const {
  initializeTestEnvironment,
  assertFails,
  assertSucceeds,
} = require("@firebase/rules-unit-testing");
const { test, before, after, beforeEach } = require("node:test");
const fs = require("node:fs");

let testEnv;
const PROJECT_ID = process.env.GCP_PROJECT || "demo-no-project";
const ALICE_UID = "alice_gamer_123";
const BOB_UID = "bob_gamer_456";

const [emulatorHost, emulatorPortStr] = (
  process.env.FIRESTORE_EMULATOR_HOST || "127.0.0.1:8085"
).split(":");
const emulatorPort = parseInt(emulatorPortStr, 10);

function validProfilePayload(uid, now = new Date(Date.now() - 2000)) {
  return {
    userId: uid,
    displayName: "Aarav Player",
    uiLanguage: "HINDI",
    customRegionEnabled: true,
    regionLeft: 0.06,
    regionTop: 0.70,
    regionRight: 0.94,
    regionBottom: 0.92,
    speechSpeed: 1.0,
    speechPitch: 1.0,
    speechVolume: 0.95,
    ocrIntervalMs: 600,
    createdAt: now,
    updatedAt: now,
  };
}

function validTranslationPayload(uid, now = new Date(Date.now() - 2000)) {
  return {
    userId: uid,
    originalEnglish: "Captain: Stay behind me! The gate is opening.",
    translatedHindi: "Captain: मेरे पीछे रहो! द्वार खुल रहा है।",
    captureMode: "region",
    favorite: false,
    createdAt: now,
    updatedAt: now,
  };
}

before(async () => {
  const rules = fs.readFileSync("./firestore.rules", "utf8");
  testEnv = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: {
      rules,
      host: emulatorHost,
      port: emulatorPort,
    },
  });
});

after(async () => {
  if (testEnv) {
    await testEnv.cleanup();
  }
});

beforeEach(async () => {
  if (testEnv) {
    await testEnv.clearFirestore();
  }
});

// --- UNAUTHENTICATED DENIAL ---

test("Unauthenticated user: denied all reads and writes on users and translations", async () => {
  const unauthDb = testEnv.unauthenticatedContext().firestore();

  await assertFails(unauthDb.collection("users").doc(ALICE_UID).get());
  await assertFails(
    unauthDb.collection("users").doc(ALICE_UID).set(validProfilePayload(ALICE_UID))
  );
  await assertFails(
    unauthDb.collection("users").doc(ALICE_UID).collection("translations").get()
  );
  await assertFails(
    unauthDb
      .collection("users")
      .doc(ALICE_UID)
      .collection("translations")
      .doc("tr_1")
      .set(validTranslationPayload(ALICE_UID))
  );
});

// --- USER PROFILE SECURITY & KOTLIN PARITY ---

test("Authenticated owner: valid profile create and partial update succeed", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const created = new Date(Date.now() - 10000);

  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).set(validProfilePayload(ALICE_UID, created))
  );

  await assertSucceeds(aliceDb.collection("users").doc(ALICE_UID).get());

  // Partial update mirroring Kotlin syncSettings()
  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).update({
      uiLanguage: "ENGLISH",
      speechSpeed: 1.25,
      regionTop: 0.65,
      updatedAt: new Date(Date.now() - 1000),
    })
  );
});

test("User profile: rejects shadow fields, immutable createdAt mutation, future timestamps, and invalid ranges", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const created = new Date(Date.now() - 10000);

  // Reject Ghost / Shadow field (e.g. role / isAdmin)
  await assertFails(
    aliceDb.collection("users").doc(ALICE_UID).set({
      ...validProfilePayload(ALICE_UID, created),
      role: "admin",
    })
  );

  // Reject future timestamp
  await assertFails(
    aliceDb
      .collection("users")
      .doc(ALICE_UID)
      .set(validProfilePayload(ALICE_UID, new Date(Date.now() + 60000)))
  );

  // Reject inverted reading box (regionRight <= regionLeft)
  await assertFails(
    aliceDb.collection("users").doc(ALICE_UID).set({
      ...validProfilePayload(ALICE_UID, created),
      regionLeft: 0.8,
      regionRight: 0.2,
    })
  );

  // Create valid doc first, then verify createdAt immutability
  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).set(validProfilePayload(ALICE_UID, created))
  );

  await assertFails(
    aliceDb.collection("users").doc(ALICE_UID).update({
      createdAt: new Date(Date.now() - 500),
      updatedAt: new Date(Date.now() - 500),
    })
  );

  // Reject listing root /users collection
  await assertFails(aliceDb.collection("users").get());
});

// --- TRANSLATIONS SUBCOLLECTION SECURITY & KOTLIN PARITY ---

test("Authenticated owner: valid Kotlin translation create, list query, favorite toggle, and delete succeed", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const created = new Date(Date.now() - 10000);
  const col = aliceDb.collection("users").doc(ALICE_UID).collection("translations");

  // Empty subcollection list query must succeed (mirrors observeTranslations)
  await assertSucceeds(col.orderBy("createdAt", "desc").limit(200).get());

  // Create mirroring Kotlin addTranslation (NO @DocumentId `id` field)
  await assertSucceeds(col.doc("tr_001").set(validTranslationPayload(ALICE_UID, created)));

  // List query matching Kotlin repository
  await assertSucceeds(col.orderBy("createdAt", "desc").limit(200).get());

  // Partial favorite toggle mirroring Kotlin toggleFavorite()
  await assertSucceeds(
    col.doc("tr_001").update({
      favorite: true,
      updatedAt: new Date(Date.now() - 1000),
    })
  );

  // Owner can delete their own entry
  await assertSucceeds(col.doc("tr_001").delete());
});

test("Translations: rejects @DocumentId 'id' key, oversized strings, bad captureMode, and mutating dialogue text", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const created = new Date(Date.now() - 10000);
  const col = aliceDb.collection("users").doc(ALICE_UID).collection("translations");

  // Reject unexpected 'id' key on create
  await assertFails(
    col.doc("tr_bad_id").set({
      id: "tr_bad_id",
      ...validTranslationPayload(ALICE_UID, created),
    })
  );

  // Reject invalid captureMode enum
  await assertFails(
    col.doc("tr_bad_mode").set({
      ...validTranslationPayload(ALICE_UID, created),
      captureMode: "invalid_mode",
    })
  );

  // Reject oversized Hindi text (> 2000 chars)
  await assertFails(
    col.doc("tr_huge").set({
      ...validTranslationPayload(ALICE_UID, created),
      translatedHindi: "अ".repeat(2001),
    })
  );

  // Reject updating immutable dialogue content
  await assertSucceeds(col.doc("tr_002").set(validTranslationPayload(ALICE_UID, created)));
  await assertFails(
    col.doc("tr_002").update({
      translatedHindi: "Tampered text",
      updatedAt: new Date(Date.now() - 1000),
    })
  );
});

// --- CROSS-USER ISOLATION ---

test("Cross-user isolation: Alice cannot read, list, create, update, or delete Bob's data", async () => {
  await testEnv.withSecurityRulesDisabled(async (context) => {
    const adminDb = context.firestore();
    await adminDb.collection("users").doc(BOB_UID).set(validProfilePayload(BOB_UID));
    await adminDb
      .collection("users")
      .doc(BOB_UID)
      .collection("translations")
      .doc("bob_tr_1")
      .set(validTranslationPayload(BOB_UID));
  });

  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();

  await assertFails(aliceDb.collection("users").doc(BOB_UID).get());
  await assertFails(
    aliceDb.collection("users").doc(BOB_UID).update({ displayName: "Hijacked" })
  );
  await assertFails(
    aliceDb.collection("users").doc(BOB_UID).collection("translations").get()
  );
  await assertFails(
    aliceDb
      .collection("users")
      .doc(BOB_UID)
      .collection("translations")
      .doc("bob_tr_1")
      .get()
  );
  await assertFails(
    aliceDb
      .collection("users")
      .doc(BOB_UID)
      .collection("translations")
      .doc("bob_tr_1")
      .update({ favorite: true, updatedAt: new Date(Date.now() - 1000) })
  );
  await assertFails(
    aliceDb
      .collection("users")
      .doc(BOB_UID)
      .collection("translations")
      .doc("bob_tr_1")
      .delete()
  );
  await assertFails(
    aliceDb
      .collection("users")
      .doc(BOB_UID)
      .collection("translations")
      .doc("injected_1")
      .set(validTranslationPayload(ALICE_UID))
  );
});
