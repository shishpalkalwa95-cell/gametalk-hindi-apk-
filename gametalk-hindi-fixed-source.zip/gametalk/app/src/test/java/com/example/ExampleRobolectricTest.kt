package com.example

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.provider.Settings
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.AppDatabase
import com.example.data.ReadingRegion
import com.example.data.SettingsStore
import com.example.data.TranslationRepository
import com.example.engine.LiveTranslatorController
import com.example.engine.OcrProcessor
import com.example.engine.PermissionManager
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @get:Rule
    val composeRule = createAndroidComposeRule<MainActivity>()

    @Test
    fun `app name matches GameTalk Hindi`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        assertEquals("GameTalk Hindi", context.getString(R.string.app_name))
    }

    @Test
    fun `permission manager creates valid overlay and tts intents`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val manager = PermissionManager(context)

        val overlayIntent = manager.createOverlayPermissionIntent()
        assertEquals(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, overlayIntent.action)
        assertTrue(overlayIntent.data.toString().contains(context.packageName))

        val ttsIntent = manager.createInstallHindiTtsIntent()
        assertNotNull(ttsIntent.action)
    }

    @Test
    fun `pending media projection grant is consumed exactly once`() {
        val controller = LiveTranslatorController()
        val intent = Intent("mock.projection.data")
        controller.storePendingProjectionGrant(Activity.RESULT_OK, intent)

        val first = controller.consumePendingProjectionGrant()
        assertNotNull(first)
        assertEquals(Activity.RESULT_OK, first?.first)

        val second = controller.consumePendingProjectionGrant()
        assertNull(second)
    }

    @Test
    fun `ocr frame signature detects visual change vs identical frame`() {
        val processor = OcrProcessor()
        val bmpA = Bitmap.createBitmap(64, 64, Bitmap.Config.ARGB_8888).apply { eraseColor(Color.BLACK) }
        val bmpB = Bitmap.createBitmap(64, 64, Bitmap.Config.ARGB_8888).apply { eraseColor(Color.BLACK) }
        val bmpC = Bitmap.createBitmap(64, 64, Bitmap.Config.ARGB_8888).apply { eraseColor(Color.WHITE) }

        val sigA = processor.computeFrameSignature(bmpA)
        val sigB = processor.computeFrameSignature(bmpB)
        val sigC = processor.computeFrameSignature(bmpC)

        assertEquals(sigA, sigB)
        assertNotEquals(sigA, sigC)

        bmpA.recycle()
        bmpB.recycle()
        bmpC.recycle()
    }

    @Test
    fun `room repository persists and clears translation history`() = runTest {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val db = Room.inMemoryDatabaseBuilder(context, AppDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        val repo = TranslationRepository(db.translationDao(), SettingsStore(context))

        val insertedId = repo.saveTranslation(
            english = "The gate is locked.",
            hindi = "द्वार बंद है।",
            customRegionMode = true
        )
        assertTrue(insertedId > 0L)

        val saved = repo.historyFlow.first()
        assertEquals(1, saved.size)
        assertEquals("द्वार बंद है।", saved.first().translatedHindi)

        repo.deleteTranslation(insertedId)
        assertTrue(repo.historyFlow.first().isEmpty())

        repo.saveTranslation("Attack now!", "अभी हमला करो!", customRegionMode = false)
        repo.clearHistory()
        assertTrue(repo.historyFlow.first().isEmpty())

        repo.saveReadingRegion(ReadingRegion(0.1f, 0.65f, 0.9f, 0.88f))
        val updatedSettings = repo.settingsFlow.first()
        assertEquals(0.65f, updatedSettings.readingRegion.top, 0.01f)

        db.close()
    }

    @Test
    fun `dashboard renders Hindi UI toggles to English and navigates to History and Settings`() {
        composeRule.waitForIdle()

        // Main dashboard elements visible in Hindi by default
        composeRule.onNodeWithTag("status_badge").assertIsDisplayed()
        composeRule.onNodeWithTag("start_translation_button").assertIsDisplayed()
        composeRule.onNodeWithText("लाइव अनुवाद शुरू करें").assertIsDisplayed()

        // Toggle UI language to English
        composeRule.onNodeWithTag("language_toggle_button").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithText("Start Live Translation").assertIsDisplayed()

        // Navigate to History tab
        composeRule.onNodeWithTag("nav_history").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithText("No translations saved yet").assertIsDisplayed()

        // Navigate to Settings tab
        composeRule.onNodeWithTag("nav_settings").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithText("Reading Area Settings").assertIsDisplayed()
    }
}
