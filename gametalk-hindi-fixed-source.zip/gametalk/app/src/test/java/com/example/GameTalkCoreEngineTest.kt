package com.example

import com.example.data.ReadingRegion
import com.example.data.TranslatorStatus
import com.example.engine.BoundedSpeechQueue
import com.example.engine.DialogueDeduplicator
import com.example.engine.GameDialogueFormatter
import com.example.engine.LiveTranslatorController
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class GameTalkCoreEngineTest {

    @Test
    fun `reading region clamps out of bounds coordinates and maps accurately to landscape and portrait bitmaps`() {
        val raw = ReadingRegion(left = -0.2f, top = 0.72f, right = 1.4f, bottom = 0.95f).normalized()
        assertEquals(0f, raw.left, 0.0001f)
        assertEquals(1f, raw.right, 0.0001f)
        assertEquals(0.72f, raw.top, 0.0001f)
        assertEquals(0.95f, raw.bottom, 0.0001f)

        // Portrait 1080x2400
        val portraitRect = raw.toBitmapPixelRect(1080, 2400)
        assertEquals(0, portraitRect.left)
        assertEquals(1080, portraitRect.right)
        assertEquals(1728, portraitRect.top)
        assertEquals(2280, portraitRect.bottom)
        assertEquals(1080, portraitRect.width)
        assertEquals(552, portraitRect.height)

        // Landscape 2400x1080
        val landscapeRect = raw.toBitmapPixelRect(2400, 1080)
        assertEquals(0, landscapeRect.left)
        assertEquals(2400, landscapeRect.right)
        assertEquals(778, landscapeRect.top)
        assertEquals(1026, landscapeRect.bottom)
        assertEquals(2400, landscapeRect.width)
        assertEquals(248, landscapeRect.height)
    }

    @Test
    fun `reading region fromPixelRect converts overlay pixels to normalized ratios`() {
        val region = ReadingRegion.fromPixelRect(
            leftPx = 100,
            topPx = 700,
            rightPx = 900,
            bottomPx = 900,
            screenWidthPx = 1000,
            screenHeightPx = 1000
        )
        assertEquals(0.1f, region.left, 0.001f)
        assertEquals(0.7f, region.top, 0.001f)
        assertEquals(0.9f, region.right, 0.001f)
        assertEquals(0.9f, region.bottom, 0.001f)
    }

    @Test
    fun `dialogue deduplicator filters OCR noise suppresses duplicates and accepts new dialogue`() {
        val dedup = DialogueDeduplicator(duplicateWindowMs = 8_000L, similarityThreshold = 0.86f)

        // Noise should be rejected
        assertFalse(dedup.shouldProcess("60 FPS", nowMs = 1_000L))
        assertFalse(dedup.shouldProcess("00:42", nowMs = 1_100L))
        assertFalse(dedup.shouldProcess("...", nowMs = 1_200L))
        assertFalse(dedup.shouldProcess("A", nowMs = 1_300L))

        // First real dialogue accepted
        assertTrue(dedup.shouldProcess("Follow me to the northern gate!", nowMs = 2_000L))

        // Exact duplicate within window suppressed
        assertFalse(dedup.shouldProcess("Follow me to the northern gate!", nowMs = 3_000L))

        // Tiny OCR flicker (1 char difference) suppressed
        assertFalse(dedup.shouldProcess("Follow me to the northern gate.", nowMs = 4_000L))

        // Force read ("Read Now") overrides suppression
        assertTrue(dedup.shouldProcess("Follow me to the northern gate!", nowMs = 4_500L, force = true))

        // New dialogue line accepted immediately
        assertTrue(dedup.shouldProcess("Watch out, archers on the roof!", nowMs = 5_000L))

        // Same dialogue after window expires accepted again
        assertTrue(dedup.shouldProcess("Watch out, archers on the roof!", nowMs = 15_000L))
    }

    @Test
    fun `game dialogue formatter preserves character names while translating non-speaker lines directly`() {
        val speakerLine = GameDialogueFormatter.extractSpeakerPrefix("Kratos: Stay behind me, boy.")
        assertEquals("Kratos", speakerLine.speakerPrefix)
        assertEquals("Stay behind me, boy.", speakerLine.dialogueBody)
        assertEquals("Kratos: मेरे पीछे रहो।", GameDialogueFormatter.formatCombined("Kratos", "मेरे पीछे रहो।"))

        val warningLine = GameDialogueFormatter.extractSpeakerPrefix("Warning: Low health!")
        assertNull(warningLine.speakerPrefix)
        assertEquals("Warning: Low health!", warningLine.dialogueBody)
    }

    @Test
    fun `bounded speech queue preserves FIFO order skips consecutive duplicates and caps capacity`() {
        val queue = BoundedSpeechQueue(maxCapacity = 3)
        queue.enqueue("पहला संवाद")
        queue.enqueue("पहला संवाद") // consecutive duplicate ignored
        assertEquals(1, queue.size())

        queue.enqueue("दूसरा संवाद")
        queue.enqueue("तीसरा संवाद")
        queue.enqueue("चौथा संवाद") // evicts oldest ("पहला संवाद")

        assertEquals(3, queue.size())
        assertEquals("दूसरा संवाद", queue.pollNext())
        assertEquals("तीसरा संवाद", queue.pollNext())
        assertEquals("चौथा संवाद", queue.pollNext())
        assertNull(queue.pollNext())
    }

    @Test
    fun `live translator controller tracks full capture pause speak stop lifecycle`() {
        val controller = LiveTranslatorController()
        assertEquals(TranslatorStatus.IDLE, controller.sessionState.value.status)
        assertFalse(controller.sessionState.value.isCapturing)

        controller.setCapturingStarted()
        assertEquals(TranslatorStatus.CAPTURING, controller.sessionState.value.status)
        assertTrue(controller.sessionState.value.isCapturing)

        controller.updateStatus(TranslatorStatus.READING)
        assertEquals(TranslatorStatus.READING, controller.sessionState.value.status)

        controller.updateStatus(TranslatorStatus.TRANSLATING)
        assertEquals(TranslatorStatus.TRANSLATING, controller.sessionState.value.status)

        controller.updateLatestDialogue("Hold the bridge!", "पुल को थामे रखो!")
        controller.updateSpeakingState(speaking = true, queuedCount = 1)
        assertEquals(TranslatorStatus.SPEAKING, controller.sessionState.value.status)
        assertEquals("पुल को थामे रखो!", controller.sessionState.value.lastHindiText)

        controller.setPaused(true)
        assertEquals(TranslatorStatus.PAUSED, controller.sessionState.value.status)
        assertTrue(controller.sessionState.value.isPaused)

        controller.setPaused(false)
        assertEquals(TranslatorStatus.CAPTURING, controller.sessionState.value.status)
        assertFalse(controller.sessionState.value.isPaused)

        controller.setCapturingStopped()
        assertEquals(TranslatorStatus.IDLE, controller.sessionState.value.status)
        assertFalse(controller.sessionState.value.isCapturing)
        assertNotNull(controller.sessionState.value.lastHindiText)
    }

    @Test
    fun `live translator controller handles permission denial error recovery and command dispatch`() {
        val controller = LiveTranslatorController()

        controller.reportPermissionRequired(
            messageHi = "स्क्रीन कैप्चर अनुमति अस्वीकृत कर दी गई।",
            messageEn = "Screen capture permission denied."
        )
        assertEquals(TranslatorStatus.PERMISSION_REQUIRED, controller.sessionState.value.status)
        assertEquals("स्क्रीन कैप्चर अनुमति अस्वीकृत कर दी गई।", controller.sessionState.value.lastErrorHi)

        controller.clearError()
        assertEquals(TranslatorStatus.IDLE, controller.sessionState.value.status)
        assertNull(controller.sessionState.value.lastErrorHi)

        controller.setCapturingStarted()
        controller.reportError("अनुवाद विफल", "Translation failed", markErrorStatus = true)
        assertEquals(TranslatorStatus.ERROR, controller.sessionState.value.status)

        controller.clearError()
        assertEquals(TranslatorStatus.CAPTURING, controller.sessionState.value.status)
    }

    @Test
    fun `bilingual AppStrings provides Hindi and English labels for all 8 translator statuses`() {
        val hi = com.example.ui.i18n.AppStrings.forLanguage(com.example.data.UiLanguage.HINDI)
        val en = com.example.ui.i18n.AppStrings.forLanguage(com.example.data.UiLanguage.ENGLISH)

        assertEquals("GameTalk Hindi", hi.appTitle)
        assertEquals("GameTalk Hindi", en.appTitle)
        for (status in TranslatorStatus.entries) {
            assertTrue("Missing Hindi status label for $status", !hi.statusLabels[status].isNullOrBlank())
            assertTrue("Missing English status label for $status", !en.statusLabels[status].isNullOrBlank())
        }
    }

    @Test
    fun `reading region enforces minimum box dimensions and zero-bitmap safety`() {
        val tiny = ReadingRegion(0.5f, 0.5f, 0.501f, 0.501f).normalized()
        assertTrue(tiny.widthRatio >= ReadingRegion.MIN_SIZE_RATIO - 0.0001f)
        assertTrue(tiny.heightRatio >= ReadingRegion.MIN_SIZE_RATIO - 0.0001f)

        val zeroRect = tiny.toBitmapPixelRect(0, 0)
        assertEquals(0, zeroRect.width)
        assertEquals(0, zeroRect.height)
    }
}
