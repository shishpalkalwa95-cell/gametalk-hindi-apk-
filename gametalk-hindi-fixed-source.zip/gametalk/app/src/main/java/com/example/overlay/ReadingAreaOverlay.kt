package com.example.overlay

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.RectF
import android.os.Build
import android.provider.Settings
import android.util.Log
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import com.example.data.ReadingRegion
import kotlin.math.hypot

/**
 * Transparent, movable, and 4-corner resizable Reading Area overlay drawn via WindowManager.
 * - Drag inside the rectangle to reposition anywhere on screen.
 * - Drag any of the 4 corner handles to resize smoothly.
 * - Tap the Lock badge to switch into pass-through mode (FLAG_NOT_TOUCHABLE) while gaming.
 * - Persists normalized [0f..1f] coordinates so orientation changes remain accurately mapped.
 */
class ReadingAreaOverlay(
    private val context: Context,
    private val onRegionChanged: (ReadingRegion) -> Unit,
    private val onToggleLock: () -> Unit,
    private val onHideRequested: () -> Unit
) {
    private val windowManager = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private var overlayView: ReadingRegionCanvasView? = null
    private var layoutParams: WindowManager.LayoutParams? = null
    private var isAttached: Boolean = false

    private var currentRegion: ReadingRegion = ReadingRegion.DEFAULT
    private var isLocked: Boolean = false
    private var showBorder: Boolean = true
    private var dimOutside: Boolean = true
    private var isHindiUi: Boolean = true

    fun updateState(
        visible: Boolean,
        region: ReadingRegion,
        locked: Boolean,
        showBorder: Boolean,
        dimOutside: Boolean,
        isHindiUi: Boolean
    ) {
        currentRegion = region.normalized()
        isLocked = locked
        this.showBorder = showBorder
        this.dimOutside = dimOutside
        this.isHindiUi = isHindiUi

        if (!visible || !showBorder || !Settings.canDrawOverlays(context)) {
            detach()
            return
        }

        if (!isAttached) {
            attach()
        } else {
            updateWindowFlagsAndRedraw()
        }
    }

    fun onConfigurationChanged() {
        if (isAttached) {
            overlayView?.syncFromNormalizedRegion(currentRegion)
            overlayView?.invalidate()
        }
    }

    private fun attach() {
        if (isAttached || !Settings.canDrawOverlays(context)) return
        val view = ReadingRegionCanvasView(context).apply {
            configure(
                region = currentRegion,
                locked = isLocked,
                dimOutside = dimOutside,
                isHindiUi = isHindiUi,
                onCommit = { updated ->
                    currentRegion = updated
                    onRegionChanged(updated)
                },
                onLockTap = onToggleLock,
                onHideTap = onHideRequested
            )
        }

        val params = createLayoutParams(isLocked)
        try {
            windowManager.addView(view, params)
            overlayView = view
            layoutParams = params
            isAttached = true
        } catch (t: Throwable) {
            Log.e(TAG, "Failed to attach ReadingAreaOverlay", t)
            overlayView = null
            layoutParams = null
            isAttached = false
        }
    }

    private fun updateWindowFlagsAndRedraw() {
        val view = overlayView ?: return
        val params = layoutParams ?: return

        val desiredFlags = computeFlags(isLocked)
        if (params.flags != desiredFlags) {
            params.flags = desiredFlags
            runCatching { windowManager.updateViewLayout(view, params) }
        }

        view.updateDisplayOptions(
            region = currentRegion,
            locked = isLocked,
            dimOutside = dimOutside,
            isHindiUi = isHindiUi
        )
    }

    fun detach() {
        if (!isAttached) return
        val view = overlayView
        overlayView = null
        layoutParams = null
        isAttached = false
        if (view != null) {
            runCatching { windowManager.removeView(view) }
        }
    }

    private fun createLayoutParams(locked: Boolean): WindowManager.LayoutParams {
        val type = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        return WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            type,
            computeFlags(locked),
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }
    }

    private fun computeFlags(locked: Boolean): Int {
        var flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
        if (locked) {
            flags = flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        }
        return flags
    }

    private class ReadingRegionCanvasView(context: Context) : View(context) {

        private enum class DragMode {
            NONE, MOVE, TOP_LEFT, TOP_RIGHT, BOTTOM_LEFT, BOTTOM_RIGHT
        }

        private val density = resources.displayMetrics.density
        private val handleRadiusPx = 11f * density
        private val handleHitRadiusPx = 30f * density
        private val minBoxWidthPx = 96f * density
        private val minBoxHeightPx = 56f * density

        private var normalizedRegion: ReadingRegion = ReadingRegion.DEFAULT
        private val boxRect = RectF()
        private val lockPillRect = RectF()
        private val hidePillRect = RectF()

        private var locked: Boolean = false
        private var dimOutside: Boolean = true
        private var isHindiUi: Boolean = true

        private var dragMode: DragMode = DragMode.NONE
        private var lastTouchX: Float = 0f
        private var lastTouchY: Float = 0f

        private var onCommit: ((ReadingRegion) -> Unit)? = null
        private var onLockTap: (() -> Unit)? = null
        private var onHideTap: (() -> Unit)? = null

        private val dimPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.argb(118, 5, 8, 20)
            style = Paint.Style.FILL
        }

        private val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#22D3EE")
            style = Paint.Style.STROKE
            strokeWidth = 2.6f * density
        }

        private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.argb(95, 157, 107, 255)
            style = Paint.Style.STROKE
            strokeWidth = 6f * density
        }

        private val handleFillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#9D6BFF")
            style = Paint.Style.FILL
        }

        private val handleStrokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            style = Paint.Style.STROKE
            strokeWidth = 2f * density
        }

        private val pillBgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.argb(225, 15, 22, 42)
            style = Paint.Style.FILL
        }

        private val pillBorderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#22D3EE")
            style = Paint.Style.STROKE
            strokeWidth = 1.4f * density
        }

        private val pillTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textSize = 12f * density
            textAlign = Paint.Align.CENTER
            isFakeBoldText = true
        }

        fun configure(
            region: ReadingRegion,
            locked: Boolean,
            dimOutside: Boolean,
            isHindiUi: Boolean,
            onCommit: (ReadingRegion) -> Unit,
            onLockTap: () -> Unit,
            onHideTap: () -> Unit
        ) {
            this.normalizedRegion = region.normalized()
            this.locked = locked
            this.dimOutside = dimOutside
            this.isHindiUi = isHindiUi
            this.onCommit = onCommit
            this.onLockTap = onLockTap
            this.onHideTap = onHideTap
            syncFromNormalizedRegion(this.normalizedRegion)
            invalidate()
        }

        fun updateDisplayOptions(
            region: ReadingRegion,
            locked: Boolean,
            dimOutside: Boolean,
            isHindiUi: Boolean
        ) {
            this.locked = locked
            this.dimOutside = dimOutside
            this.isHindiUi = isHindiUi
            if (dragMode == DragMode.NONE) {
                this.normalizedRegion = region.normalized()
                syncFromNormalizedRegion(this.normalizedRegion)
            }
            invalidate()
        }

        fun syncFromNormalizedRegion(region: ReadingRegion) {
            if (width <= 0 || height <= 0) return
            val safe = region.normalized()
            boxRect.set(
                safe.left * width,
                safe.top * height,
                safe.right * width,
                safe.bottom * height
            )
            updateToolbarRects()
        }

        override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
            super.onSizeChanged(w, h, oldw, oldh)
            syncFromNormalizedRegion(normalizedRegion)
        }

        private fun updateToolbarRects() {
            val pillHeight = 30f * density
            val lockWidth = 96f * density
            val hideWidth = 72f * density
            val gap = 8f * density
            val pillTop = if (boxRect.top - pillHeight - 10f * density > 16f * density) {
                boxRect.top - pillHeight - 10f * density
            } else {
                (boxRect.bottom + 10f * density).coerceAtMost(height - pillHeight - 12f * density)
            }
            val startX = boxRect.left.coerceIn(12f * density, (width - lockWidth - hideWidth - gap - 12f * density).coerceAtLeast(12f * density))
            lockPillRect.set(startX, pillTop, startX + lockWidth, pillTop + pillHeight)
            hidePillRect.set(lockPillRect.right + gap, pillTop, lockPillRect.right + gap + hideWidth, pillTop + pillHeight)
        }

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            if (width <= 0 || height <= 0) return
            if (boxRect.width() <= 1f || boxRect.height() <= 1f) {
                syncFromNormalizedRegion(normalizedRegion)
            }

            if (dimOutside) {
                // Draw 4 dimmed bands around the transparent reading window
                canvas.drawRect(0f, 0f, width.toFloat(), boxRect.top, dimPaint)
                canvas.drawRect(0f, boxRect.bottom, width.toFloat(), height.toFloat(), dimPaint)
                canvas.drawRect(0f, boxRect.top, boxRect.left, boxRect.bottom, dimPaint)
                canvas.drawRect(boxRect.right, boxRect.top, width.toFloat(), boxRect.bottom, dimPaint)
            }

            val cornerRadius = 10f * density
            borderPaint.color = if (locked) Color.parseColor("#9D6BFF") else Color.parseColor("#22D3EE")
            borderPaint.alpha = if (locked) 175 else 255
            glowPaint.alpha = if (locked) 50 else 100

            canvas.drawRoundRect(boxRect, cornerRadius, cornerRadius, glowPaint)
            canvas.drawRoundRect(boxRect, cornerRadius, cornerRadius, borderPaint)

            if (!locked) {
                // 4 corner resize handles
                val corners = arrayOf(
                    boxRect.left to boxRect.top,
                    boxRect.right to boxRect.top,
                    boxRect.left to boxRect.bottom,
                    boxRect.right to boxRect.bottom
                )
                for ((cx, cy) in corners) {
                    canvas.drawCircle(cx, cy, handleRadiusPx, handleFillPaint)
                    canvas.drawCircle(cx, cy, handleRadiusPx, handleStrokePaint)
                }

                // Floating action pills to Lock or Hide the box directly over the game
                updateToolbarRects()
                val pillRadius = 15f * density
                canvas.drawRoundRect(lockPillRect, pillRadius, pillRadius, pillBgPaint)
                canvas.drawRoundRect(lockPillRect, pillRadius, pillRadius, pillBorderPaint)
                val lockLabel = if (isHindiUi) "लॉक करें" else "Lock Box"
                val textOffsetY = (pillTextPaint.descent() + pillTextPaint.ascent()) / 2f
                canvas.drawText(
                    lockLabel,
                    lockPillRect.centerX(),
                    lockPillRect.centerY() - textOffsetY,
                    pillTextPaint
                )

                canvas.drawRoundRect(hidePillRect, pillRadius, pillRadius, pillBgPaint)
                canvas.drawRoundRect(hidePillRect, pillRadius, pillRadius, pillBorderPaint)
                val hideLabel = if (isHindiUi) "छुपाएँ" else "Hide"
                canvas.drawText(
                    hideLabel,
                    hidePillRect.centerX(),
                    hidePillRect.centerY() - textOffsetY,
                    pillTextPaint
                )
            }
        }

        override fun onTouchEvent(event: MotionEvent): Boolean {
            if (locked) return false
            val x = event.x
            val y = event.y

            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    if (lockPillRect.contains(x, y)) {
                        onLockTap?.invoke()
                        return true
                    }
                    if (hidePillRect.contains(x, y)) {
                        onHideTap?.invoke()
                        return true
                    }

                    dragMode = hitTest(x, y)
                    lastTouchX = x
                    lastTouchY = y
                    return dragMode != DragMode.NONE
                }

                MotionEvent.ACTION_MOVE -> {
                    if (dragMode == DragMode.NONE) return false
                    val dx = x - lastTouchX
                    val dy = y - lastTouchY
                    lastTouchX = x
                    lastTouchY = y
                    applyDrag(dx, dy)
                    invalidate()
                    return true
                }

                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    if (dragMode != DragMode.NONE) {
                        dragMode = DragMode.NONE
                        commitNormalizedRegion()
                        return true
                    }
                }
            }
            return false
        }

        private fun hitTest(x: Float, y: Float): DragMode {
            if (hypot(x - boxRect.left, y - boxRect.top) <= handleHitRadiusPx) return DragMode.TOP_LEFT
            if (hypot(x - boxRect.right, y - boxRect.top) <= handleHitRadiusPx) return DragMode.TOP_RIGHT
            if (hypot(x - boxRect.left, y - boxRect.bottom) <= handleHitRadiusPx) return DragMode.BOTTOM_LEFT
            if (hypot(x - boxRect.right, y - boxRect.bottom) <= handleHitRadiusPx) return DragMode.BOTTOM_RIGHT
            if (boxRect.contains(x, y)) return DragMode.MOVE
            return DragMode.NONE
        }

        private fun applyDrag(dx: Float, dy: Float) {
            val maxW = width.toFloat().coerceAtLeast(minBoxWidthPx)
            val maxH = height.toFloat().coerceAtLeast(minBoxHeightPx)

            when (dragMode) {
                DragMode.MOVE -> {
                    val boxW = boxRect.width()
                    val boxH = boxRect.height()
                    val newLeft = (boxRect.left + dx).coerceIn(0f, (maxW - boxW).coerceAtLeast(0f))
                    val newTop = (boxRect.top + dy).coerceIn(0f, (maxH - boxH).coerceAtLeast(0f))
                    boxRect.set(newLeft, newTop, newLeft + boxW, newTop + boxH)
                }

                DragMode.TOP_LEFT -> {
                    boxRect.left = (boxRect.left + dx).coerceIn(0f, boxRect.right - minBoxWidthPx)
                    boxRect.top = (boxRect.top + dy).coerceIn(0f, boxRect.bottom - minBoxHeightPx)
                }

                DragMode.TOP_RIGHT -> {
                    boxRect.right = (boxRect.right + dx).coerceIn(boxRect.left + minBoxWidthPx, maxW)
                    boxRect.top = (boxRect.top + dy).coerceIn(0f, boxRect.bottom - minBoxHeightPx)
                }

                DragMode.BOTTOM_LEFT -> {
                    boxRect.left = (boxRect.left + dx).coerceIn(0f, boxRect.right - minBoxWidthPx)
                    boxRect.bottom = (boxRect.bottom + dy).coerceIn(boxRect.top + minBoxHeightPx, maxH)
                }

                DragMode.BOTTOM_RIGHT -> {
                    boxRect.right = (boxRect.right + dx).coerceIn(boxRect.left + minBoxWidthPx, maxW)
                    boxRect.bottom = (boxRect.bottom + dy).coerceIn(boxRect.top + minBoxHeightPx, maxH)
                }

                DragMode.NONE -> Unit
            }
        }

        private fun commitNormalizedRegion() {
            if (width <= 0 || height <= 0) return
            val updated = ReadingRegion.fromPixelRect(
                leftPx = boxRect.left.toInt(),
                topPx = boxRect.top.toInt(),
                rightPx = boxRect.right.toInt(),
                bottomPx = boxRect.bottom.toInt(),
                screenWidthPx = width,
                screenHeightPx = height
            )
            normalizedRegion = updated
            onCommit?.invoke(updated)
        }
    }

    companion object {
        private const val TAG = "ReadingAreaOverlay"
    }
}
