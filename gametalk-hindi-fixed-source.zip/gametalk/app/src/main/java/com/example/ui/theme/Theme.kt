package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.unit.dp

private val GameTalkDarkColorScheme = darkColorScheme(
    primary = ElectricPurple,
    onPrimary = ObsidianBlack,
    primaryContainer = ElectricPurpleContainer,
    onPrimaryContainer = TextPrimaryLight,
    secondary = NeonCyan,
    onSecondary = ObsidianBlack,
    secondaryContainer = NeonCyanContainer,
    onSecondaryContainer = TextPrimaryLight,
    tertiary = StatusActiveEmerald,
    onTertiary = ObsidianBlack,
    background = ObsidianBlack,
    onBackground = TextPrimaryLight,
    surface = DeepNavy,
    onSurface = TextPrimaryLight,
    surfaceVariant = NavyCard,
    onSurfaceVariant = TextSecondaryLight,
    surfaceContainerLowest = ObsidianBlack,
    surfaceContainerLow = DeepNavy,
    surfaceContainer = NavyCard,
    surfaceContainerHigh = NavyElevated,
    surfaceContainerHighest = NavyBorder,
    outline = NavyBorder,
    outlineVariant = ColorTokens.SubtleOutline,
    error = StatusErrorRose,
    onError = TextPrimaryLight,
    errorContainer = ColorTokens.ErrorContainerDark,
    onErrorContainer = ColorTokens.ErrorOnContainer
)

private object ColorTokens {
    val SubtleOutline = androidx.compose.ui.graphics.Color(0xFF1F2B4D)
    val ErrorContainerDark = androidx.compose.ui.graphics.Color(0xFF4C0D1D)
    val ErrorOnContainer = androidx.compose.ui.graphics.Color(0xFFFFD6DF)
}

private val GameTalkShapes = Shapes(
    extraSmall = RoundedCornerShape(8.dp),
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(22.dp),
    extraLarge = RoundedCornerShape(28.dp)
)

@Composable
fun GameTalkHindiTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = GameTalkDarkColorScheme,
        typography = AppTypography,
        shapes = GameTalkShapes,
        content = content
    )
}
