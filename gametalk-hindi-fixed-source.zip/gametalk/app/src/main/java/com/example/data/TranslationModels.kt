package com.example.data

import android.graphics.Rect
import kotlin.math.roundToInt

enum class TranslatorStatus {
    IDLE,
    PERMISSION_REQUIRED,
    CAPTURING,
    READING,
    TRANSLATING,
    SPEAKING,
    PAUSED,
    ERROR
}

enum class UiLanguage {
    HINDI,
    ENGLISH
}

data class PixelRect(
    val left: Int,
    val top: Int,
    val right: Int,
    val bottom: Int
) {
    val width: Int get() = (right - left).coerceAtLeast(0)
    val height: Int get() = (bottom - top).coerceAtLeast(0)
}

/**
 * Normalized reading area coordinates in [0f..1f] relative to the full physical display.
 * Storing normalized ratios ensures accurate mapping across resolution scaling and
 * portrait/landscape game orientation switches.
 */
data class ReadingRegion(
    val left: Float = DEFAULT_LEFT,
    val top: Float = DEFAULT_TOP,
    val right: Float = DEFAULT_RIGHT,
    val bottom: Float = DEFAULT_BOTTOM
) {
    val widthRatio: Float get() = (right - left).coerceAtLeast(MIN_SIZE_RATIO)
    val heightRatio: Float get() = (bottom - top).coerceAtLeast(MIN_SIZE_RATIO)

    fun normalized(): ReadingRegion {
        val clampedLeft = left.coerceIn(0f, 1f - MIN_SIZE_RATIO)
        val clampedTop = top.coerceIn(0f, 1f - MIN_SIZE_RATIO)
        val clampedRight = right.coerceIn(clampedLeft + MIN_SIZE_RATIO, 1f)
        val clampedBottom = bottom.coerceIn(clampedTop + MIN_SIZE_RATIO, 1f)
        return ReadingRegion(
            left = clampedLeft,
            top = clampedTop,
            right = clampedRight,
            bottom = clampedBottom
        )
    }

    /**
     * Converts normalized overlay ratios into exact pixel bounds inside a captured screenshot Bitmap,
     * safely clamping within [0, bitmapWidth] and [0, bitmapHeight].
     */
    fun toBitmapPixelRect(bitmapWidth: Int, bitmapHeight: Int): PixelRect {
        if (bitmapWidth <= 0 || bitmapHeight <= 0) return PixelRect(0, 0, 0, 0)
        val safe = normalized()
        val l = (safe.left * bitmapWidth).roundToInt().coerceIn(0, (bitmapWidth - 1).coerceAtLeast(0))
        val t = (safe.top * bitmapHeight).roundToInt().coerceIn(0, (bitmapHeight - 1).coerceAtLeast(0))
        val r = (safe.right * bitmapWidth).roundToInt().coerceIn(l + 1, bitmapWidth)
        val b = (safe.bottom * bitmapHeight).roundToInt().coerceIn(t + 1, bitmapHeight)
        return PixelRect(l, t, r, b)
    }

    fun toBitmapRect(bitmapWidth: Int, bitmapHeight: Int): Rect {
        val px = toBitmapPixelRect(bitmapWidth, bitmapHeight)
        return Rect(px.left, px.top, px.right, px.bottom)
    }

    companion object {
        const val MIN_SIZE_RATIO = 0.08f
        const val DEFAULT_LEFT = 0.06f
        const val DEFAULT_TOP = 0.70f
        const val DEFAULT_RIGHT = 0.94f
        const val DEFAULT_BOTTOM = 0.92f

        val DEFAULT = ReadingRegion()

        fun fromPixelRect(
            leftPx: Int,
            topPx: Int,
            rightPx: Int,
            bottomPx: Int,
            screenWidthPx: Int,
            screenHeightPx: Int
        ): ReadingRegion {
            if (screenWidthPx <= 0 || screenHeightPx <= 0) return DEFAULT
            return ReadingRegion(
                left = leftPx.toFloat() / screenWidthPx.toFloat(),
                top = topPx.toFloat() / screenHeightPx.toFloat(),
                right = rightPx.toFloat() / screenWidthPx.toFloat(),
                bottom = bottomPx.toFloat() / screenHeightPx.toFloat()
            ).normalized()
        }
    }
}

data class AppSettings(
    val uiLanguage: UiLanguage = UiLanguage.HINDI,
    val floatingOverlayEnabled: Boolean = true,
    val subtitleOverlayEnabled: Boolean = true,
    val customRegionEnabled: Boolean = true,
    val showRegionBorder: Boolean = true,
    val dimOutsideRegion: Boolean = true,
    val regionLocked: Boolean = false,
    val readingRegion: ReadingRegion = ReadingRegion.DEFAULT,
    val ocrIntervalMs: Long = 600L,
    val speechSpeed: Float = 1.0f,
    val speechPitch: Float = 1.0f,
    val speechVolume: Float = 1.0f,
    val isMuted: Boolean = false,
    val autoSpeak: Boolean = true,
    val floatingButtonOpacity: Float = 0.92f,
    val floatingButtonSizeDp: Int = 56
)

sealed interface ModelDownloadState {
    data object NotChecked : ModelDownloadState
    data object Checking : ModelDownloadState
    data object Downloading : ModelDownloadState
    data object Downloaded : ModelDownloadState
    data class Error(val messageHi: String, val messageEn: String) : ModelDownloadState
}

sealed interface TtsVoiceStatus {
    data object Checking : TtsVoiceStatus
    data class Ready(val voiceName: String) : TtsVoiceStatus
    data object HindiMissing : TtsVoiceStatus
    data class Unavailable(val reasonHi: String, val reasonEn: String) : TtsVoiceStatus
}

data class LiveSessionState(
    val status: TranslatorStatus = TranslatorStatus.IDLE,
    val isCapturing: Boolean = false,
    val isPaused: Boolean = false,
    val isSpeaking: Boolean = false,
    val lastEnglishText: String = "",
    val lastHindiText: String = "",
    val lastErrorHi: String? = null,
    val lastErrorEn: String? = null,
    val overlayActive: Boolean = false,
    val modelState: ModelDownloadState = ModelDownloadState.NotChecked,
    val ttsStatus: TtsVoiceStatus = TtsVoiceStatus.Checking,
    val queuedSpeechCount: Int = 0,
    val framesProcessed: Long = 0L,
    val lastCapturedAt: Long = 0L
)
