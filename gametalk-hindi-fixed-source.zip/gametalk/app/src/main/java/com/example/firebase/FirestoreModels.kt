package com.example.firebase

import androidx.annotation.Keep
import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.ServerTimestamp

@Keep
@IgnoreExtraProperties
data class UserProfile(
    @DocumentId val id: String = "",
    val userId: String = "",
    val displayName: String = "Gamer",
    val uiLanguage: String = "HINDI",
    val customRegionEnabled: Boolean = true,
    val regionLeft: Double = 0.06,
    val regionTop: Double = 0.70,
    val regionRight: Double = 0.94,
    val regionBottom: Double = 0.92,
    val speechSpeed: Double = 1.0,
    val speechPitch: Double = 1.0,
    val speechVolume: Double = 1.0,
    val ocrIntervalMs: Long = 600L,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class CloudTranslation(
    @DocumentId val id: String = "",
    val userId: String = "",
    val originalEnglish: String = "",
    val translatedHindi: String = "",
    val captureMode: String = "region",
    val favorite: Boolean = false,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

sealed interface CloudHistoryUiState {
    data object Loading : CloudHistoryUiState
    data class Success(val items: List<CloudTranslation>) : CloudHistoryUiState
    data class Error(val message: String) : CloudHistoryUiState
}
