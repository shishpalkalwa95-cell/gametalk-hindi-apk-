package com.example

import android.app.Application
import com.example.data.AppDatabase
import com.example.data.SettingsStore
import com.example.data.TranslationRepository
import com.example.engine.HindiSpeechManager
import com.example.engine.LiveTranslatorController
import com.example.engine.OcrProcessor
import com.example.engine.PermissionManager
import com.example.engine.TranslationManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch

class AppContainer(application: Application) {
    val appScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    val database: AppDatabase = AppDatabase.getInstance(application)
    val settingsStore: SettingsStore = SettingsStore(application)
    val repository: TranslationRepository = TranslationRepository(
        translationDao = database.translationDao(),
        settingsStore = settingsStore
    )
    val permissionManager: PermissionManager = PermissionManager(application)
    val firestoreRepository: com.example.firebase.FirestoreSyncRepository =
        com.example.firebase.FirestoreSyncRepository(application)
    val ocrProcessor: OcrProcessor = OcrProcessor()
    val translationManager: TranslationManager = TranslationManager(permissionManager)
    val speechManager: HindiSpeechManager = HindiSpeechManager(application)
    val controller: LiveTranslatorController = LiveTranslatorController()

    init {
        speechManager.initialize()

        appScope.launch {
            translationManager.modelState.collect { state ->
                controller.updateModelState(state)
            }
        }
        appScope.launch {
            speechManager.voiceStatus.collect { voiceStatus ->
                controller.updateTtsStatus(voiceStatus)
            }
        }
        appScope.launch {
            combine(
                speechManager.isSpeaking,
                speechManager.queuedCount
            ) { speaking, queued -> speaking to queued }.collect { (speaking, queued) ->
                controller.updateSpeakingState(speaking, queued)
            }
        }
        appScope.launch {
            repository.settingsFlow.collect { settings ->
                speechManager.setTargetLanguage(settings.targetLanguage)
                speechManager.updateAudioConfig(
                    speed = settings.speechSpeed,
                    pitch = settings.speechPitch,
                    volume = settings.speechVolume,
                    muted = settings.isMuted || !settings.autoSpeak
                )
                translationManager.setTargetLanguage(settings.targetLanguage)
            }
        }
        appScope.launch {
            translationManager.checkModelDownloaded()
        }
    }
}

class GameTalkApplication : Application() {
    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        container = AppContainer(this)
    }
}
