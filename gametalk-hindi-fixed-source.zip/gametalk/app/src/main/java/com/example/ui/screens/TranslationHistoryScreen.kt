package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.outlined.StarBorder
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.firebase.CloudHistoryUiState
import com.example.firebase.CloudTranslation
import com.example.ui.i18n.LocalizedStrings
import com.example.ui.theme.ElectricPurple
import com.example.ui.theme.NavyBorder
import com.example.ui.theme.NavyCard
import com.example.ui.theme.NavyElevated
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NotoDevanagariFontFamily
import com.example.ui.theme.StatusErrorRose
import com.example.ui.theme.StatusIdleSlate
import com.example.ui.theme.StatusPausedAmber
import com.example.ui.theme.TextSecondaryLight
import com.google.firebase.Timestamp
import java.text.SimpleDateFormat
import java.util.Locale

@Composable
fun TranslationHistoryScreen(
    strings: LocalizedStrings,
    historyState: CloudHistoryUiState,
    onBackToDashboard: () -> Unit,
    onReplayHindi: (String) -> Unit,
    onToggleFavorite: (String, Boolean) -> Unit,
    onDeleteEntry: (String) -> Unit,
    onClearAllHistory: () -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler(onBack = onBackToDashboard)
    var showClearDialog by remember { mutableStateOf(false) }
    val clipboard = LocalClipboardManager.current

    val itemsList = (historyState as? CloudHistoryUiState.Success)?.items.orEmpty()

    if (showClearDialog) {
        AlertDialog(
            onDismissRequest = { showClearDialog = false },
            containerColor = NavyCard,
            title = { Text(strings.clearHistoryConfirmTitle) },
            text = { Text(strings.clearHistoryConfirmBody, color = TextSecondaryLight) },
            confirmButton = {
                TextButton(
                    onClick = {
                        showClearDialog = false
                        onClearAllHistory()
                    },
                    modifier = Modifier.testTag("confirm_clear_history_button")
                ) {
                    Text(strings.confirmClear, color = StatusErrorRose)
                }
            },
            dismissButton = {
                TextButton(onClick = { showClearDialog = false }) {
                    Text(strings.cancel)
                }
            }
        )
    }

    Box(
        modifier = modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 680.dp)
                .padding(horizontal = 16.dp, vertical = 12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "${strings.historyTitle} (${itemsList.size})",
                    style = MaterialTheme.typography.titleLarge
                )
                if (itemsList.isNotEmpty()) {
                    FilledTonalButton(
                        onClick = { showClearDialog = true },
                        modifier = Modifier.testTag("history_clear_all_button"),
                        colors = ButtonDefaults.filledTonalButtonColors(
                            containerColor = StatusErrorRose.copy(alpha = 0.18f),
                            contentColor = StatusErrorRose
                        )
                    ) {
                        Icon(Icons.Filled.DeleteSweep, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text(strings.clearHistory)
                    }
                }
            }

            Spacer(Modifier.height(12.dp))

            when (historyState) {
                CloudHistoryUiState.Loading -> {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator(color = NeonCyan)
                    }
                }

                is CloudHistoryUiState.Error -> {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF3A0C1B)),
                        border = BorderStroke(1.dp, StatusErrorRose),
                        shape = MaterialTheme.shapes.medium,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(16.dp),
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Filled.ErrorOutline, contentDescription = null, tint = StatusErrorRose)
                            Text(
                                text = historyState.message,
                                style = MaterialTheme.typography.bodyMedium,
                                color = Color(0xFFFFD6DF)
                            )
                        }
                    }
                }

                is CloudHistoryUiState.Success -> {
                    if (historyState.items.isEmpty()) {
                        Box(
                            modifier = Modifier.fillMaxSize(),
                            contentAlignment = Alignment.Center
                        ) {
                            Card(
                                colors = CardDefaults.cardColors(containerColor = NavyCard),
                                border = BorderStroke(1.dp, NavyBorder),
                                shape = MaterialTheme.shapes.large
                            ) {
                                Column(
                                    modifier = Modifier.padding(28.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Filled.History,
                                        contentDescription = null,
                                        tint = ElectricPurple,
                                        modifier = Modifier.size(48.dp)
                                    )
                                    Text(
                                        text = strings.emptyHistoryTitle,
                                        style = MaterialTheme.typography.titleMedium
                                    )
                                    Text(
                                        text = strings.emptyHistoryBody,
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = TextSecondaryLight
                                    )
                                }
                            }
                        }
                    } else {
                        LazyColumn(
                            contentPadding = PaddingValues(bottom = 24.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            items(historyState.items, key = { it.id }) { entry ->
                                HistoryEntryCard(
                                    entry = entry,
                                    strings = strings,
                                    onReplay = { onReplayHindi(entry.translatedHindi) },
                                    onToggleFavorite = { onToggleFavorite(entry.id, !entry.favorite) },
                                    onCopy = {
                                        clipboard.setText(
                                            AnnotatedString("${entry.translatedHindi}\n(${entry.originalEnglish})")
                                        )
                                    },
                                    onDelete = { onDeleteEntry(entry.id) }
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun HistoryEntryCard(
    entry: CloudTranslation,
    strings: LocalizedStrings,
    onReplay: () -> Unit,
    onToggleFavorite: () -> Unit,
    onCopy: () -> Unit,
    onDelete: () -> Unit
) {
    val formatter = remember { SimpleDateFormat("dd MMM, hh:mm:ss a", Locale.getDefault()) }
    val displayTs = entry.updatedAt ?: entry.createdAt ?: Timestamp.now()
    val timestampStr = formatter.format(displayTs.toDate())

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("history_card_${entry.id}"),
        shape = MaterialTheme.shapes.large,
        colors = CardDefaults.cardColors(containerColor = NavyCard),
        border = BorderStroke(1.dp, if (entry.favorite) StatusPausedAmber.copy(alpha = 0.7f) else NavyBorder)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    color = NavyElevated,
                    shape = RoundedCornerShape(50)
                ) {
                    Text(
                        text = if (entry.captureMode == "region") strings.customRegionMode else strings.fullScreenMode,
                        style = MaterialTheme.typography.labelSmall,
                        color = NeonCyan,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                    )
                }
                Text(
                    text = timestampStr,
                    style = MaterialTheme.typography.labelSmall,
                    color = StatusIdleSlate
                )
            }

            Text(
                text = entry.translatedHindi,
                fontFamily = NotoDevanagariFontFamily,
                fontSize = 19.sp,
                lineHeight = 28.sp,
                fontWeight = FontWeight.SemiBold,
                color = Color.White
            )

            Surface(
                color = NavyElevated,
                shape = MaterialTheme.shapes.small,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = entry.originalEnglish,
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondaryLight,
                    modifier = Modifier.padding(10.dp)
                )
            }

            HorizontalDivider(color = NavyBorder.copy(alpha = 0.5f))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                FilledTonalButton(
                    onClick = onReplay,
                    modifier = Modifier.testTag("history_replay_${entry.id}"),
                    colors = ButtonDefaults.filledTonalButtonColors(
                        containerColor = NeonCyan.copy(alpha = 0.16f),
                        contentColor = NeonCyan
                    )
                ) {
                    Icon(Icons.AutoMirrored.Filled.VolumeUp, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text(strings.replayHindi)
                }

                Row {
                    IconButton(
                        onClick = onToggleFavorite,
                        modifier = Modifier.testTag("history_favorite_${entry.id}")
                    ) {
                        Icon(
                            imageVector = if (entry.favorite) Icons.Filled.Star else Icons.Outlined.StarBorder,
                            contentDescription = "Favorite",
                            tint = if (entry.favorite) StatusPausedAmber else TextSecondaryLight
                        )
                    }
                    IconButton(onClick = onCopy) {
                        Icon(
                            imageVector = Icons.Filled.ContentCopy,
                            contentDescription = "Copy",
                            tint = TextSecondaryLight
                        )
                    }
                    IconButton(
                        onClick = onDelete,
                        modifier = Modifier.testTag("history_delete_${entry.id}")
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Delete,
                            contentDescription = strings.deleteEntry,
                            tint = StatusErrorRose
                        )
                    }
                }
            }
        }
    }
}
