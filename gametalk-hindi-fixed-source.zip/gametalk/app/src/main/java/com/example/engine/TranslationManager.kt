package com.example.engine

import android.util.Log
import com.example.data.ModelDownloadState
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.common.model.RemoteModelManager
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.TranslateRemoteModel
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.tasks.await

/**
 * Pure preprocessing & postprocessing helper for game dialogue translation:
 * preserves character speaker prefixes ("Kratos: Stay behind me!") and common gaming acronyms.
 */
object GameDialogueFormatter {
    private val SPEAKER_PREFIX_REGEX = Regex("^([A-Z][A-Za-z0-9'\\- ]{1,22}):\\s+(.+)$")

    data class SplitSpeaker(val speakerPrefix: String?, val dialogueBody: String)

    fun extractSpeakerPrefix(line: String): SplitSpeaker {
        val match = SPEAKER_PREFIX_REGEX.matchEntire(line.trim()) ?: return SplitSpeaker(null, line.trim())
        val name = match.groupValues[1].trim()
        val body = match.groupValues[2].trim()
        // Avoid splitting common non-speaker labels like "Note:" or "Warning:"
        val nonSpeakerWords = setOf("Note", "Tip", "Warning", "Objective", "Mission", "Quest", "Hint")
        return if (name in nonSpeakerWords || name.split(" ").size > 3) {
            SplitSpeaker(null, line.trim())
        } else {
            SplitSpeaker(name, body)
        }
    }

    fun formatCombined(speakerPrefix: String?, translatedBody: String): String {
        val cleanBody = translatedBody.trim()
        return if (!speakerPrefix.isNullOrBlank()) {
            "$speakerPrefix: $cleanBody"
        } else {
            cleanBody
        }
    }
}

sealed interface TranslationResult {
    data class Success(val hindiText: String, val fromCache: Boolean) : TranslationResult
    data class Failure(val messageHi: String, val messageEn: String) : TranslationResult
}

class TranslationManager(
    private val permissionManager: PermissionManager
) {
    private val _modelState = MutableStateFlow<ModelDownloadState>(ModelDownloadState.NotChecked)
    val modelState: StateFlow<ModelDownloadState> = _modelState.asStateFlow()

    private val mutex = Mutex()
    private var translator: Translator? = null

    private val cacheLock = Any()
    private val translationCache = object : LinkedHashMap<String, String>(160, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, String>?): Boolean {
            return size > MAX_CACHE_SIZE
        }
    }

    private fun getOrCreateTranslator(): Translator {
        return translator ?: Translation.getClient(
            TranslatorOptions.Builder()
                .setSourceLanguage(TranslateLanguage.ENGLISH)
                .setTargetLanguage(TranslateLanguage.HINDI)
                .build()
        ).also { translator = it }
    }

    suspend fun checkModelDownloaded(): Boolean = mutex.withLock {
        _modelState.value = ModelDownloadState.Checking
        return try {
            val hindiModel = TranslateRemoteModel.Builder(TranslateLanguage.HINDI).build()
            val downloaded = RemoteModelManager.getInstance()
                .isModelDownloaded(hindiModel)
                .await()
            _modelState.value = if (downloaded) {
                ModelDownloadState.Downloaded
            } else {
                ModelDownloadState.NotChecked
            }
            downloaded
        } catch (t: Throwable) {
            Log.e(TAG, "Failed checking Hindi translation model", t)
            _modelState.value = ModelDownloadState.Error(
                messageHi = "ऑफ़लाइन हिंदी मॉडल की स्थिति जाँची नहीं जा सकी।",
                messageEn = "Could not check offline Hindi model status."
            )
            false
        }
    }

    suspend fun ensureModelDownloaded(): Boolean = mutex.withLock {
        try {
            val hindiModel = TranslateRemoteModel.Builder(TranslateLanguage.HINDI).build()
            val alreadyDownloaded = RemoteModelManager.getInstance()
                .isModelDownloaded(hindiModel)
                .await()
            if (alreadyDownloaded) {
                _modelState.value = ModelDownloadState.Downloaded
                return true
            }

            if (!permissionManager.isNetworkAvailable()) {
                _modelState.value = ModelDownloadState.Error(
                    messageHi = "हिंदी अनुवाद मॉडल डाउनलोड करने के लिए इंटरनेट कनेक्शन आवश्यक है। एक बार डाउनलोड होने के बाद यह ऑफ़लाइन काम करेगा।",
                    messageEn = "Internet connection is required once to download the English-Hindi model. After download, translation works offline."
                )
                return false
            }

            _modelState.value = ModelDownloadState.Downloading
            val conditions = DownloadConditions.Builder().build()
            getOrCreateTranslator().downloadModelIfNeeded(conditions).await()
            _modelState.value = ModelDownloadState.Downloaded
            true
        } catch (t: Throwable) {
            Log.e(TAG, "Model download failed", t)
            _modelState.value = ModelDownloadState.Error(
                messageHi = "ऑफ़लाइन हिंदी मॉडल डाउनलोड नहीं हो सका। कृपया इंटरनेट जाँचें और फिर प्रयास करें।",
                messageEn = "Failed to download offline Hindi translation model. Check internet connection and try again."
            )
            false
        }
    }

    suspend fun translateEnglishToHindi(englishText: String): TranslationResult {
        val cleanInput = englishText.trim()
        if (cleanInput.isEmpty()) {
            return TranslationResult.Failure(
                messageHi = "अनुवाद के लिए कोई टेक्स्ट नहीं मिला।",
                messageEn = "No text found to translate."
            )
        }

        val cacheKey = DialogueDeduplicator.normalizeForComparison(cleanInput)
        synchronized(cacheLock) {
            translationCache[cacheKey]?.let { cached ->
                return TranslationResult.Success(hindiText = cached, fromCache = true)
            }
        }

        val ready = if (_modelState.value is ModelDownloadState.Downloaded) {
            true
        } else {
            ensureModelDownloaded()
        }

        if (!ready) {
            val err = _modelState.value as? ModelDownloadState.Error
            return TranslationResult.Failure(
                messageHi = err?.messageHi ?: "ऑफ़लाइन हिंदी मॉडल उपलब्ध नहीं है।",
                messageEn = err?.messageEn ?: "Offline Hindi model is not downloaded."
            )
        }

        return try {
            val client = getOrCreateTranslator()
            val translatedLines = cleanInput.lines()
                .map { it.trim() }
                .filter { it.isNotEmpty() }
                .map { line ->
                    val split = GameDialogueFormatter.extractSpeakerPrefix(line)
                    val translatedBody = client.translate(split.dialogueBody).await()
                    GameDialogueFormatter.formatCombined(split.speakerPrefix, translatedBody)
                }

            val finalHindi = translatedLines.joinToString("\n").trim()
            if (finalHindi.isEmpty()) {
                TranslationResult.Failure(
                    messageHi = "हिंदी अनुवाद खाली प्राप्त हुआ।",
                    messageEn = "Received empty Hindi translation."
                )
            } else {
                synchronized(cacheLock) {
                    translationCache[cacheKey] = finalHindi
                }
                TranslationResult.Success(hindiText = finalHindi, fromCache = false)
            }
        } catch (t: Throwable) {
            Log.e(TAG, "Translation failed", t)
            TranslationResult.Failure(
                messageHi = "ऑन-डिवाइस अनुवाद विफल रहा। कृपया मॉडल स्थिति जाँचें।",
                messageEn = "On-device translation failed. Please check model status."
            )
        }
    }

    fun clearCache() {
        synchronized(cacheLock) {
            translationCache.clear()
        }
    }

    fun close() {
        try {
            translator?.close()
        } catch (_: Throwable) {
        } finally {
            translator = null
        }
    }

    companion object {
        private const val TAG = "TranslationManager"
        private const val MAX_CACHE_SIZE = 150
    }
}
