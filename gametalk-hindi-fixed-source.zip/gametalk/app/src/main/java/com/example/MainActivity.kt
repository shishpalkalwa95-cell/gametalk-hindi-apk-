package com.example

import android.Manifest
import android.app.Activity
import android.graphics.Color as AndroidColor
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.NavigationRailItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.credentials.CredentialManager
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.ViewModelProvider.AndroidViewModelFactory.Companion.APPLICATION_KEY
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.example.data.AppSettings
import com.example.data.UiLanguage
import com.example.firebase.CloudHistoryUiState
import com.example.firebase.FirestoreSyncRepository
import com.example.firebase.authStateFlow
import com.example.firebase.signOutUser
import com.example.ui.i18n.AppStrings
import com.example.ui.screens.AuthScreen
import com.example.ui.screens.DashboardScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.TranslationHistoryScreen
import com.example.ui.theme.DeepNavy
import com.example.ui.theme.ElectricPurple
import com.example.ui.theme.GameTalkHindiTheme
import com.example.ui.theme.NavyBorder
import com.example.ui.theme.NavyCard
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.TextSecondaryLight
import com.example.ui.viewmodel.MainViewModel
import com.google.firebase.Firebase
import com.google.firebase.auth.auth
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.launch

private enum class AppTab {
    DASHBOARD,
    HISTORY,
    SETTINGS
}

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(AndroidColor.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(AndroidColor.TRANSPARENT)
        )

        setContent {
            GameTalkHindiTheme {
                GameTalkAuthGate(
                    onLaunchExternalIntent = { intent ->
                        runCatching { startActivity(intent) }
                    }
                )
            }
        }
    }
}

/**
 * Root auth-gated navigation. Feature ViewModels and Firestore snapshot listeners
 * are never instantiated until the user completes Google Sign-In via Credential Manager.
 */
@Composable
private fun GameTalkAuthGate(
    onLaunchExternalIntent: (android.content.Intent) -> Unit
) {
    val context = LocalContext.current
    val app = context.applicationContext as GameTalkApplication
    val scope = rememberCoroutineScope()

    val currentUser by remember { Firebase.auth.authStateFlow() }
        .collectAsStateWithLifecycle(initialValue = Firebase.auth.currentUser)

    val settings by app.container.repository.settingsFlow
        .collectAsStateWithLifecycle(initialValue = AppSettings())

    val user = currentUser
    if (user == null) {
        AuthScreen(
            uiLanguage = settings.uiLanguage,
            onToggleLanguage = {
                scope.launch {
                    app.container.repository.updateSettings { current ->
                        val next = if (current.uiLanguage == UiLanguage.HINDI) {
                            UiLanguage.ENGLISH
                        } else {
                            UiLanguage.HINDI
                        }
                        current.copy(uiLanguage = next)
                    }
                }
            },
            onAuthSuccess = { /* AuthStateListener drives transition automatically */ }
        )
    } else {
        val uid = user.uid
        val displayName = user.displayName?.takeIf { it.isNotBlank() } ?: "Gamer"
        // Key composition and ViewModel by uid so signing out or switching accounts
        // tears down old Firestore snapshot listeners cleanly.
        key(uid) {
            val viewModel: MainViewModel = viewModel(
                key = uid,
                factory = viewModelFactory {
                    initializer {
                        val application = checkNotNull(this[APPLICATION_KEY]) as GameTalkApplication
                        val databaseId = application.getString(R.string.firestore_database_id)
                        val db = FirebaseFirestore.getInstance(databaseId)
                        val firestoreRepo = FirestoreSyncRepository(db)
                        MainViewModel(
                            app = application,
                            firestoreRepository = firestoreRepo,
                            currentUserId = uid,
                            userDisplayName = displayName
                        )
                    }
                }
            )
            GameTalkAppRoot(
                viewModel = viewModel,
                onLaunchExternalIntent = onLaunchExternalIntent
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun GameTalkAppRoot(
    viewModel: MainViewModel,
    onLaunchExternalIntent: (android.content.Intent) -> Unit
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val scope = rememberCoroutineScope()
    val credentialManager = remember(context) { CredentialManager.create(context) }

    DisposableEffect(lifecycleOwner, viewModel) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                viewModel.refreshPermissionsAndEngines()
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    val settings by viewModel.settings.collectAsStateWithLifecycle()
    val session by viewModel.sessionState.collectAsStateWithLifecycle()
    val cloudHistoryState by viewModel.cloudHistoryState.collectAsStateWithLifecycle()
    val hasOverlayPermission by viewModel.hasOverlayPermission.collectAsStateWithLifecycle()
    val hasNotificationPermission by viewModel.hasNotificationPermission.collectAsStateWithLifecycle()
    val isTestingVoice by viewModel.isTestingVoice.collectAsStateWithLifecycle()

    val recentCloudHistory = (cloudHistoryState as? CloudHistoryUiState.Success)?.items.orEmpty()
    val strings = AppStrings.forLanguage(settings.uiLanguage)
    var currentTab by rememberSaveable { mutableStateOf(AppTab.DASHBOARD) }

    // Official Android MediaProjection system consent dialog launcher (requested every new session)
    val mediaProjectionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val data = result.data
        if (result.resultCode == Activity.RESULT_OK && data != null) {
            viewModel.onMediaProjectionGranted(result.resultCode, data)
        } else {
            viewModel.onMediaProjectionDenied()
        }
    }

    // Android 13+ POST_NOTIFICATIONS runtime permission launcher
    val notificationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        viewModel.onNotificationPermissionResult(granted)
    }

    val requestStartCapture: () -> Unit = {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU && !hasNotificationPermission) {
            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        val captureIntent = viewModel.createScreenCaptureIntent()
        if (captureIntent != null) {
            mediaProjectionLauncher.launch(captureIntent)
        } else {
            viewModel.onMediaProjectionDenied()
        }
    }

    val requestOverlaySettings: () -> Unit = {
        onLaunchExternalIntent(viewModel.createOverlayPermissionIntent())
    }

    val requestNotificationPerm: () -> Unit = {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    val openInstallHindiVoice: () -> Unit = {
        onLaunchExternalIntent(viewModel.createInstallHindiTtsIntent())
    }

    BoxWithConstraints(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianBlack)
    ) {
        val useNavigationRail = maxWidth >= 600.dp

        Scaffold(
            modifier = Modifier.fillMaxSize(),
            containerColor = ObsidianBlack,
            contentWindowInsets = WindowInsets.safeDrawing,
            topBar = {
                TopAppBar(
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = DeepNavy,
                        titleContentColor = MaterialTheme.colorScheme.onSurface
                    ),
                    title = {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Image(
                                painter = painterResource(id = R.drawable.ic_gametalk_foreground_1795616329537),
                                contentDescription = stringResource(id = R.string.cd_app_logo),
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(RoundedCornerShape(10.dp))
                            )
                            Column {
                                Text(
                                    text = strings.appTitle,
                                    style = MaterialTheme.typography.titleLarge
                                )
                                Text(
                                    text = strings.appSubtitle,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = NeonCyan
                                )
                            }
                        }
                    },
                    actions = {
                        Surface(
                            onClick = { viewModel.toggleUiLanguage() },
                            shape = RoundedCornerShape(50),
                            color = NavyCard,
                            border = BorderStroke(1.dp, ElectricPurple.copy(alpha = 0.7f)),
                            modifier = Modifier
                                .padding(end = 4.dp)
                                .testTag("language_toggle_button")
                        ) {
                            Text(
                                text = if (settings.uiLanguage == UiLanguage.HINDI) "हिंदी / EN" else "EN / हिंदी",
                                style = MaterialTheme.typography.labelMedium,
                                color = ElectricPurple,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp)
                            )
                        }
                        IconButton(
                            onClick = {
                                signOutUser(
                                    credentialManager = credentialManager,
                                    scope = scope,
                                    beforeSignOut = { viewModel.stopTranslation() }
                                )
                            },
                            modifier = Modifier.testTag("sign_out_button")
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.Logout,
                                contentDescription = if (settings.uiLanguage == UiLanguage.HINDI) "साइन आउट" else "Sign out",
                                tint = TextSecondaryLight
                            )
                        }
                    }
                )
            },
            bottomBar = {
                if (!useNavigationRail) {
                    NavigationBar(
                        containerColor = DeepNavy,
                        tonalElevation = 0.dp
                    ) {
                        NavigationBarItem(
                            selected = currentTab == AppTab.DASHBOARD,
                            onClick = { currentTab = AppTab.DASHBOARD },
                            icon = { Icon(Icons.Filled.Dashboard, contentDescription = strings.navDashboard) },
                            label = { Text(strings.navDashboard) },
                            modifier = Modifier.testTag("nav_dashboard"),
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = ObsidianBlack,
                                selectedTextColor = NeonCyan,
                                indicatorColor = NeonCyan,
                                unselectedIconColor = TextSecondaryLight,
                                unselectedTextColor = TextSecondaryLight
                            )
                        )
                        NavigationBarItem(
                            selected = currentTab == AppTab.HISTORY,
                            onClick = { currentTab = AppTab.HISTORY },
                            icon = { Icon(Icons.Filled.History, contentDescription = strings.navHistory) },
                            label = { Text(strings.navHistory) },
                            modifier = Modifier.testTag("nav_history"),
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = ObsidianBlack,
                                selectedTextColor = NeonCyan,
                                indicatorColor = NeonCyan,
                                unselectedIconColor = TextSecondaryLight,
                                unselectedTextColor = TextSecondaryLight
                            )
                        )
                        NavigationBarItem(
                            selected = currentTab == AppTab.SETTINGS,
                            onClick = { currentTab = AppTab.SETTINGS },
                            icon = { Icon(Icons.Filled.Settings, contentDescription = strings.navSettings) },
                            label = { Text(strings.navSettings) },
                            modifier = Modifier.testTag("nav_settings"),
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = ObsidianBlack,
                                selectedTextColor = NeonCyan,
                                indicatorColor = NeonCyan,
                                unselectedIconColor = TextSecondaryLight,
                                unselectedTextColor = TextSecondaryLight
                            )
                        )
                    }
                }
            }
        ) { innerPadding ->
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                if (useNavigationRail) {
                    NavigationRail(
                        containerColor = DeepNavy,
                        modifier = Modifier.fillMaxHeight()
                    ) {
                        Spacer(Modifier.size(12.dp))
                        NavigationRailItem(
                            selected = currentTab == AppTab.DASHBOARD,
                            onClick = { currentTab = AppTab.DASHBOARD },
                            icon = { Icon(Icons.Filled.Dashboard, contentDescription = strings.navDashboard) },
                            label = { Text(strings.navDashboard) },
                            colors = NavigationRailItemDefaults.colors(
                                selectedIconColor = ObsidianBlack,
                                selectedTextColor = NeonCyan,
                                indicatorColor = NeonCyan
                            )
                        )
                        NavigationRailItem(
                            selected = currentTab == AppTab.HISTORY,
                            onClick = { currentTab = AppTab.HISTORY },
                            icon = { Icon(Icons.Filled.History, contentDescription = strings.navHistory) },
                            label = { Text(strings.navHistory) },
                            colors = NavigationRailItemDefaults.colors(
                                selectedIconColor = ObsidianBlack,
                                selectedTextColor = NeonCyan,
                                indicatorColor = NeonCyan
                            )
                        )
                        NavigationRailItem(
                            selected = currentTab == AppTab.SETTINGS,
                            onClick = { currentTab = AppTab.SETTINGS },
                            icon = { Icon(Icons.Filled.Settings, contentDescription = strings.navSettings) },
                            label = { Text(strings.navSettings) },
                            colors = NavigationRailItemDefaults.colors(
                                selectedIconColor = ObsidianBlack,
                                selectedTextColor = NeonCyan,
                                indicatorColor = NeonCyan
                            )
                        )
                    }
                    Spacer(
                        modifier = Modifier
                            .width(1.dp)
                            .fillMaxHeight()
                            .background(NavyBorder)
                    )
                }

                when (currentTab) {
                    AppTab.DASHBOARD -> DashboardScreen(
                        strings = strings,
                        settings = settings,
                        session = session,
                        history = recentCloudHistory,
                        hasOverlayPermission = hasOverlayPermission,
                        hasNotificationPermission = hasNotificationPermission,
                        isTestingVoice = isTestingVoice,
                        onStartCaptureClick = requestStartCapture,
                        onStopCaptureClick = { viewModel.stopTranslation() },
                        onPauseClick = { viewModel.pauseTranslation() },
                        onResumeClick = { viewModel.resumeTranslation() },
                        onReadNowClick = { viewModel.triggerReadNow() },
                        onReadAgainClick = { viewModel.readAgain() },
                        onStopSpeakingClick = { viewModel.stopSpeaking() },
                        onToggleFloatingOverlay = { enabled ->
                            if (!viewModel.setFloatingOverlayEnabled(enabled) && enabled) {
                                requestOverlaySettings()
                            }
                        },
                        onToggleSubtitleOverlay = { viewModel.setSubtitleOverlayEnabled(it) },
                        onToggleShowRegionBox = { show ->
                            if (!viewModel.setShowRegionBorder(show) && show) {
                                requestOverlaySettings()
                            }
                        },
                        onToggleLockRegion = { viewModel.setRegionLocked(it) },
                        onToggleCustomRegionMode = { viewModel.setCustomRegionEnabled(it) },
                        onSpeechSpeedChange = { viewModel.updateSpeechSpeed(it) },
                        onSpeechVolumeChange = { viewModel.updateSpeechVolume(it) },
                        onToggleMute = { viewModel.setMuted(it) },
                        onRequestOverlayPermission = requestOverlaySettings,
                        onRequestNotificationPermission = requestNotificationPerm,
                        onDownloadHindiModel = { viewModel.downloadHindiModel() },
                        onOpenInstallHindiVoice = openInstallHindiVoice,
                        onTestHindiVoice = { viewModel.runLiveVoiceAndTranslationTest() },
                        onReplayHistoryItem = { viewModel.replayHindiText(it) },
                        onClearHistory = { viewModel.clearAllHistory() },
                        onOpenFullHistory = { currentTab = AppTab.HISTORY },
                        onOpenSettings = { currentTab = AppTab.SETTINGS },
                        onDismissError = { viewModel.clearError() }
                    )

                    AppTab.HISTORY -> TranslationHistoryScreen(
                        strings = strings,
                        historyState = cloudHistoryState,
                        onBackToDashboard = { currentTab = AppTab.DASHBOARD },
                        onReplayHindi = { viewModel.replayHindiText(it) },
                        onToggleFavorite = { id, fav -> viewModel.toggleFavoriteTranslation(id, fav) },
                        onDeleteEntry = { viewModel.deleteHistoryItem(it) },
                        onClearAllHistory = { viewModel.clearAllHistory() }
                    )

                    AppTab.SETTINGS -> SettingsScreen(
                        strings = strings,
                        settings = settings,
                        modelState = session.modelState,
                        ttsStatus = session.ttsStatus,
                        isTestingVoice = isTestingVoice,
                        onBackToDashboard = { currentTab = AppTab.DASHBOARD },
                        onSetCustomRegionEnabled = { viewModel.setCustomRegionEnabled(it) },
                        onSetShowRegionBorder = { show ->
                            if (!viewModel.setShowRegionBorder(show) && show) {
                                requestOverlaySettings()
                            }
                        },
                        onSetRegionLocked = { viewModel.setRegionLocked(it) },
                        onSetDimOutside = { viewModel.setDimOutsideRegion(it) },
                        onResetRegion = { viewModel.resetReadingRegion() },
                        onSetFloatingOverlayEnabled = { enabled ->
                            if (!viewModel.setFloatingOverlayEnabled(enabled) && enabled) {
                                requestOverlaySettings()
                            }
                        },
                        onSetSubtitleOverlayEnabled = { viewModel.setSubtitleOverlayEnabled(it) },
                        onUpdateFloatingOpacity = { viewModel.updateFloatingButtonOpacity(it) },
                        onUpdateFloatingSizeDp = { viewModel.updateFloatingButtonSizeDp(it) },
                        onUpdateOcrIntervalMs = { viewModel.updateOcrInterval(it) },
                        onUpdateSpeechSpeed = { viewModel.updateSpeechSpeed(it) },
                        onUpdateSpeechPitch = { viewModel.updateSpeechPitch(it) },
                        onUpdateSpeechVolume = { viewModel.updateSpeechVolume(it) },
                        onSetMuted = { viewModel.setMuted(it) },
                        onSetAutoSpeak = { viewModel.setAutoSpeak(it) },
                        onTestHindiVoice = { viewModel.runLiveVoiceAndTranslationTest() },
                        onOpenInstallHindiVoice = openInstallHindiVoice,
                        onDownloadHindiModel = { viewModel.downloadHindiModel() },
                        onSetUiLanguage = { viewModel.setUiLanguage(it) }
                    )
                }
            }
        }
    }
}
