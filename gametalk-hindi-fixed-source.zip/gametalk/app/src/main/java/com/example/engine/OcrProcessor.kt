package com.example.engine

import android.graphics.Bitmap
import android.util.Log
import com.example.data.ReadingRegion
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.Text
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.TextRecognizer
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.tasks.await
import kotlin.math.abs
import kotlin.math.max

/**
 * Pure text normalization, noise filtering, and duplicate dialogue suppression engine.
 * Extracted cleanly so both live ML Kit OCR and JVM unit tests exercise identical logic.
 */
class DialogueDeduplicator(
    private val duplicateWindowMs: Long = 8_000L,
    private val similarityThreshold: Float = 0.86f
) {
    private var lastNormalized: String = ""
    private var lastAcceptedAtMs: Long = 0L

    @Synchronized
    fun reset() {
        lastNormalized = ""
        lastAcceptedAtMs = 0L
    }

    @Synchronized
    fun shouldProcess(rawText: String, nowMs: Long = System.currentTimeMillis(), force: Boolean = false): Boolean {
        val cleaned = cleanDialogueText(rawText)
        if (!isValidGameDialogue(cleaned)) return false
        val normalized = normalizeForComparison(cleaned)
        if (normalized.length < 2) return false

        if (force) {
            lastNormalized = normalized
            lastAcceptedAtMs = nowMs
            return true
        }

        if (lastNormalized.isNotEmpty()) {
            if (normalized == lastNormalized && (nowMs - lastAcceptedAtMs) < duplicateWindowMs) {
                return false
            }
            val similarity = computeSimilarity(normalized, lastNormalized)
            if (similarity >= similarityThreshold && (nowMs - lastAcceptedAtMs) < duplicateWindowMs) {
                return false
            }
        }

        lastNormalized = normalized
        lastAcceptedAtMs = nowMs
        return true
    }

    companion object {
        private val PURE_HUD_REGEX = Regex(
            "^([0-9:/.,%+-]+|\\d+\\s*(fps|ms|ping|hp|mp|xp|lv|lvl))$",
            RegexOption.IGNORE_CASE
        )
        private val MULTI_SPACE_REGEX = Regex("[ \\t]{2,}")
        private val LETTER_REGEX = Regex("[A-Za-z]")

        fun cleanDialogueText(raw: String): String {
            return raw
                .replace("\r\n", "\n")
                .replace('\r', '\n')
                .lines()
                .map { line -> line.trim().replace(MULTI_SPACE_REGEX, " ") }
                .filter { it.isNotEmpty() }
                .joinToString("\n")
                .trim()
        }

        fun isValidGameDialogue(cleanedText: String): Boolean {
            if (cleanedText.length < 3) return false
            if (PURE_HUD_REGEX.matches(cleanedText)) return false
            val letterCount = LETTER_REGEX.findAll(cleanedText).count()
            if (letterCount < 2) return false
            val ratio = letterCount.toFloat() / cleanedText.length.toFloat()
            return ratio >= 0.35f
        }

        fun normalizeForComparison(text: String): String {
            return text
                .lowercase()
                .replace(Regex("[^a-z0-9\\s]"), "")
                .replace(Regex("\\s+"), " ")
                .trim()
        }

        fun computeSimilarity(a: String, b: String): Float {
            if (a == b) return 1f
            val maxLen = max(a.length, b.length)
            if (maxLen == 0) return 1f
            val distance = levenshteinDistance(a, b)
            return (1f - distance.toFloat() / maxLen.toFloat()).coerceIn(0f, 1f)
        }

        private fun levenshteinDistance(a: String, b: String): Int {
            if (a.isEmpty()) return b.length
            if (b.isEmpty()) return a.length
            val prev = IntArray(b.length + 1) { it }
            val curr = IntArray(b.length + 1)
            for (i in 1..a.length) {
                curr[0] = i
                for (j in 1..b.length) {
                    val cost = if (a[i - 1] == b[j - 1]) 0 else 1
                    curr[j] = minOf(
                        curr[j - 1] + 1,
                        prev[j] + 1,
                        prev[j - 1] + cost
                    )
                }
                System.arraycopy(curr, 0, prev, 0, prev.size)
            }
            return prev[b.length]
        }
    }
}

sealed interface OcrResult {
    data object UnchangedFrame : OcrResult
    data object EmptyOrNoise : OcrResult
    data object DuplicateSuppressed : OcrResult
    data class NewDialogue(val text: String) : OcrResult
    data class Failure(val throwable: Throwable) : OcrResult
}

class OcrProcessor(
    private val deduplicator: DialogueDeduplicator = DialogueDeduplicator()
) {
    private var recognizer: TextRecognizer? = null
    private var lastFrameSignature: Long = Long.MIN_VALUE

    private fun getOrCreateRecognizer(): TextRecognizer {
        return recognizer ?: TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
            .also { recognizer = it }
    }

    fun resetState() {
        lastFrameSignature = Long.MIN_VALUE
        deduplicator.reset()
    }

    suspend fun processBitmap(
        fullFrame: Bitmap,
        customRegionEnabled: Boolean,
        readingRegion: ReadingRegion,
        forceRead: Boolean = false
    ): OcrResult {
        if (fullFrame.isRecycled || fullFrame.width <= 0 || fullFrame.height <= 0) {
            return OcrResult.EmptyOrNoise
        }

        var croppedBitmap: Bitmap? = null
        return try {
            val targetBitmap = if (customRegionEnabled) {
                val rect = readingRegion.toBitmapPixelRect(fullFrame.width, fullFrame.height)
                if (rect.width <= 2 || rect.height <= 2) {
                    return OcrResult.EmptyOrNoise
                }
                Bitmap.createBitmap(
                    fullFrame,
                    rect.left,
                    rect.top,
                    rect.width,
                    rect.height
                ).also { croppedBitmap = it }
            } else {
                fullFrame
            }

            val signature = computeFrameSignature(targetBitmap)
            if (!forceRead && signature == lastFrameSignature) {
                return OcrResult.UnchangedFrame
            }
            lastFrameSignature = signature

            val inputImage = InputImage.fromBitmap(targetBitmap, 0)
            val visionText = getOrCreateRecognizer().process(inputImage).await()
            val orderedDialogue = extractOrderedDialogue(visionText)
            val cleaned = DialogueDeduplicator.cleanDialogueText(orderedDialogue)

            if (!DialogueDeduplicator.isValidGameDialogue(cleaned)) {
                return OcrResult.EmptyOrNoise
            }

            if (!deduplicator.shouldProcess(cleaned, force = forceRead)) {
                return OcrResult.DuplicateSuppressed
            }

            OcrResult.NewDialogue(cleaned)
        } catch (t: Throwable) {
            Log.e(TAG, "OCR processing failed", t)
            OcrResult.Failure(t)
        } finally {
            croppedBitmap?.let {
                if (!it.isRecycled) it.recycle()
            }
        }
    }

    /**
     * Sorts ML Kit lines into natural top-to-bottom, left-to-right reading order and merges
     * lines belonging to the same visual row so multi-line game subtitles read naturally.
     */
    private fun extractOrderedDialogue(visionText: Text): String {
        val lines = visionText.textBlocks
            .flatMap { it.lines }
            .filter { it.text.isNotBlank() }

        if (lines.isEmpty()) return ""

        val sorted = lines.sortedWith(
            compareBy<Text.Line>(
                { it.boundingBox?.top ?: Int.MAX_VALUE },
                { it.boundingBox?.left ?: Int.MAX_VALUE }
            )
        )

        val rows = mutableListOf<MutableList<Text.Line>>()
        for (line in sorted) {
            val lineBox = line.boundingBox
            if (rows.isEmpty() || lineBox == null) {
                rows.add(mutableListOf(line))
            } else {
                val lastRow = rows.last()
                val refBox = lastRow.first().boundingBox
                val tolerance = ((refBox?.height() ?: 24) * 0.6f).toInt().coerceAtLeast(12)
                if (refBox != null && abs(lineBox.centerY() - refBox.centerY()) <= tolerance) {
                    lastRow.add(line)
                } else {
                    rows.add(mutableListOf(line))
                }
            }
        }

        return rows.joinToString("\n") { row ->
            row.sortedBy { it.boundingBox?.left ?: 0 }
                .joinToString(" ") { it.text.trim() }
        }
    }

    /**
     * Computes a fast coarse quantized luminance fingerprint over an 8x8 sample grid.
     * Skips running ML Kit when the subtitle area has not visually changed.
     */
    fun computeFrameSignature(bitmap: Bitmap): Long {
        val w = bitmap.width
        val h = bitmap.height
        if (w <= 0 || h <= 0) return 0L
        var hash = 1125899906842597L
        val stepX = (w / 8).coerceAtLeast(1)
        val stepY = (h / 8).coerceAtLeast(1)
        var y = stepY / 2
        while (y < h) {
            var x = stepX / 2
            while (x < w) {
                val pixel = bitmap.getPixel(x, y)
                val r = (pixel shr 16) and 0xFF
                val g = (pixel shr 8) and 0xFF
                val b = pixel and 0xFF
                // Quantize luminance to 16 buckets so tiny compression jitter is ignored
                val lumaBucket = ((r * 3 + g * 6 + b) / 10) shr 4
                hash = 31L * hash + lumaBucket
                x += stepX
            }
            y += stepY
        }
        return hash
    }

    fun close() {
        try {
            recognizer?.close()
        } catch (_: Throwable) {
        } finally {
            recognizer = null
        }
    }

    companion object {
        private const val TAG = "OcrProcessor"
    }
}
