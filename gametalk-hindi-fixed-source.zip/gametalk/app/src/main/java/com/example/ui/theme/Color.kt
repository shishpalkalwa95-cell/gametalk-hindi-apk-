package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Deep obsidian & dark navy gaming palette
val ObsidianBlack = Color(0xFF070A14)
val DeepNavy = Color(0xFF0D1326)
val NavyCard = Color(0xFF131B33)
val NavyElevated = Color(0xFF1B2545)
val NavyBorder = Color(0xFF2B3966)

// Electric purple & neon cyan accents
val ElectricPurple = Color(0xFF9D6BFF)
val ElectricPurpleDark = Color(0xFF6D28D9)
val ElectricPurpleContainer = Color(0xFF2A1B4E)

val NeonCyan = Color(0xFF22D3EE)
val NeonCyanDark = Color(0xFF0891B2)
val NeonCyanContainer = Color(0xFF0D2F3F)

// Semantic status colors
val StatusActiveEmerald = Color(0xFF10B981)
val StatusSpeakingCyan = Color(0xFF06D6E0)
val StatusReadingViolet = Color(0xFFA78BFA)
val StatusPausedAmber = Color(0xFFF59E0B)
val StatusErrorRose = Color(0xFFF43F5E)
val StatusIdleSlate = Color(0xFF64748B)

// High-contrast readable text on dark surfaces
val TextPrimaryLight = Color(0xFFF8FAFC)
val TextSecondaryLight = Color(0xFFB6C2DF)
val TextMutedLight = Color(0xFF7D8CB3)
