package com.example.engine

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.SystemClock
import android.util.Log
import android.view.WindowManager
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong

/**
 * Manages the Android MediaProjection, VirtualDisplay, and ImageReader pipeline safely.
 * Always registers MediaProjection.Callback before creating VirtualDisplay (Android 14+ requirement),
 * throttles frame extraction, skips capture while paused, handles orientation/display resize,
 * and guarantees every Image is closed immediately to avoid buffer exhaustion or leaks.
 */
class ScreenCaptureManager(
    private val context: Context,
    private val onFrameCaptured: (Bitmap, Boolean) -> Unit,
    private val onProjectionStopped: () -> Unit,
    private val onCaptureError: (String, String) -> Unit,
    private val onDisplayReconfigured: () -> Unit = {}
) {
    private var mediaProjection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private var handlerThread: HandlerThread? = null
    private var backgroundHandler: Handler? = null

    private val isRunning = AtomicBoolean(false)
    private val isPaused = AtomicBoolean(false)
    private val forceNextFrame = AtomicBoolean(false)
    private val lastFrameTimeMs = AtomicLong(0L)
    private val intervalMs = AtomicLong(600L)

    private var currentWidth: Int = 0
    private var currentHeight: Int = 0
    private var currentDensityDpi: Int = 320

    private val projectionCallback = object : MediaProjection.Callback() {
        override fun onStop() {
            Log.i(TAG, "MediaProjection stopped by system or user")
            // The system has already stopped the projection. Release local resources without
            // calling MediaProjection.stop() again (which could re-enter this callback).
            if (isRunning.getAndSet(false)) {
                isPaused.set(false)
                forceNextFrame.set(false)
                releaseSurfaceOnly()
                mediaProjection = null
                stopHandlerThread()
                onProjectionStopped()
            }
        }

        override fun onCapturedContentResize(width: Int, height: Int) {
            if (width > 0 && height > 0 && isRunning.get()) {
                Log.i(TAG, "Captured content resized to ${width}x${height}")
                reconfigureDisplay(width, height, currentDensityDpi)
            }
        }
    }

    fun start(resultCode: Int, resultData: Intent, scanIntervalMs: Long): Boolean {
        if (isRunning.get()) {
            // A repeated start command must not tear down a valid MediaProjection session.
            updateInterval(scanIntervalMs)
            return true
        }
        intervalMs.set(scanIntervalMs.coerceIn(400L, 1500L))

        val projectionManager =
            context.getSystemService(Context.MEDIA_PROJECTION_SERVICE) as? MediaProjectionManager
        if (projectionManager == null) {
            onCaptureError(
                "इस डिवाइस पर MediaProjection सेवा उपलब्ध नहीं है।",
                "MediaProjection service is unavailable on this device."
            )
            return false
        }

        return try {
            val projection = projectionManager.getMediaProjection(resultCode, resultData)
            if (projection == null) {
                onCaptureError(
                    "स्क्रीन कैप्चर शुरू नहीं हो सका। कृपया फिर से अनुमति दें।",
                    "Could not start screen capture. Please grant permission again."
                )
                return false
            }

            val thread = HandlerThread("GameTalkCaptureThread").apply { start() }
            val handler = Handler(thread.looper)
            handlerThread = thread
            backgroundHandler = handler

            mediaProjection = projection
            // Mandatory on Android 14+ (API 34+): register callback before createVirtualDisplay
            projection.registerCallback(projectionCallback, handler)

            val metrics = readCurrentDisplayMetrics()
            currentWidth = metrics.width
            currentHeight = metrics.height
            currentDensityDpi = metrics.densityDpi

            isRunning.set(true)
            isPaused.set(false)
            lastFrameTimeMs.set(0L)

            createCaptureSurface(currentWidth, currentHeight, currentDensityDpi)
            true
        } catch (se: SecurityException) {
            Log.e(TAG, "SecurityException starting MediaProjection", se)
            stop()
            onCaptureError(
                "स्क्रीन कैप्चर अनुमति अस्वीकृत या समाप्त हो गई। कृपया फिर से शुरू करें।",
                "Screen capture permission was denied or expired. Please start again."
            )
            false
        } catch (t: Throwable) {
            Log.e(TAG, "Failed to start MediaProjection", t)
            stop()
            onCaptureError(
                "स्क्रीन कैप्चर शुरू करते समय त्रुटि हुई: ${t.localizedMessage ?: "अज्ञात"}",
                "Failed to start screen capture: ${t.localizedMessage ?: "Unknown error"}"
            )
            false
        }
    }

    fun updateInterval(newIntervalMs: Long) {
        intervalMs.set(newIntervalMs.coerceIn(400L, 1500L))
    }

    fun setPaused(paused: Boolean) {
        isPaused.set(paused)
    }

    fun requestImmediateCapture() {
        forceNextFrame.set(true)
        backgroundHandler?.post {
            acquireLatestFrameIfAllowed(ignoreThrottle = true)
        }
    }

    fun handleConfigurationChanged() {
        if (!isRunning.get()) return
        val metrics = readCurrentDisplayMetrics()
        if (metrics.width != currentWidth || metrics.height != currentHeight) {
            reconfigureDisplay(metrics.width, metrics.height, metrics.densityDpi)
        }
    }

    @Synchronized
    fun reconfigureDisplay(width: Int, height: Int, densityDpi: Int) {
        if (!isRunning.get() || mediaProjection == null) return
        val safeW = width.coerceAtLeast(160)
        val safeH = height.coerceAtLeast(160)
        val safeDpi = densityDpi.coerceAtLeast(120)
        if (safeW == currentWidth && safeH == currentHeight && safeDpi == currentDensityDpi) return

        val handler = backgroundHandler ?: return
        val display = virtualDisplay
        if (display == null) {
            onCaptureError(
                "स्क्रीन कैप्चर डिस्प्ले उपलब्ध नहीं है। कृपया Live Translation दोबारा शुरू करें।",
                "Virtual display is missing. Please start Live Translation again."
            )
            return
        }

        // IMPORTANT: Android 14+ permits one VirtualDisplay creation per MediaProjection.
        // Keep that VirtualDisplay and resize/rebind its Surface instead of creating another one.
        var replacementReader: ImageReader? = null
        try {
            replacementReader = ImageReader.newInstance(
                safeW, safeH, PixelFormat.RGBA_8888, 3
            )
            replacementReader.setOnImageAvailableListener({
                acquireLatestFrameIfAllowed(ignoreThrottle = false)
            }, handler)

            display.resize(safeW, safeH, safeDpi)
            display.setSurface(replacementReader.surface)

            val previousReader = imageReader
            imageReader = replacementReader
            replacementReader = null
            currentWidth = safeW
            currentHeight = safeH
            currentDensityDpi = safeDpi

            runCatching { previousReader?.setOnImageAvailableListener(null, null) }
            runCatching { previousReader?.close() }
            lastFrameTimeMs.set(0L)
            forceNextFrame.set(true)
            onDisplayReconfigured()
            handler.post { acquireLatestFrameIfAllowed(ignoreThrottle = true) }
            Log.i(TAG, "VirtualDisplay resized in-place to ${safeW}x${safeH} @ ${safeDpi}dpi")
        } catch (t: Throwable) {
            Log.e(TAG, "Error resizing existing VirtualDisplay", t)
            runCatching { replacementReader?.setOnImageAvailableListener(null, null) }
            runCatching { replacementReader?.close() }
            onCaptureError(
                "स्क्रीन का आकार बदलते समय कैप्चर अपडेट नहीं हो सका: ${t.localizedMessage ?: "अज्ञात त्रुटि"}",
                "Could not update capture after display resize: ${t.localizedMessage ?: "unknown error"}"
            )
        }
    }

    private fun createCaptureSurface(width: Int, height: Int, densityDpi: Int) {
        val handler = backgroundHandler ?: return
        val projection = mediaProjection ?: return

        val reader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
        reader.setOnImageAvailableListener({
            acquireLatestFrameIfAllowed(ignoreThrottle = false)
        }, handler)
        imageReader = reader

        virtualDisplay = projection.createVirtualDisplay(
            "GameTalkHindiVirtualDisplay",
            width,
            height,
            densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            reader.surface,
            null,
            handler
        ) ?: run {
            runCatching { reader.setOnImageAvailableListener(null, null) }
            runCatching { reader.close() }
            imageReader = null
            throw IllegalStateException("Android returned a null VirtualDisplay")
        }
    }

    private fun acquireLatestFrameIfAllowed(ignoreThrottle: Boolean) {
        if (!isRunning.get()) return
        val reader = imageReader ?: return

        val force = forceNextFrame.getAndSet(false) || ignoreThrottle
        if (isPaused.get() && !force) {
            // Drain latest buffer cleanly so ImageReader doesn't stall without doing work
            drainLatestImage(reader)
            return
        }

        val now = SystemClock.elapsedRealtime()
        val elapsed = now - lastFrameTimeMs.get()
        if (!force && elapsed < intervalMs.get()) {
            drainLatestImage(reader)
            return
        }

        var image: Image? = null
        try {
            image = reader.acquireLatestImage() ?: return
            lastFrameTimeMs.set(now)
            val bitmap = imageToBitmap(image)
            if (bitmap != null) {
                onFrameCaptured(bitmap, force)
            }
        } catch (t: Throwable) {
            Log.w(TAG, "Frame acquisition warning: ${t.message}")
        } finally {
            try {
                image?.close()
            } catch (_: Throwable) {
            }
        }
    }

    private fun drainLatestImage(reader: ImageReader) {
        var image: Image? = null
        try {
            image = reader.acquireLatestImage()
        } catch (_: Throwable) {
        } finally {
            try {
                image?.close()
            } catch (_: Throwable) {
            }
        }
    }

    private fun imageToBitmap(image: Image): Bitmap? {
        val plane = image.planes.firstOrNull() ?: return null
        val buffer = plane.buffer ?: return null
        val pixelStride = plane.pixelStride
        val rowStride = plane.rowStride
        if (pixelStride <= 0) return null

        val rowPadding = rowStride - pixelStride * image.width
        val paddedWidth = image.width + rowPadding / pixelStride
        if (paddedWidth <= 0 || image.height <= 0) return null

        val fullBitmap = Bitmap.createBitmap(paddedWidth, image.height, Bitmap.Config.ARGB_8888)
        return try {
            buffer.rewind()
            fullBitmap.copyPixelsFromBuffer(buffer)
            if (paddedWidth == image.width) {
                fullBitmap
            } else {
                val cropped = Bitmap.createBitmap(fullBitmap, 0, 0, image.width, image.height)
                fullBitmap.recycle()
                cropped
            }
        } catch (t: Throwable) {
            if (!fullBitmap.isRecycled) fullBitmap.recycle()
            Log.e(TAG, "Bitmap conversion failed", t)
            null
        }
    }

    private fun releaseSurfaceOnly() {
        runCatching { virtualDisplay?.release() }
        virtualDisplay = null
        runCatching { imageReader?.setOnImageAvailableListener(null, null) }
        runCatching { imageReader?.close() }
        imageReader = null
    }

    @Synchronized
    fun stop() {
        isRunning.set(false)
        isPaused.set(false)
        forceNextFrame.set(false)

        releaseSurfaceOnly()

        val projection = mediaProjection
        mediaProjection = null
        if (projection != null) {
            runCatching { projection.unregisterCallback(projectionCallback) }
            runCatching { projection.stop() }
        }

        stopHandlerThread()
    }

    private fun stopHandlerThread() {
        val thread = handlerThread
        handlerThread = null
        backgroundHandler = null
        runCatching { thread?.quitSafely() }
    }

    private data class DisplayInfo(val width: Int, val height: Int, val densityDpi: Int)

    private fun readCurrentDisplayMetrics(): DisplayInfo {
        val wm = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val density = context.resources.displayMetrics.densityDpi
        // Capture the physical display dimensions, not the app window dimensions.
        @Suppress("DEPRECATION")
        val realMetrics = android.util.DisplayMetrics().also { wm.defaultDisplay.getRealMetrics(it) }
        return DisplayInfo(
            width = realMetrics.widthPixels.coerceAtLeast(320),
            height = realMetrics.heightPixels.coerceAtLeast(320),
            densityDpi = realMetrics.densityDpi.takeIf { it > 0 } ?: density
        )
    }

    companion object {
        private const val TAG = "ScreenCaptureManager"
    }
}
