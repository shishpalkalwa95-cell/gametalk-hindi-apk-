package com.example.engine

import android.content.Intent
import com.example.data.LiveSessionState
import com.example.data.ModelDownloadState
import com.example.data.TranslatorStatus
import com.example.data.TtsVoiceStatus
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

sealed interface CaptureCommand {
    data object ReadNow : CaptureCommand
    data object Pause : CaptureCommand
    data object Resume : CaptureCommand
    data object Stop : CaptureCommand
}

/**
 * Single source of truth for live translation runtime state shared across
 * MainActivity, MainViewModel, ScreenCaptureService, and FloatingOverlayService.
 */
class LiveTranslatorController {

    private val _sessionState = MutableStateFlow(LiveSessionState())
    val sessionState: StateFlow<LiveSessionState> = _sessionState.asStateFlow()

    private val _commands = MutableSharedFlow<CaptureCommand>(extraBufferCapacity = 16)
    val commands: SharedFlow<CaptureCommand> = _commands.asSharedFlow()

    @Volatile
    private var pendingProjectionResultCode: Int = 0
    @Volatile
    private var pendingProjectionData: Intent? = null

    @Synchronized
    fun storePendingProjectionGrant(resultCode: Int, data: Intent) {
        pendingProjectionResultCode = resultCode
        pendingProjectionData = data
    }

    @Synchronized
    fun consumePendingProjectionGrant(): Pair<Int, Intent>? {
        val data = pendingProjectionData ?: return null
        val code = pendingProjectionResultCode
        pendingProjectionData = null
        pendingProjectionResultCode = 0
        return code to data
    }

    fun sendCommand(command: CaptureCommand) {
        _commands.tryEmit(command)
    }

    fun updateStatus(status: TranslatorStatus) {
        _sessionState.update { it.copy(status = status) }
    }

    fun setCapturingStarted() {
        _sessionState.update {
            it.copy(
                status = TranslatorStatus.CAPTURING,
                isCapturing = true,
                isPaused = false,
                lastErrorHi = null,
                lastErrorEn = null
            )
        }
    }

    fun setPaused(paused: Boolean) {
        _sessionState.update { current ->
            if (!current.isCapturing) return@update current
            current.copy(
                isPaused = paused,
                status = if (paused) TranslatorStatus.PAUSED else TranslatorStatus.CAPTURING
            )
        }
    }

    fun setCapturingStopped() {
        _sessionState.update {
            it.copy(
                status = TranslatorStatus.IDLE,
                isCapturing = false,
                isPaused = false,
                isSpeaking = false,
                queuedSpeechCount = 0
            )
        }
    }

    fun setOverlayActive(active: Boolean) {
        _sessionState.update { it.copy(overlayActive = active) }
    }

    fun updateLatestDialogue(english: String, hindi: String) {
        _sessionState.update {
            it.copy(
                lastEnglishText = english,
                lastHindiText = hindi,
                lastCapturedAt = System.currentTimeMillis(),
                lastErrorHi = null,
                lastErrorEn = null
            )
        }
    }

    fun incrementProcessedFrames() {
        _sessionState.update { it.copy(framesProcessed = it.framesProcessed + 1L) }
    }

    fun updateSpeakingState(speaking: Boolean, queuedCount: Int) {
        _sessionState.update { current ->
            val nextStatus = when {
                !current.isCapturing -> if (speaking) TranslatorStatus.SPEAKING else current.status
                current.isPaused -> TranslatorStatus.PAUSED
                speaking -> TranslatorStatus.SPEAKING
                current.status == TranslatorStatus.SPEAKING -> TranslatorStatus.CAPTURING
                else -> current.status
            }
            current.copy(
                isSpeaking = speaking,
                queuedSpeechCount = queuedCount,
                status = nextStatus
            )
        }
    }

    fun updateModelState(state: ModelDownloadState) {
        _sessionState.update { it.copy(modelState = state) }
    }

    fun updateTtsStatus(status: TtsVoiceStatus) {
        _sessionState.update { it.copy(ttsStatus = status) }
    }

    fun reportError(messageHi: String, messageEn: String, markErrorStatus: Boolean = true) {
        _sessionState.update {
            it.copy(
                status = if (markErrorStatus) TranslatorStatus.ERROR else it.status,
                lastErrorHi = messageHi,
                lastErrorEn = messageEn
            )
        }
    }

    fun reportPermissionRequired(messageHi: String, messageEn: String) {
        _sessionState.update {
            it.copy(
                status = TranslatorStatus.PERMISSION_REQUIRED,
                lastErrorHi = messageHi,
                lastErrorEn = messageEn
            )
        }
    }

    fun clearError() {
        _sessionState.update { current ->
            val recoveredStatus = when {
                current.isCapturing && current.isPaused -> TranslatorStatus.PAUSED
                current.isCapturing -> TranslatorStatus.CAPTURING
                else -> TranslatorStatus.IDLE
            }
            current.copy(
                status = if (current.status == TranslatorStatus.ERROR ||
                    current.status == TranslatorStatus.PERMISSION_REQUIRED
                ) recoveredStatus else current.status,
                lastErrorHi = null,
                lastErrorEn = null
            )
        }
    }
}
