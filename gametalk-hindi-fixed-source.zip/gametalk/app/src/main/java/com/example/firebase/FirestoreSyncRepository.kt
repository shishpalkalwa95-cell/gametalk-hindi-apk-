package com.example.firebase

import android.content.Context
import com.example.R
import com.example.data.AppSettings
import com.google.firebase.Firebase
import com.google.firebase.Timestamp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await

/**
 * Authenticated Firestore repository bound to the provisioned named database ID
 * (`R.string.firestore_database_id`).
 */
class FirestoreSyncRepository(
    private val db: FirebaseFirestore,
    private val auth: FirebaseAuth = Firebase.auth
) {
    constructor(context: Context) : this(
        db = FirebaseFirestore.getInstance(
            context.applicationContext.getString(R.string.firestore_database_id)
        )
    )

    private fun requireUserId(): String {
        val uid = auth.currentUser?.uid
        check(!uid.isNullOrBlank()) {
            "User must be signed in with Google before accessing Firestore."
        }
        return uid
    }

    fun observeTranslations(userId: String): Flow<List<CloudTranslation>> = flow {
        if (userId.isBlank()) {
            emit(emptyList())
            return@flow
        }
        val path = "users/$userId/translations"
        emitAll(
            db.collection("users")
                .document(userId)
                .collection("translations")
                .orderBy("createdAt", Query.Direction.DESCENDING)
                .limit(200)
                .snapshots()
                .map { snapshot ->
                    snapshot.toObjects(
                        CloudTranslation::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    ).sortedByDescending { it.createdAt ?: Timestamp(0, 0) }
                }
                .catch { error ->
                    val firestoreError = generateSequence(error) { it.cause }
                        .filterIsInstance<FirebaseFirestoreException>()
                        .firstOrNull()
                    if (firestoreError == null && error is CancellationException) throw error
                    val exceptionToLog = firestoreError ?: (error as? Exception)
                    if (exceptionToLog != null && auth.currentUser?.uid == userId) {
                        handleFirestoreError(exceptionToLog, OperationType.LIST, path)
                    }
                    throw error
                }
        )
    }

    fun observeUserProfile(userId: String): Flow<UserProfile?> = flow {
        if (userId.isBlank()) {
            emit(null)
            return@flow
        }
        val path = "users/$userId"
        emitAll(
            db.collection("users")
                .document(userId)
                .snapshots()
                .map { snapshot ->
                    if (snapshot.exists()) {
                        snapshot.toObject(
                            UserProfile::class.java,
                            DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                        )
                    } else {
                        null
                    }
                }
                .catch { error ->
                    val firestoreError = generateSequence(error) { it.cause }
                        .filterIsInstance<FirebaseFirestoreException>()
                        .firstOrNull()
                    if (firestoreError == null && error is CancellationException) throw error
                    val exceptionToLog = firestoreError ?: (error as? Exception)
                    if (exceptionToLog != null && auth.currentUser?.uid == userId) {
                        handleFirestoreError(exceptionToLog, OperationType.GET, path)
                    }
                    throw error
                }
        )
    }

    suspend fun syncUserProfile(
        displayName: String,
        settings: AppSettings
    ): Result<Unit> {
        val currentUid = auth.currentUser?.uid
        val path = "users/${currentUid ?: "unauthenticated"}"
        return try {
            val uid = requireUserId()
            val safeName = displayName.trim().ifBlank { "Gamer" }.take(80)
            val safeRegion = settings.readingRegion.normalized()
            val safeLanguage = settings.uiLanguage.name
            val safeSpeed = settings.speechSpeed.toDouble().coerceIn(0.6, 1.5)
            val safePitch = settings.speechPitch.toDouble().coerceIn(0.7, 1.3)
            val safeVolume = settings.speechVolume.toDouble().coerceIn(0.0, 1.0)
            val safeInterval = settings.ocrIntervalMs.coerceIn(400L, 1500L)

            val docRef = db.collection("users").document(uid)
            val existingSnap = docRef.get().await()
            if (!existingSnap.exists()) {
                val createPayload = mapOf(
                    "userId" to uid,
                    "displayName" to safeName,
                    "uiLanguage" to safeLanguage,
                    "customRegionEnabled" to settings.customRegionEnabled,
                    "regionLeft" to safeRegion.left.toDouble(),
                    "regionTop" to safeRegion.top.toDouble(),
                    "regionRight" to safeRegion.right.toDouble(),
                    "regionBottom" to safeRegion.bottom.toDouble(),
                    "speechSpeed" to safeSpeed,
                    "speechPitch" to safePitch,
                    "speechVolume" to safeVolume,
                    "ocrIntervalMs" to safeInterval,
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
                docRef.set(createPayload).await()
            } else {
                val updatePayload = mapOf(
                    "displayName" to safeName,
                    "uiLanguage" to safeLanguage,
                    "customRegionEnabled" to settings.customRegionEnabled,
                    "regionLeft" to safeRegion.left.toDouble(),
                    "regionTop" to safeRegion.top.toDouble(),
                    "regionRight" to safeRegion.right.toDouble(),
                    "regionBottom" to safeRegion.bottom.toDouble(),
                    "speechSpeed" to safeSpeed,
                    "speechPitch" to safePitch,
                    "speechVolume" to safeVolume,
                    "ocrIntervalMs" to safeInterval,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
                docRef.update(updatePayload).await()
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, path)
            Result.failure(e)
        }
    }

    suspend fun addTranslation(
        english: String,
        hindi: String,
        customRegionMode: Boolean
    ): Result<String> {
        var docPath = "users/${auth.currentUser?.uid ?: "unauthenticated"}/translations"
        return try {
            val uid = requireUserId()
            val cleanEn = english.trim().take(1000)
            val cleanHi = hindi.trim().take(2000)
            require(cleanEn.isNotEmpty() && cleanHi.isNotEmpty()) {
                "Translation text must not be empty."
            }

            val docRef = db.collection("users")
                .document(uid)
                .collection("translations")
                .document()
            docPath = docRef.path

            val payload = mapOf(
                "userId" to uid,
                "originalEnglish" to cleanEn,
                "translatedHindi" to cleanHi,
                "captureMode" to if (customRegionMode) "region" else "fullscreen",
                "favorite" to false,
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            )
            docRef.set(payload).await()
            Result.success(docRef.id)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docPath)
            Result.failure(e)
        }
    }

    suspend fun toggleFavorite(translationId: String, favorite: Boolean): Result<Unit> {
        var docPath = "users/${auth.currentUser?.uid ?: "unauthenticated"}/translations/$translationId"
        return try {
            val uid = requireUserId()
            require(translationId.isNotBlank()) { "Translation ID must not be blank." }
            val docRef = db.collection("users")
                .document(uid)
                .collection("translations")
                .document(translationId)
            docPath = docRef.path
            docRef.update(
                mapOf(
                    "favorite" to favorite,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docPath)
            Result.failure(e)
        }
    }

    suspend fun deleteTranslation(translationId: String): Result<Unit> {
        var docPath = "users/${auth.currentUser?.uid ?: "unauthenticated"}/translations/$translationId"
        return try {
            val uid = requireUserId()
            require(translationId.isNotBlank()) { "Translation ID must not be blank." }
            val docRef = db.collection("users")
                .document(uid)
                .collection("translations")
                .document(translationId)
            docPath = docRef.path
            docRef.delete().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, docPath)
            Result.failure(e)
        }
    }

    suspend fun clearAllTranslations(): Result<Unit> {
        val currentUid = auth.currentUser?.uid
        val path = "users/${currentUid ?: "unauthenticated"}/translations"
        return try {
            val uid = requireUserId()
            val colRef = db.collection("users").document(uid).collection("translations")
            val snapshots = colRef.limit(400).get().await()
            if (!snapshots.isEmpty) {
                val batch = db.batch()
                for (doc in snapshots.documents) {
                    batch.delete(doc.reference)
                }
                batch.commit().await()
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, path)
            Result.failure(e)
        }
    }
}
