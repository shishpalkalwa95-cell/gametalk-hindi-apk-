package com.example.engine

import android.content.Context
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Log
import com.example.data.TtsVoiceStatus
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.ArrayDeque
import java.util.Locale
import java.util.UUID

/**
 * Bounded FIFO speech queue for smooth sequential Hindi narration without unbounded growth.
 */
class BoundedSpeechQueue(private val maxCapacity: Int = 8) {
    private val queue = ArrayDeque<String>(maxCapacity)

    @Synchronized
    fun enqueue(text: String): Int {
        val clean = text.trim()
        if (clean.isEmpty()) return queue.size
        // Avoid adding consecutive identical utterances
        if (queue.peekLast() == clean) return queue.size
        while (queue.size >= maxCapacity) {
            queue.pollFirst()
        }
        queue.addLast(clean)
        return queue.size
    }

    @Synchronized
    fun pollNext(): String? = queue.pollFirst()

    @Synchronized
    fun clear() {
        queue.clear()
    }

    @Synchronized
    fun size(): Int = queue.size
}

class HindiSpeechManager(private val context: Context) {

    private val _voiceStatus = MutableStateFlow<TtsVoiceStatus>(TtsVoiceStatus.Checking)
    val voiceStatus: StateFlow<TtsVoiceStatus> = _voiceStatus.asStateFlow()

    private val _isSpeaking = MutableStateFlow(false)
    val isSpeaking: StateFlow<Boolean> = _isSpeaking.asStateFlow()

    private val _queuedCount = MutableStateFlow(0)
    val queuedCount: StateFlow<Int> = _queuedCount.asStateFlow()

    private val speechQueue = BoundedSpeechQueue(maxCapacity = 8)

    @Volatile
    private var tts: TextToSpeech? = null
    @Volatile
    private var isInitialized: Boolean = false
    @Volatile
    private var isPaused: Boolean = false
    @Volatile
    private var isMuted: Boolean = false
    @Volatile
    private var speechRate: Float = 1.0f
    @Volatile
    private var speechPitch: Float = 1.0f
    @Volatile
    private var speechVolume: Float = 1.0f
    @Volatile
    private var currentUtteranceText: String = ""

    private val hindiLocale = Locale("hi", "IN")

    fun initialize() {
        if (tts != null) return
        _voiceStatus.value = TtsVoiceStatus.Checking
        try {
            tts = TextToSpeech(context.applicationContext) { status ->
                if (status == TextToSpeech.SUCCESS) {
                    isInitialized = true
                    configureHindiVoice()
                } else {
                    isInitialized = false
                    _voiceStatus.value = TtsVoiceStatus.Unavailable(
                        reasonHi = "Android Text-to-Speech इंजन शुरू नहीं हो सका।",
                        reasonEn = "Android Text-to-Speech engine could not initialize."
                    )
                }
            }
        } catch (t: Throwable) {
            Log.e(TAG, "Failed to create TextToSpeech", t)
            _voiceStatus.value = TtsVoiceStatus.Unavailable(
                reasonHi = "Text-to-Speech सेवा उपलब्ध नहीं है।",
                reasonEn = "Text-to-Speech service is unavailable."
            )
        }
    }

    fun recheckHindiVoice() {
        if (!isInitialized || tts == null) {
            shutdown()
            initialize()
        } else {
            configureHindiVoice()
        }
    }

    private fun configureHindiVoice() {
        val engine = tts ?: return
        try {
            val availability = engine.isLanguageAvailable(hindiLocale)
            if (availability == TextToSpeech.LANG_MISSING_DATA ||
                availability == TextToSpeech.LANG_NOT_SUPPORTED
            ) {
                _voiceStatus.value = TtsVoiceStatus.HindiMissing
            } else {
                val result = engine.setLanguage(hindiLocale)
                if (result == TextToSpeech.LANG_MISSING_DATA ||
                    result == TextToSpeech.LANG_NOT_SUPPORTED
                ) {
                    _voiceStatus.value = TtsVoiceStatus.HindiMissing
                } else {
                    // Prefer an offline high-quality Hindi voice if available
                    val bestVoice = runCatching {
                        engine.voices
                            ?.filter { it.locale.language.equals("hi", ignoreCase = true) }
                            ?.sortedBy { it.isNetworkConnectionRequired }
                            ?.firstOrNull()
                    }.getOrNull()

                    if (bestVoice != null) {
                        runCatching { engine.voice = bestVoice }
                    }
                    _voiceStatus.value = TtsVoiceStatus.Ready(
                        voiceName = bestVoice?.name ?: "Hindi (India)"
                    )
                }
            }

            engine.setSpeechRate(speechRate)
            engine.setPitch(speechPitch)
            engine.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {
                    _isSpeaking.value = true
                }

                override fun onDone(utteranceId: String?) {
                    _isSpeaking.value = false
                    currentUtteranceText = ""
                    drainQueueIfIdle()
                }

                @Deprecated("Deprecated in Java")
                override fun onError(utteranceId: String?) {
                    _isSpeaking.value = false
                    currentUtteranceText = ""
                    drainQueueIfIdle()
                }

                override fun onError(utteranceId: String?, errorCode: Int) {
                    _isSpeaking.value = false
                    currentUtteranceText = ""
                    drainQueueIfIdle()
                }
            })
        } catch (t: Throwable) {
            Log.e(TAG, "Error configuring Hindi TTS voice", t)
            _voiceStatus.value = TtsVoiceStatus.Unavailable(
                reasonHi = "हिंदी आवाज़ सेट करते समय त्रुटि हुई।",
                reasonEn = "Error configuring Hindi voice."
            )
        }
    }

    fun updateAudioConfig(
        speed: Float,
        pitch: Float,
        volume: Float,
        muted: Boolean
    ) {
        speechRate = speed.coerceIn(0.6f, 1.5f)
        speechPitch = pitch.coerceIn(0.7f, 1.3f)
        speechVolume = volume.coerceIn(0f, 1f)
        isMuted = muted
        tts?.let { engine ->
            runCatching {
                engine.setSpeechRate(speechRate)
                engine.setPitch(speechPitch)
            }
        }
        if (muted && _isSpeaking.value) {
            stopSpeaking()
        }
    }

    /**
     * Enqueues a newly translated Hindi dialogue without interrupting the currently spoken sentence.
     */
    fun enqueueDialogue(hindiText: String, interruptPending: Boolean = false) {
        val clean = hindiText.trim()
        if (clean.isEmpty() || isMuted || isPaused) return
        if (interruptPending) {
            speechQueue.clear()
            _queuedCount.value = 0
        }
        if (!isInitialized) {
            initialize()
            return
        }
        // Do not interrupt or re-queue if currently speaking virtually identical text
        if (_isSpeaking.value && currentUtteranceText == clean) return

        val newSize = speechQueue.enqueue(clean)
        _queuedCount.value = newSize
        drainQueueIfIdle()
    }

    /**
     * Immediately speaks a specific Hindi text (used for Read Again, History Replay, or Voice Test).
     */
    fun speakNow(hindiText: String) {
        val clean = hindiText.trim()
        if (clean.isEmpty()) return
        if (!isInitialized) {
            initialize()
            return
        }
        speechQueue.clear()
        _queuedCount.value = 0
        speakInternal(clean, TextToSpeech.QUEUE_FLUSH)
    }

    private fun drainQueueIfIdle() {
        if (isPaused || isMuted || !isInitialized) return
        if (_isSpeaking.value) return
        val next = speechQueue.pollNext()
        _queuedCount.value = speechQueue.size()
        if (next != null) {
            speakInternal(next, TextToSpeech.QUEUE_ADD)
        }
    }

    private fun speakInternal(text: String, queueMode: Int) {
        val engine = tts ?: return
        try {
            currentUtteranceText = text
            val params = Bundle().apply {
                putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, speechVolume)
            }
            val utteranceId = "gt_${UUID.randomUUID()}"
            engine.setSpeechRate(speechRate)
            engine.setPitch(speechPitch)
            val result = engine.speak(text, queueMode, params, utteranceId)
            if (result == TextToSpeech.ERROR) {
                _isSpeaking.value = false
                currentUtteranceText = ""
            } else {
                _isSpeaking.value = true
            }
        } catch (t: Throwable) {
            Log.e(TAG, "TTS speak failed", t)
            _isSpeaking.value = false
            currentUtteranceText = ""
        }
    }

    fun pause() {
        isPaused = true
        stopSpeaking()
    }

    fun resume() {
        isPaused = false
        drainQueueIfIdle()
    }

    fun stopSpeaking() {
        speechQueue.clear()
        _queuedCount.value = 0
        currentUtteranceText = ""
        _isSpeaking.value = false
        runCatching { tts?.stop() }
    }

    fun trimQueueForLowMemory() {
        speechQueue.clear()
        _queuedCount.value = 0
    }

    fun shutdown() {
        stopSpeaking()
        isInitialized = false
        runCatching { tts?.shutdown() }
        tts = null
    }

    companion object {
        private const val TAG = "HindiSpeechManager"
    }
}
