package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.CropFree
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.data.AppSettings
import com.example.data.ModelDownloadState
import com.example.data.ReadingRegion
import com.example.data.TtsVoiceStatus
import com.example.data.UiLanguage
import com.example.ui.i18n.LocalizedStrings
import com.example.ui.theme.ElectricPurple
import com.example.ui.theme.NavyBorder
import com.example.ui.theme.NavyCard
import com.example.ui.theme.NavyElevated
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.StatusActiveEmerald
import com.example.ui.theme.StatusPausedAmber
import com.example.ui.theme.TextSecondaryLight
import java.util.Locale
import kotlin.math.roundToInt

@Composable
fun SettingsScreen(
    strings: LocalizedStrings,
    settings: AppSettings,
    modelState: ModelDownloadState,
    ttsStatus: TtsVoiceStatus,
    isTestingVoice: Boolean,
    onBackToDashboard: () -> Unit,
    onSetCustomRegionEnabled: (Boolean) -> Unit,
    onSetShowRegionBorder: (Boolean) -> Unit,
    onSetRegionLocked: (Boolean) -> Unit,
    onSetDimOutside: (Boolean) -> Unit,
    onResetRegion: () -> Unit,
    onSetFloatingOverlayEnabled: (Boolean) -> Unit,
    onSetSubtitleOverlayEnabled: (Boolean) -> Unit,
    onUpdateFloatingOpacity: (Float) -> Unit,
    onUpdateFloatingSizeDp: (Int) -> Unit,
    onUpdateOcrIntervalMs: (Long) -> Unit,
    onUpdateSpeechSpeed: (Float) -> Unit,
    onUpdateSpeechPitch: (Float) -> Unit,
    onUpdateSpeechVolume: (Float) -> Unit,
    onSetMuted: (Boolean) -> Unit,
    onSetAutoSpeak: (Boolean) -> Unit,
    onTestHindiVoice: () -> Unit,
    onOpenInstallHindiVoice: () -> Unit,
    onDownloadHindiModel: () -> Unit,
    onSetUiLanguage: (UiLanguage) -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler(onBack = onBackToDashboard)
    val isHindiUi = settings.uiLanguage == UiLanguage.HINDI

    Box(
        modifier = modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 680.dp),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // 1. Reading Area Configuration & Mini Preview
            item(key = "section_reading_area") {
                SettingsSectionCard(
                    title = strings.sectionReadingArea,
                    icon = Icons.Filled.CropFree,
                    accentColor = NeonCyan
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        FilterChip(
                            selected = settings.customRegionEnabled,
                            onClick = { onSetCustomRegionEnabled(true) },
                            label = { Text(strings.customRegionMode) },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("chip_custom_region"),
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = NeonCyan.copy(alpha = 0.22f),
                                selectedLabelColor = NeonCyan
                            )
                        )
                        FilterChip(
                            selected = !settings.customRegionEnabled,
                            onClick = { onSetCustomRegionEnabled(false) },
                            label = { Text(strings.fullScreenMode) },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("chip_full_screen"),
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = ElectricPurple.copy(alpha = 0.22f),
                                selectedLabelColor = ElectricPurple
                            )
                        )
                    }

                    if (settings.customRegionEnabled) {
                        ReadingRegionPreviewCanvas(
                            region = settings.readingRegion,
                            locked = settings.regionLocked,
                            dimOutside = settings.dimOutsideRegion
                        )
                        Text(
                            text = strings.regionPreviewHint,
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondaryLight
                        )

                        SettingsSwitchRow(
                            label = strings.showSelectionBox,
                            checked = settings.showRegionBorder,
                            onCheckedChange = onSetShowRegionBorder,
                            tag = "settings_show_region_switch"
                        )
                        SettingsSwitchRow(
                            label = strings.lockPosition,
                            checked = settings.regionLocked,
                            onCheckedChange = onSetRegionLocked,
                            tag = "settings_lock_region_switch"
                        )
                        SettingsSwitchRow(
                            label = strings.dimOutside,
                            checked = settings.dimOutsideRegion,
                            onCheckedChange = onSetDimOutside,
                            tag = "settings_dim_outside_switch"
                        )

                        OutlinedButton(
                            onClick = onResetRegion,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .testTag("reset_region_button"),
                            shape = MaterialTheme.shapes.small
                        ) {
                            Icon(Icons.Filled.RestartAlt, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text(strings.resetRegion)
                        }
                    }
                }
            }

            // 2. Floating Button & Subtitle Overlay
            item(key = "section_floating") {
                SettingsSectionCard(
                    title = strings.sectionFloatingControls,
                    icon = Icons.Filled.Layers,
                    accentColor = ElectricPurple
                ) {
                    SettingsSwitchRow(
                        label = strings.floatingOverlay,
                        checked = settings.floatingOverlayEnabled,
                        onCheckedChange = onSetFloatingOverlayEnabled,
                        tag = "settings_floating_switch"
                    )
                    SettingsSwitchRow(
                        label = strings.subtitleOverlay,
                        checked = settings.subtitleOverlayEnabled,
                        onCheckedChange = onSetSubtitleOverlayEnabled,
                        tag = "settings_subtitle_switch"
                    )

                    SettingsSliderRow(
                        label = strings.floatingButtonOpacity,
                        valueLabel = "${(settings.floatingButtonOpacity * 100).roundToInt()}%",
                        value = settings.floatingButtonOpacity,
                        valueRange = 0.35f..1.0f,
                        accent = ElectricPurple,
                        onValueChange = onUpdateFloatingOpacity,
                        tag = "floating_opacity_slider"
                    )

                    SettingsSliderRow(
                        label = strings.floatingButtonSize,
                        valueLabel = "${settings.floatingButtonSizeDp} dp",
                        value = settings.floatingButtonSizeDp.toFloat(),
                        valueRange = 44f..72f,
                        accent = NeonCyan,
                        onValueChange = { onUpdateFloatingSizeDp(it.roundToInt()) },
                        tag = "floating_size_slider"
                    )
                }
            }

            // 3. Hindi Voice & Audio Controls
            item(key = "section_voice") {
                SettingsSectionCard(
                    title = strings.sectionVoiceAudio,
                    icon = Icons.Filled.RecordVoiceOver,
                    accentColor = NeonCyan
                ) {
                    SettingsSliderRow(
                        label = strings.speechSpeed,
                        valueLabel = String.format(Locale.US, "%.2fx", settings.speechSpeed),
                        value = settings.speechSpeed,
                        valueRange = 0.6f..1.5f,
                        accent = ElectricPurple,
                        onValueChange = onUpdateSpeechSpeed,
                        tag = "settings_speed_slider"
                    )
                    SettingsSliderRow(
                        label = strings.speechPitch,
                        valueLabel = String.format(Locale.US, "%.2fx", settings.speechPitch),
                        value = settings.speechPitch,
                        valueRange = 0.7f..1.3f,
                        accent = NeonCyan,
                        onValueChange = onUpdateSpeechPitch,
                        tag = "settings_pitch_slider"
                    )
                    SettingsSliderRow(
                        label = strings.speechVolume,
                        valueLabel = "${(settings.speechVolume * 100).roundToInt()}%",
                        value = settings.speechVolume,
                        valueRange = 0f..1f,
                        accent = StatusActiveEmerald,
                        onValueChange = onUpdateSpeechVolume,
                        tag = "settings_volume_slider"
                    )

                    SettingsSwitchRow(
                        label = strings.autoSpeak,
                        checked = settings.autoSpeak,
                        onCheckedChange = onSetAutoSpeak,
                        tag = "settings_auto_speak_switch"
                    )
                    SettingsSwitchRow(
                        label = strings.muteVoice,
                        checked = settings.isMuted,
                        onCheckedChange = onSetMuted,
                        tag = "settings_mute_switch"
                    )

                    val voiceSummary = when (ttsStatus) {
                        is TtsVoiceStatus.Ready -> "${strings.voiceReady} (${ttsStatus.voiceName})"
                        TtsVoiceStatus.Checking -> strings.modelChecking
                        TtsVoiceStatus.HindiMissing -> strings.installHindiVoice
                        is TtsVoiceStatus.Unavailable -> if (isHindiUi) ttsStatus.reasonHi else ttsStatus.reasonEn
                    }
                    Text(
                        text = voiceSummary,
                        style = MaterialTheme.typography.bodySmall,
                        color = if (ttsStatus is TtsVoiceStatus.Ready) StatusActiveEmerald else StatusPausedAmber
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Button(
                            onClick = onTestHindiVoice,
                            enabled = !isTestingVoice,
                            modifier = Modifier
                                .weight(1f)
                                .height(48.dp)
                                .testTag("settings_test_voice_button"),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = ElectricPurple,
                                contentColor = ObsidianBlack
                            )
                        ) {
                            Icon(Icons.AutoMirrored.Filled.VolumeUp, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text(if (isHindiUi) "आवाज़ टेस्ट" else "Test Voice")
                        }
                        OutlinedButton(
                            onClick = onOpenInstallHindiVoice,
                            modifier = Modifier
                                .weight(1f)
                                .height(48.dp)
                                .testTag("settings_install_tts_button")
                        ) {
                            Text(if (isHindiUi) "हिंदी वॉइस" else "TTS Settings")
                        }
                    }
                }
            }

            // 4. OCR Scan Interval & Battery
            item(key = "section_ocr") {
                SettingsSectionCard(
                    title = strings.sectionOcrPerformance,
                    icon = Icons.Filled.Speed,
                    accentColor = ElectricPurple
                ) {
                    SettingsSliderRow(
                        label = strings.ocrInterval,
                        valueLabel = "${settings.ocrIntervalMs} ms",
                        value = settings.ocrIntervalMs.toFloat(),
                        valueRange = 400f..1200f,
                        accent = NeonCyan,
                        onValueChange = { onUpdateOcrIntervalMs((it / 50f).roundToInt() * 50L) },
                        tag = "ocr_interval_slider"
                    )
                }
            }

            // 5. Offline Translation Model (ML Kit)
            item(key = "section_model") {
                SettingsSectionCard(
                    title = strings.sectionOfflineModel,
                    icon = Icons.Filled.Download,
                    accentColor = StatusActiveEmerald
                ) {
                    val statusMsg = when (modelState) {
                        ModelDownloadState.Downloaded -> strings.downloadedOffline
                        ModelDownloadState.Downloading -> strings.downloading
                        ModelDownloadState.Checking -> strings.modelChecking
                        is ModelDownloadState.Error -> if (isHindiUi) modelState.messageHi else modelState.messageEn
                        ModelDownloadState.NotChecked -> strings.downloadModel
                    }
                    Text(
                        text = statusMsg,
                        style = MaterialTheme.typography.bodyMedium,
                        color = if (modelState is ModelDownloadState.Downloaded) StatusActiveEmerald else TextSecondaryLight
                    )

                    if (modelState !is ModelDownloadState.Downloaded) {
                        Button(
                            onClick = onDownloadHindiModel,
                            enabled = modelState !is ModelDownloadState.Downloading,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .testTag("settings_download_model_button"),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = NeonCyan,
                                contentColor = ObsidianBlack
                            )
                        ) {
                            if (modelState is ModelDownloadState.Downloading) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(18.dp),
                                    strokeWidth = 2.dp,
                                    color = ObsidianBlack
                                )
                                Spacer(Modifier.width(8.dp))
                                Text(strings.downloading)
                            } else {
                                Icon(Icons.Filled.Download, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(Modifier.width(8.dp))
                                Text(strings.downloadModel)
                            }
                        }
                    }
                }
            }

            // 6. Interface Language Toggle (Hindi / English)
            item(key = "section_language") {
                SettingsSectionCard(
                    title = strings.sectionInterface,
                    icon = Icons.Filled.Language,
                    accentColor = NeonCyan
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        FilterChip(
                            selected = settings.uiLanguage == UiLanguage.HINDI,
                            onClick = { onSetUiLanguage(UiLanguage.HINDI) },
                            label = { Text("हिंदी (Hindi)") },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("lang_chip_hindi"),
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = ElectricPurple.copy(alpha = 0.25f),
                                selectedLabelColor = ElectricPurple
                            )
                        )
                        FilterChip(
                            selected = settings.uiLanguage == UiLanguage.ENGLISH,
                            onClick = { onSetUiLanguage(UiLanguage.ENGLISH) },
                            label = { Text("English") },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("lang_chip_english"),
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = NeonCyan.copy(alpha = 0.25f),
                                selectedLabelColor = NeonCyan
                            )
                        )
                    }
                }
            }

            item { Spacer(Modifier.height(16.dp)) }
        }
    }
}

@Composable
private fun SettingsSectionCard(
    title: String,
    icon: ImageVector,
    accentColor: Color,
    content: @Composable () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = MaterialTheme.shapes.large,
        colors = CardDefaults.cardColors(containerColor = NavyCard),
        border = BorderStroke(1.dp, NavyBorder)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(imageVector = icon, contentDescription = null, tint = accentColor)
                Text(text = title, style = MaterialTheme.typography.titleMedium)
            }
            HorizontalDivider(color = NavyBorder.copy(alpha = 0.6f))
            content()
        }
    }
}

@Composable
private fun SettingsSwitchRow(
    label: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    tag: String
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodyMedium,
            modifier = Modifier.weight(1f)
        )
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            modifier = Modifier.testTag(tag),
            colors = SwitchDefaults.colors(
                checkedThumbColor = ObsidianBlack,
                checkedTrackColor = NeonCyan
            )
        )
    }
}

@Composable
private fun SettingsSliderRow(
    label: String,
    valueLabel: String,
    value: Float,
    valueRange: ClosedFloatingPointRange<Float>,
    accent: Color,
    onValueChange: (Float) -> Unit,
    tag: String
) {
    Column {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(label, style = MaterialTheme.typography.bodyMedium)
            Text(valueLabel, style = MaterialTheme.typography.labelLarge, color = accent)
        }
        Slider(
            value = value,
            onValueChange = onValueChange,
            valueRange = valueRange,
            modifier = Modifier.testTag(tag),
            colors = SliderDefaults.colors(
                thumbColor = accent,
                activeTrackColor = accent
            )
        )
    }
}

@Composable
private fun ReadingRegionPreviewCanvas(
    region: ReadingRegion,
    locked: Boolean,
    dimOutside: Boolean
) {
    val safe = region.normalized()
    Canvas(
        modifier = Modifier
            .fillMaxWidth()
            .height(126.dp)
    ) {
        drawRoundRect(
            color = NavyElevated,
            cornerRadius = CornerRadius(12.dp.toPx(), 12.dp.toPx())
        )
        if (dimOutside) {
            drawRoundRect(
                color = Color.Black.copy(alpha = 0.45f),
                cornerRadius = CornerRadius(12.dp.toPx(), 12.dp.toPx())
            )
        }
        val left = safe.left * size.width
        val top = safe.top * size.height
        val boxW = (safe.right - safe.left) * size.width
        val boxH = (safe.bottom - safe.top) * size.height

        drawRoundRect(
            color = Color(0xFF152A4A),
            topLeft = Offset(left, top),
            size = Size(boxW, boxH),
            cornerRadius = CornerRadius(6.dp.toPx(), 6.dp.toPx())
        )
        drawRoundRect(
            color = if (locked) ElectricPurple else NeonCyan,
            topLeft = Offset(left, top),
            size = Size(boxW, boxH),
            cornerRadius = CornerRadius(6.dp.toPx(), 6.dp.toPx()),
            style = Stroke(width = 2.dp.toPx())
        )
        if (!locked) {
            val handleR = 4.dp.toPx()
            val corners = listOf(
                Offset(left, top),
                Offset(left + boxW, top),
                Offset(left, top + boxH),
                Offset(left + boxW, top + boxH)
            )
            corners.forEach { pt ->
                drawCircle(color = ElectricPurple, radius = handleR, center = pt)
            }
        }
    }
}
