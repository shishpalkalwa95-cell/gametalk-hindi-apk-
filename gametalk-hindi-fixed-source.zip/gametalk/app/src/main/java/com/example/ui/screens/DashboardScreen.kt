package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.VolumeOff
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CropFree
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Subtitles
import androidx.compose.material.icons.filled.Translate
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.AppSettings
import com.example.data.LiveSessionState
import com.example.data.ModelDownloadState
import com.example.data.TranslatorStatus
import com.example.data.TtsVoiceStatus
import com.example.data.UiLanguage
import com.example.firebase.CloudTranslation
import com.example.ui.i18n.LocalizedStrings
import com.google.firebase.Timestamp
import com.example.ui.theme.ElectricPurple
import com.example.ui.theme.NavyBorder
import com.example.ui.theme.NavyCard
import com.example.ui.theme.NavyElevated
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NotoDevanagariFontFamily
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.StatusActiveEmerald
import com.example.ui.theme.StatusErrorRose
import com.example.ui.theme.StatusIdleSlate
import com.example.ui.theme.StatusPausedAmber
import com.example.ui.theme.StatusReadingViolet
import com.example.ui.theme.StatusSpeakingCyan
import com.example.ui.theme.TextSecondaryLight
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

@Composable
fun DashboardScreen(
    strings: LocalizedStrings,
    settings: AppSettings,
    session: LiveSessionState,
    history: List<CloudTranslation>,
    hasOverlayPermission: Boolean,
    hasNotificationPermission: Boolean,
    isTestingVoice: Boolean,
    onStartCaptureClick: () -> Unit,
    onStopCaptureClick: () -> Unit,
    onPauseClick: () -> Unit,
    onResumeClick: () -> Unit,
    onReadNowClick: () -> Unit,
    onReadAgainClick: () -> Unit,
    onStopSpeakingClick: () -> Unit,
    onToggleFloatingOverlay: (Boolean) -> Unit,
    onToggleSubtitleOverlay: (Boolean) -> Unit,
    onToggleShowRegionBox: (Boolean) -> Unit,
    onToggleLockRegion: (Boolean) -> Unit,
    onToggleCustomRegionMode: (Boolean) -> Unit,
    onSpeechSpeedChange: (Float) -> Unit,
    onSpeechVolumeChange: (Float) -> Unit,
    onToggleMute: (Boolean) -> Unit,
    onRequestOverlayPermission: () -> Unit,
    onRequestNotificationPermission: () -> Unit,
    onDownloadHindiModel: () -> Unit,
    onOpenInstallHindiVoice: () -> Unit,
    onTestHindiVoice: () -> Unit,
    onReplayHistoryItem: (String) -> Unit,
    onClearHistory: () -> Unit,
    onOpenFullHistory: () -> Unit,
    onOpenSettings: () -> Unit,
    onDismissError: () -> Unit,
    modifier: Modifier = Modifier
) {
    val isHindi = settings.uiLanguage == UiLanguage.HINDI
    val activeError = if (isHindi) session.lastErrorHi else session.lastErrorEn

    Box(
        modifier = modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 680.dp),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // 1. Hero Live Control Deck with Generated HUD Banner
            item(key = "hero_deck") {
                HeroControlDeckCard(
                    strings = strings,
                    session = session,
                    onStartCaptureClick = onStartCaptureClick,
                    onStopCaptureClick = onStopCaptureClick,
                    onPauseClick = onPauseClick,
                    onResumeClick = onResumeClick,
                    onReadNowClick = onReadNowClick
                )
            }

            // 2. Dismissible Error / Permission Guidance Banner
            item(key = "error_banner") {
                AnimatedVisibility(visible = !activeError.isNullOrBlank()) {
                    ErrorAlertCard(
                        message = activeError.orEmpty(),
                        dismissLabel = strings.dismissError,
                        showOverlayAction = !hasOverlayPermission && session.status == TranslatorStatus.PERMISSION_REQUIRED,
                        overlayActionLabel = strings.openOverlaySettings,
                        onOpenOverlaySettings = onRequestOverlayPermission,
                        onDismiss = onDismissError
                    )
                }
            }

            // 3. Live Translation Display (Original English + Large Hindi + Voice Controls)
            item(key = "live_translation") {
                LiveDialogueCard(
                    strings = strings,
                    session = session,
                    subtitleOverlayEnabled = settings.subtitleOverlayEnabled,
                    onReadAgain = onReadAgainClick,
                    onStopSpeaking = onStopSpeakingClick,
                    onToggleSubtitleOverlay = onToggleSubtitleOverlay
                )
            }

            // 4. Quick Gaming Controls (Floating Overlay, Reading Box, Speed & Volume)
            item(key = "quick_controls") {
                QuickControlsCard(
                    strings = strings,
                    settings = settings,
                    onToggleFloatingOverlay = onToggleFloatingOverlay,
                    onToggleShowRegionBox = onToggleShowRegionBox,
                    onToggleLockRegion = onToggleLockRegion,
                    onToggleCustomRegionMode = onToggleCustomRegionMode,
                    onSpeechSpeedChange = onSpeechSpeedChange,
                    onSpeechVolumeChange = onSpeechVolumeChange,
                    onToggleMute = onToggleMute,
                    onOpenReadingSettings = onOpenSettings
                )
            }

            // 5. Readiness Checklist (Overlay, Notifications, Offline ML Kit Model, Hindi TTS)
            item(key = "readiness_card") {
                ReadinessChecklistCard(
                    strings = strings,
                    hasOverlayPermission = hasOverlayPermission,
                    hasNotificationPermission = hasNotificationPermission,
                    modelState = session.modelState,
                    ttsStatus = session.ttsStatus,
                    isHindiUi = isHindi,
                    isTestingVoice = isTestingVoice,
                    onRequestOverlayPermission = onRequestOverlayPermission,
                    onRequestNotificationPermission = onRequestNotificationPermission,
                    onDownloadModel = onDownloadHindiModel,
                    onInstallHindiVoice = onOpenInstallHindiVoice,
                    onTestHindiVoice = onTestHindiVoice
                )
            }

            // 6. Beginner Quick-Start + Privacy & DRM Transparency
            item(key = "privacy_and_guide") {
                QuickGuideAndPrivacyCard(strings = strings)
            }

            // 7. Recent Translation History Preview
            item(key = "recent_history_header") {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = strings.recentHistory,
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        if (history.isNotEmpty()) {
                            TextButton(
                                onClick = onClearHistory,
                                modifier = Modifier.testTag("dashboard_clear_history_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.DeleteSweep,
                                    contentDescription = strings.clearHistory,
                                    modifier = Modifier.size(18.dp),
                                    tint = StatusErrorRose
                                )
                                Spacer(Modifier.width(4.dp))
                                Text(strings.clearHistory, color = StatusErrorRose)
                            }
                        }
                        TextButton(
                            onClick = onOpenFullHistory,
                            modifier = Modifier.testTag("view_all_history_button")
                        ) {
                            Text(strings.viewAll, color = NeonCyan)
                        }
                    }
                }
            }

            if (history.isEmpty()) {
                item(key = "empty_recent") {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = NavyCard),
                        border = BorderStroke(1.dp, NavyBorder),
                        shape = MaterialTheme.shapes.medium,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(18.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Translate,
                                contentDescription = null,
                                tint = ElectricPurple,
                                modifier = Modifier.size(32.dp)
                            )
                            Spacer(Modifier.height(8.dp))
                            Text(
                                text = strings.emptyHistoryTitle,
                                style = MaterialTheme.typography.titleSmall,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Spacer(Modifier.height(4.dp))
                            Text(
                                text = strings.emptyHistoryBody,
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondaryLight
                            )
                        }
                    }
                }
            } else {
                items(history.take(4), key = { it.id }) { item ->
                    RecentHistoryMiniCard(
                        item = item,
                        replayDesc = strings.replayHindi,
                        onReplay = { onReplayHistoryItem(item.translatedHindi) }
                    )
                }
            }

            item { Spacer(Modifier.height(16.dp)) }
        }
    }
}

@Composable
private fun HeroControlDeckCard(
    strings: LocalizedStrings,
    session: LiveSessionState,
    onStartCaptureClick: () -> Unit,
    onStopCaptureClick: () -> Unit,
    onPauseClick: () -> Unit,
    onResumeClick: () -> Unit,
    onReadNowClick: () -> Unit
) {
    val statusColor = statusBadgeColor(session.status)
    val statusText = strings.statusLabels[session.status] ?: session.status.name
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulseAlpha by infiniteTransition.animateFloat(
        initialValue = 0.45f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(900),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulseAlpha"
    )

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = MaterialTheme.shapes.large,
        border = BorderStroke(
            width = 1.2.dp,
            brush = Brush.linearGradient(listOf(ElectricPurple.copy(alpha = 0.7f), NeonCyan.copy(alpha = 0.7f)))
        ),
        colors = CardDefaults.cardColors(containerColor = NavyCard)
    ) {
        Box(modifier = Modifier.fillMaxWidth()) {
            Image(
                painter = painterResource(id = R.drawable.img_dashboard_banner_1795616326866),
                contentDescription = stringResource(id = R.string.cd_banner),
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .matchParentSize()
                    .alpha(0.32f)
            )
            Box(
                modifier = Modifier
                    .matchParentSize()
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(
                                ObsidianBlack.copy(alpha = 0.55f),
                                NavyCard.copy(alpha = 0.92f)
                            )
                        )
                    )
            )

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Status Pill & Frame Counter
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Surface(
                        color = statusColor.copy(alpha = 0.18f),
                        shape = RoundedCornerShape(50),
                        border = BorderStroke(1.dp, statusColor.copy(alpha = 0.75f)),
                        modifier = Modifier.testTag("status_badge")
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(9.dp)
                                    .clip(CircleShape)
                                    .background(
                                        if (session.isCapturing && !session.isPaused) {
                                            statusColor.copy(alpha = pulseAlpha)
                                        } else {
                                            statusColor
                                        }
                                    )
                            )
                            Text(
                                text = statusText,
                                style = MaterialTheme.typography.labelLarge,
                                color = statusColor
                            )
                        }
                    }

                    if (session.isCapturing) {
                        Text(
                            text = "OCR #${session.framesProcessed}",
                            style = MaterialTheme.typography.labelSmall,
                            color = TextSecondaryLight
                        )
                    }
                }

                // Primary Start / Stop CTA
                if (!session.isCapturing) {
                    Button(
                        onClick = onStartCaptureClick,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(56.dp)
                            .testTag("start_translation_button"),
                        shape = MaterialTheme.shapes.medium,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = ElectricPurple,
                            contentColor = ObsidianBlack
                        )
                    ) {
                        Icon(
                            imageVector = Icons.Filled.PlayArrow,
                            contentDescription = null,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(Modifier.width(8.dp))
                        Text(
                            text = strings.startLiveTranslation,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                    }
                } else {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Button(
                            onClick = onStopCaptureClick,
                            modifier = Modifier
                                .weight(1f)
                                .height(52.dp)
                                .testTag("stop_translation_button"),
                            shape = MaterialTheme.shapes.medium,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = StatusErrorRose,
                                contentColor = Color.White
                            )
                        ) {
                            Icon(Icons.Filled.Stop, contentDescription = null)
                            Spacer(Modifier.width(6.dp))
                            Text(strings.stopTranslation, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }

                        FilledTonalButton(
                            onClick = if (session.isPaused) onResumeClick else onPauseClick,
                            modifier = Modifier
                                .weight(1f)
                                .height(52.dp)
                                .testTag("pause_resume_button"),
                            shape = MaterialTheme.shapes.medium,
                            colors = ButtonDefaults.filledTonalButtonColors(
                                containerColor = if (session.isPaused) StatusActiveEmerald.copy(alpha = 0.22f) else StatusPausedAmber.copy(alpha = 0.22f),
                                contentColor = if (session.isPaused) StatusActiveEmerald else StatusPausedAmber
                            )
                        ) {
                            Icon(
                                imageVector = if (session.isPaused) Icons.Filled.PlayArrow else Icons.Filled.Pause,
                                contentDescription = null
                            )
                            Spacer(Modifier.width(6.dp))
                            Text(if (session.isPaused) strings.resume else strings.pause)
                        }
                    }

                    OutlinedButton(
                        onClick = onReadNowClick,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("read_now_button"),
                        shape = MaterialTheme.shapes.medium,
                        border = BorderStroke(1.dp, NeonCyan.copy(alpha = 0.7f)),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = NeonCyan)
                    ) {
                        Icon(Icons.Filled.CropFree, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(8.dp))
                        Text(strings.readNow)
                    }
                }
            }
        }
    }
}

@Composable
private fun ErrorAlertCard(
    message: String,
    dismissLabel: String,
    showOverlayAction: Boolean,
    overlayActionLabel: String,
    onOpenOverlaySettings: () -> Unit,
    onDismiss: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("error_banner_card"),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF3A0C1B)),
        border = BorderStroke(1.dp, StatusErrorRose),
        shape = MaterialTheme.shapes.medium
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                verticalAlignment = Alignment.Top,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Icon(
                    imageVector = Icons.Filled.ErrorOutline,
                    contentDescription = null,
                    tint = StatusErrorRose,
                    modifier = Modifier.size(22.dp)
                )
                Text(
                    text = message,
                    style = MaterialTheme.typography.bodyMedium,
                    color = Color(0xFFFFD6DF),
                    modifier = Modifier.weight(1f)
                )
            }
            Spacer(Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End
            ) {
                if (showOverlayAction) {
                    TextButton(onClick = onOpenOverlaySettings) {
                        Text(overlayActionLabel, color = NeonCyan)
                    }
                }
                TextButton(onClick = onDismiss) {
                    Text(dismissLabel, color = Color.White)
                }
            }
        }
    }
}

@Composable
private fun LiveDialogueCard(
    strings: LocalizedStrings,
    session: LiveSessionState,
    subtitleOverlayEnabled: Boolean,
    onReadAgain: () -> Unit,
    onStopSpeaking: () -> Unit,
    onToggleSubtitleOverlay: (Boolean) -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = MaterialTheme.shapes.large,
        colors = CardDefaults.cardColors(containerColor = NavyCard),
        border = BorderStroke(1.dp, if (session.isSpeaking) NeonCyan else NavyBorder)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Filled.GraphicEq,
                        contentDescription = null,
                        tint = if (session.isSpeaking) NeonCyan else ElectricPurple
                    )
                    Text(
                        text = strings.liveDialogueTitle,
                        style = MaterialTheme.typography.titleMedium
                    )
                }

                if (session.isSpeaking) {
                    Surface(
                        color = NeonCyan.copy(alpha = 0.16f),
                        shape = RoundedCornerShape(50)
                    ) {
                        Text(
                            text = if (session.queuedSpeechCount > 0) {
                                "${strings.speakingNow} (${strings.queuedPrefix} ${session.queuedSpeechCount})"
                            } else {
                                strings.speakingNow
                            },
                            style = MaterialTheme.typography.labelSmall,
                            color = NeonCyan,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                        )
                    }
                }
            }

            if (session.lastHindiText.isBlank() && session.lastEnglishText.isBlank()) {
                Text(
                    text = strings.waitingForDialogue,
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextSecondaryLight
                )
            } else {
                // Original English
                Surface(
                    color = NavyElevated,
                    shape = MaterialTheme.shapes.small,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(
                            text = strings.originalEnglish,
                            style = MaterialTheme.typography.labelSmall,
                            color = TextSecondaryLight
                        )
                        Spacer(Modifier.height(4.dp))
                        Text(
                            text = session.lastEnglishText,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }

                // Large Readable Hindi Translation
                Surface(
                    color = Color(0xFF0D2036),
                    shape = MaterialTheme.shapes.small,
                    border = BorderStroke(1.dp, NeonCyan.copy(alpha = 0.4f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(
                            text = strings.hindiTranslation,
                            style = MaterialTheme.typography.labelSmall,
                            color = NeonCyan
                        )
                        Spacer(Modifier.height(6.dp))
                        Text(
                            text = session.lastHindiText,
                            fontFamily = NotoDevanagariFontFamily,
                            fontSize = 21.sp,
                            lineHeight = 31.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = Color.White,
                            modifier = Modifier.testTag("live_hindi_output")
                        )
                    }
                }
            }

            // Read Again & Stop Speaking Buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                FilledTonalButton(
                    onClick = onReadAgain,
                    enabled = session.lastHindiText.isNotBlank(),
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .testTag("read_again_button"),
                    shape = MaterialTheme.shapes.small
                ) {
                    Icon(Icons.Filled.Refresh, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text(strings.readAgain, maxLines = 1)
                }

                OutlinedButton(
                    onClick = onStopSpeaking,
                    enabled = session.isSpeaking,
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .testTag("stop_speaking_button"),
                    shape = MaterialTheme.shapes.small,
                    border = BorderStroke(1.dp, if (session.isSpeaking) StatusErrorRose else NavyBorder)
                ) {
                    Icon(Icons.Filled.Stop, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text(strings.stopSpeaking, maxLines = 1)
                }
            }

            HorizontalDivider(color = NavyBorder.copy(alpha = 0.7f))

            // Hindi Subtitle Overlay Switch
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    modifier = Modifier.weight(1f),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Icon(Icons.Filled.Subtitles, contentDescription = null, tint = NeonCyan)
                    Column {
                        Text(strings.subtitleOverlay, style = MaterialTheme.typography.titleSmall)
                        Text(
                            strings.subtitleOverlayDesc,
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondaryLight
                        )
                    }
                }
                Switch(
                    checked = subtitleOverlayEnabled,
                    onCheckedChange = onToggleSubtitleOverlay,
                    modifier = Modifier.testTag("subtitle_overlay_switch"),
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = ObsidianBlack,
                        checkedTrackColor = NeonCyan
                    )
                )
            }
        }
    }
}

@Composable
private fun QuickControlsCard(
    strings: LocalizedStrings,
    settings: AppSettings,
    onToggleFloatingOverlay: (Boolean) -> Unit,
    onToggleShowRegionBox: (Boolean) -> Unit,
    onToggleLockRegion: (Boolean) -> Unit,
    onToggleCustomRegionMode: (Boolean) -> Unit,
    onSpeechSpeedChange: (Float) -> Unit,
    onSpeechVolumeChange: (Float) -> Unit,
    onToggleMute: (Boolean) -> Unit,
    onOpenReadingSettings: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = MaterialTheme.shapes.large,
        colors = CardDefaults.cardColors(containerColor = NavyCard),
        border = BorderStroke(1.dp, NavyBorder)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Floating Overlay Toggle
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    modifier = Modifier.weight(1f),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Icon(Icons.Filled.Layers, contentDescription = null, tint = ElectricPurple)
                    Column {
                        Text(strings.floatingOverlay, style = MaterialTheme.typography.titleSmall)
                        Text(
                            strings.floatingOverlayDesc,
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondaryLight
                        )
                    }
                }
                Switch(
                    checked = settings.floatingOverlayEnabled,
                    onCheckedChange = onToggleFloatingOverlay,
                    modifier = Modifier.testTag("floating_overlay_switch"),
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = ObsidianBlack,
                        checkedTrackColor = ElectricPurple
                    )
                )
            }

            HorizontalDivider(color = NavyBorder.copy(alpha = 0.6f))

            // Reading Area Quick Controls
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Icon(Icons.Filled.CropFree, contentDescription = null, tint = NeonCyan)
                    Column {
                        Text(strings.readingArea, style = MaterialTheme.typography.titleSmall)
                        Text(
                            if (settings.customRegionEnabled) strings.customRegionMode else strings.fullScreenMode,
                            style = MaterialTheme.typography.bodySmall,
                            color = NeonCyan
                        )
                    }
                }
                TextButton(onClick = onOpenReadingSettings) {
                    Text(strings.navSettings, color = ElectricPurple)
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FilledTonalButton(
                    onClick = { onToggleCustomRegionMode(!settings.customRegionEnabled) },
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .testTag("toggle_region_mode_button"),
                    shape = MaterialTheme.shapes.small
                ) {
                    Text(
                        text = if (settings.customRegionEnabled) strings.customRegionMode else strings.fullScreenMode,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                OutlinedButton(
                    onClick = { onToggleShowRegionBox(!settings.showRegionBorder) },
                    enabled = settings.customRegionEnabled,
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .testTag("toggle_show_box_button"),
                    shape = MaterialTheme.shapes.small
                ) {
                    Icon(
                        imageVector = if (settings.showRegionBorder) Icons.Filled.Visibility else Icons.Filled.VisibilityOff,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(Modifier.width(4.dp))
                    Text(if (settings.showRegionBorder) "Box ON" else "Box OFF", maxLines = 1)
                }
                OutlinedButton(
                    onClick = { onToggleLockRegion(!settings.regionLocked) },
                    enabled = settings.customRegionEnabled && settings.showRegionBorder,
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .testTag("toggle_lock_box_button"),
                    shape = MaterialTheme.shapes.small
                ) {
                    Icon(
                        imageVector = if (settings.regionLocked) Icons.Filled.Lock else Icons.Filled.LockOpen,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(Modifier.width(4.dp))
                    Text(
                        if (settings.regionLocked) strings.locked else strings.unlocked,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            HorizontalDivider(color = NavyBorder.copy(alpha = 0.6f))

            // Speech Speed Slider (0.6x to 1.5x)
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(strings.speechSpeed, style = MaterialTheme.typography.titleSmall)
                    Text(
                        text = String.format(Locale.US, "%.2fx", settings.speechSpeed),
                        style = MaterialTheme.typography.labelLarge,
                        color = ElectricPurple
                    )
                }
                Slider(
                    value = settings.speechSpeed,
                    onValueChange = onSpeechSpeedChange,
                    valueRange = 0.6f..1.5f,
                    modifier = Modifier.testTag("dashboard_speed_slider"),
                    colors = SliderDefaults.colors(
                        thumbColor = ElectricPurple,
                        activeTrackColor = ElectricPurple
                    )
                )
            }

            // Speech Volume & Mute
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(strings.speechVolume, style = MaterialTheme.typography.titleSmall)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = if (settings.isMuted) "0%" else "${(settings.speechVolume * 100).roundToInt()}%",
                            style = MaterialTheme.typography.labelLarge,
                            color = NeonCyan
                        )
                        IconButton(
                            onClick = { onToggleMute(!settings.isMuted) },
                            modifier = Modifier.testTag("mute_toggle_button")
                        ) {
                            Icon(
                                imageVector = if (settings.isMuted) Icons.AutoMirrored.Filled.VolumeOff else Icons.AutoMirrored.Filled.VolumeUp,
                                contentDescription = strings.muteVoice,
                                tint = if (settings.isMuted) StatusErrorRose else NeonCyan
                            )
                        }
                    }
                }
                Slider(
                    value = if (settings.isMuted) 0f else settings.speechVolume,
                    onValueChange = { value ->
                        if (settings.isMuted && value > 0f) onToggleMute(false)
                        onSpeechVolumeChange(value)
                    },
                    valueRange = 0f..1f,
                    modifier = Modifier.testTag("dashboard_volume_slider"),
                    colors = SliderDefaults.colors(
                        thumbColor = NeonCyan,
                        activeTrackColor = NeonCyan
                    )
                )
            }
        }
    }
}

@Composable
private fun ReadinessChecklistCard(
    strings: LocalizedStrings,
    hasOverlayPermission: Boolean,
    hasNotificationPermission: Boolean,
    modelState: ModelDownloadState,
    ttsStatus: TtsVoiceStatus,
    isHindiUi: Boolean,
    isTestingVoice: Boolean,
    onRequestOverlayPermission: () -> Unit,
    onRequestNotificationPermission: () -> Unit,
    onDownloadModel: () -> Unit,
    onInstallHindiVoice: () -> Unit,
    onTestHindiVoice: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = MaterialTheme.shapes.large,
        colors = CardDefaults.cardColors(containerColor = NavyCard),
        border = BorderStroke(1.dp, NavyBorder)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(
                text = strings.readinessTitle,
                style = MaterialTheme.typography.titleMedium
            )

            // Overlay permission
            ReadinessRow(
                icon = Icons.Filled.Layers,
                title = strings.overlayPermission,
                isReady = hasOverlayPermission,
                statusText = if (hasOverlayPermission) strings.granted else strings.grantNow,
                actionLabel = if (hasOverlayPermission) null else strings.grantNow,
                onAction = onRequestOverlayPermission,
                actionTag = "grant_overlay_button"
            )

            // Notification permission
            ReadinessRow(
                icon = Icons.Filled.NotificationsActive,
                title = strings.notificationPermission,
                isReady = hasNotificationPermission,
                statusText = if (hasNotificationPermission) strings.granted else strings.grantNow,
                actionLabel = if (hasNotificationPermission) null else strings.grantNow,
                onAction = onRequestNotificationPermission,
                actionTag = "grant_notification_button"
            )

            // ML Kit English-Hindi Offline Model
            val modelReady = modelState is ModelDownloadState.Downloaded
            val modelBusy = modelState is ModelDownloadState.Downloading || modelState is ModelDownloadState.Checking
            val modelSubtitle = when (modelState) {
                ModelDownloadState.Downloaded -> strings.downloadedOffline
                ModelDownloadState.Downloading -> strings.downloading
                ModelDownloadState.Checking -> strings.modelChecking
                is ModelDownloadState.Error -> if (isHindiUi) modelState.messageHi else modelState.messageEn
                ModelDownloadState.NotChecked -> strings.downloadModel
            }
            ReadinessRow(
                icon = Icons.Filled.Download,
                title = strings.offlineHindiModel,
                isReady = modelReady,
                isBusy = modelBusy,
                statusText = modelSubtitle,
                actionLabel = if (modelReady || modelBusy) null else strings.downloadModel,
                onAction = onDownloadModel,
                actionTag = "download_model_button"
            )

            // Hindi TTS Voice Engine
            val voiceReady = ttsStatus is TtsVoiceStatus.Ready
            val voiceSubtitle = when (ttsStatus) {
                is TtsVoiceStatus.Ready -> strings.voiceReady
                TtsVoiceStatus.Checking -> strings.modelChecking
                TtsVoiceStatus.HindiMissing -> strings.installHindiVoice
                is TtsVoiceStatus.Unavailable -> if (isHindiUi) ttsStatus.reasonHi else ttsStatus.reasonEn
            }
            ReadinessRow(
                icon = Icons.Filled.RecordVoiceOver,
                title = strings.hindiVoiceEngine,
                isReady = voiceReady,
                isBusy = ttsStatus is TtsVoiceStatus.Checking,
                statusText = voiceSubtitle,
                actionLabel = if (voiceReady) null else strings.installHindiVoice,
                onAction = onInstallHindiVoice,
                actionTag = "install_tts_button"
            )

            HorizontalDivider(color = NavyBorder.copy(alpha = 0.6f))

            OutlinedButton(
                onClick = onTestHindiVoice,
                enabled = !isTestingVoice,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("test_hindi_voice_button"),
                shape = MaterialTheme.shapes.small,
                border = BorderStroke(1.dp, ElectricPurple.copy(alpha = 0.7f))
            ) {
                if (isTestingVoice) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(18.dp),
                        strokeWidth = 2.dp,
                        color = ElectricPurple
                    )
                } else {
                    Icon(Icons.AutoMirrored.Filled.VolumeUp, contentDescription = null, modifier = Modifier.size(18.dp))
                }
                Spacer(Modifier.width(8.dp))
                Text(strings.testHindiVoice, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }
    }
}

@Composable
private fun ReadinessRow(
    icon: ImageVector,
    title: String,
    isReady: Boolean,
    statusText: String,
    isBusy: Boolean = false,
    actionLabel: String?,
    onAction: () -> Unit,
    actionTag: String
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(
            modifier = Modifier.weight(1f),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Icon(
                imageVector = if (isReady) Icons.Filled.CheckCircle else icon,
                contentDescription = null,
                tint = if (isReady) StatusActiveEmerald else StatusPausedAmber,
                modifier = Modifier.size(22.dp)
            )
            Column {
                Text(title, style = MaterialTheme.typography.titleSmall)
                Text(
                    text = statusText,
                    style = MaterialTheme.typography.bodySmall,
                    color = if (isReady) StatusActiveEmerald else TextSecondaryLight,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
        if (isBusy) {
            CircularProgressIndicator(
                modifier = Modifier.size(22.dp),
                strokeWidth = 2.2.dp,
                color = NeonCyan
            )
        } else if (actionLabel != null) {
            FilledTonalButton(
                onClick = onAction,
                modifier = Modifier.testTag(actionTag),
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
            ) {
                Text(actionLabel, style = MaterialTheme.typography.labelMedium)
            }
        }
    }
}

@Composable
private fun QuickGuideAndPrivacyCard(strings: LocalizedStrings) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = MaterialTheme.shapes.large,
        colors = CardDefaults.cardColors(containerColor = NavyCard),
        border = BorderStroke(1.dp, NavyBorder)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(
                text = strings.quickSetupStepsTitle,
                style = MaterialTheme.typography.titleSmall,
                color = NeonCyan
            )
            Text(strings.quickSetupStep1, style = MaterialTheme.typography.bodySmall, color = TextSecondaryLight)
            Text(strings.quickSetupStep2, style = MaterialTheme.typography.bodySmall, color = TextSecondaryLight)
            Text(strings.quickSetupStep3, style = MaterialTheme.typography.bodySmall, color = TextSecondaryLight)

            HorizontalDivider(
                color = NavyBorder.copy(alpha = 0.6f),
                modifier = Modifier.padding(vertical = 4.dp)
            )

            Row(
                verticalAlignment = Alignment.Top,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = Icons.Filled.Security,
                    contentDescription = null,
                    tint = StatusActiveEmerald,
                    modifier = Modifier.size(18.dp)
                )
                Column {
                    Text(
                        text = strings.privacyNoticeTitle,
                        style = MaterialTheme.typography.labelLarge,
                        color = StatusActiveEmerald
                    )
                    Text(
                        text = strings.privacyNoticeBody,
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondaryLight
                    )
                }
            }
        }
    }
}

@Composable
private fun RecentHistoryMiniCard(
    item: CloudTranslation,
    replayDesc: String,
    onReplay: () -> Unit
) {
    val displayTs = item.updatedAt ?: item.createdAt ?: Timestamp.now()
    val timeText = SimpleDateFormat("hh:mm a", Locale.getDefault()).format(displayTs.toDate())
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = MaterialTheme.shapes.medium,
        colors = CardDefaults.cardColors(containerColor = NavyCard),
        border = BorderStroke(1.dp, NavyBorder.copy(alpha = 0.7f))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = item.translatedHindi,
                    fontFamily = NotoDevanagariFontFamily,
                    fontSize = 17.sp,
                    lineHeight = 24.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = Color.White,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(Modifier.height(3.dp))
                Text(
                    text = item.originalEnglish,
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondaryLight,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = timeText,
                    style = MaterialTheme.typography.labelSmall,
                    color = StatusIdleSlate
                )
            }
            IconButton(
                onClick = onReplay,
                modifier = Modifier.testTag("recent_replay_${item.id}")
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.VolumeUp,
                    contentDescription = replayDesc,
                    tint = NeonCyan
                )
            }
        }
    }
}

private fun statusBadgeColor(status: TranslatorStatus): Color = when (status) {
    TranslatorStatus.IDLE -> StatusIdleSlate
    TranslatorStatus.PERMISSION_REQUIRED -> StatusPausedAmber
    TranslatorStatus.CAPTURING -> StatusActiveEmerald
    TranslatorStatus.READING -> StatusReadingViolet
    TranslatorStatus.TRANSLATING -> ElectricPurple
    TranslatorStatus.SPEAKING -> StatusSpeakingCyan
    TranslatorStatus.PAUSED -> StatusPausedAmber
    TranslatorStatus.ERROR -> StatusErrorRose
}
