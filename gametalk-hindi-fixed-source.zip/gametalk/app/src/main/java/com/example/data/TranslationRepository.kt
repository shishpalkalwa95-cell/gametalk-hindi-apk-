package com.example.data

import kotlinx.coroutines.flow.Flow

class TranslationRepository(
    private val translationDao: TranslationDao,
    private val settingsStore: SettingsStore
) {
    val historyFlow: Flow<List<TranslationEntity>> = translationDao.observeAll()
    val settingsFlow: Flow<AppSettings> = settingsStore.settingsFlow

    suspend fun saveTranslation(
        english: String,
        hindi: String,
        customRegionMode: Boolean
    ): Long {
        val cleanEn = english.trim()
        val cleanHi = hindi.trim()
        if (cleanEn.isEmpty() || cleanHi.isEmpty()) return -1L
        return translationDao.insert(
            TranslationEntity(
                originalEnglish = cleanEn,
                translatedHindi = cleanHi,
                timestamp = System.currentTimeMillis(),
                captureMode = if (customRegionMode) "region" else "fullscreen"
            )
        )
    }

    suspend fun deleteTranslation(id: Long) {
        translationDao.deleteById(id)
    }

    suspend fun clearHistory() {
        translationDao.clearAll()
    }

    suspend fun updateSettings(transform: (AppSettings) -> AppSettings) {
        settingsStore.updateSettings(transform)
    }

    suspend fun saveReadingRegion(region: ReadingRegion) {
        settingsStore.updateSettings { it.copy(readingRegion = region.normalized()) }
    }
}
