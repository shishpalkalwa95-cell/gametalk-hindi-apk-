package com.example.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import java.io.IOException

private val Context.gameTalkDataStore: DataStore<Preferences> by preferencesDataStore(
    name = "gametalk_hindi_settings"
)

class SettingsStore(private val context: Context) {

    private object Keys {
        val UI_LANGUAGE = stringPreferencesKey("ui_language")
        val FLOATING_OVERLAY_ENABLED = booleanPreferencesKey("floating_overlay_enabled")
        val SUBTITLE_OVERLAY_ENABLED = booleanPreferencesKey("subtitle_overlay_enabled")
        val CUSTOM_REGION_ENABLED = booleanPreferencesKey("custom_region_enabled")
        val SHOW_REGION_BORDER = booleanPreferencesKey("show_region_border")
        val DIM_OUTSIDE_REGION = booleanPreferencesKey("dim_outside_region")
        val REGION_LOCKED = booleanPreferencesKey("region_locked")
        val REGION_LEFT = floatPreferencesKey("region_left")
        val REGION_TOP = floatPreferencesKey("region_top")
        val REGION_RIGHT = floatPreferencesKey("region_right")
        val REGION_BOTTOM = floatPreferencesKey("region_bottom")
        val OCR_INTERVAL_MS = longPreferencesKey("ocr_interval_ms")
        val SPEECH_SPEED = floatPreferencesKey("speech_speed")
        val SPEECH_PITCH = floatPreferencesKey("speech_pitch")
        val SPEECH_VOLUME = floatPreferencesKey("speech_volume")
        val IS_MUTED = booleanPreferencesKey("is_muted")
        val AUTO_SPEAK = booleanPreferencesKey("auto_speak")
        val FLOATING_BUTTON_OPACITY = floatPreferencesKey("floating_button_opacity")
        val FLOATING_BUTTON_SIZE_DP = intPreferencesKey("floating_button_size_dp")
    }

    val settingsFlow: Flow<AppSettings> = context.gameTalkDataStore.data
        .catch { exception ->
            if (exception is IOException) {
                emit(emptyPreferences())
            } else {
                throw exception
            }
        }
        .map { prefs ->
            val language = when (prefs[Keys.UI_LANGUAGE]) {
                UiLanguage.ENGLISH.name -> UiLanguage.ENGLISH
                else -> UiLanguage.HINDI
            }
            val region = ReadingRegion(
                left = prefs[Keys.REGION_LEFT] ?: ReadingRegion.DEFAULT_LEFT,
                top = prefs[Keys.REGION_TOP] ?: ReadingRegion.DEFAULT_TOP,
                right = prefs[Keys.REGION_RIGHT] ?: ReadingRegion.DEFAULT_RIGHT,
                bottom = prefs[Keys.REGION_BOTTOM] ?: ReadingRegion.DEFAULT_BOTTOM
            ).normalized()

            AppSettings(
                uiLanguage = language,
                floatingOverlayEnabled = prefs[Keys.FLOATING_OVERLAY_ENABLED] ?: true,
                subtitleOverlayEnabled = prefs[Keys.SUBTITLE_OVERLAY_ENABLED] ?: true,
                customRegionEnabled = prefs[Keys.CUSTOM_REGION_ENABLED] ?: true,
                showRegionBorder = prefs[Keys.SHOW_REGION_BORDER] ?: true,
                dimOutsideRegion = prefs[Keys.DIM_OUTSIDE_REGION] ?: true,
                regionLocked = prefs[Keys.REGION_LOCKED] ?: false,
                readingRegion = region,
                ocrIntervalMs = (prefs[Keys.OCR_INTERVAL_MS] ?: 600L).coerceIn(400L, 1500L),
                speechSpeed = (prefs[Keys.SPEECH_SPEED] ?: 1.0f).coerceIn(0.6f, 1.5f),
                speechPitch = (prefs[Keys.SPEECH_PITCH] ?: 1.0f).coerceIn(0.7f, 1.3f),
                speechVolume = (prefs[Keys.SPEECH_VOLUME] ?: 1.0f).coerceIn(0f, 1f),
                isMuted = prefs[Keys.IS_MUTED] ?: false,
                autoSpeak = prefs[Keys.AUTO_SPEAK] ?: true,
                floatingButtonOpacity = (prefs[Keys.FLOATING_BUTTON_OPACITY] ?: 0.92f).coerceIn(0.35f, 1f),
                floatingButtonSizeDp = (prefs[Keys.FLOATING_BUTTON_SIZE_DP] ?: 56).coerceIn(44, 72)
            )
        }

    suspend fun updateSettings(transform: (AppSettings) -> AppSettings) {
        context.gameTalkDataStore.edit { prefs ->
            val current = mapFromPreferences(prefs)
            val updated = transform(current)
            val safeRegion = updated.readingRegion.normalized()
            prefs[Keys.UI_LANGUAGE] = updated.uiLanguage.name
            prefs[Keys.FLOATING_OVERLAY_ENABLED] = updated.floatingOverlayEnabled
            prefs[Keys.SUBTITLE_OVERLAY_ENABLED] = updated.subtitleOverlayEnabled
            prefs[Keys.CUSTOM_REGION_ENABLED] = updated.customRegionEnabled
            prefs[Keys.SHOW_REGION_BORDER] = updated.showRegionBorder
            prefs[Keys.DIM_OUTSIDE_REGION] = updated.dimOutsideRegion
            prefs[Keys.REGION_LOCKED] = updated.regionLocked
            prefs[Keys.REGION_LEFT] = safeRegion.left
            prefs[Keys.REGION_TOP] = safeRegion.top
            prefs[Keys.REGION_RIGHT] = safeRegion.right
            prefs[Keys.REGION_BOTTOM] = safeRegion.bottom
            prefs[Keys.OCR_INTERVAL_MS] = updated.ocrIntervalMs.coerceIn(400L, 1500L)
            prefs[Keys.SPEECH_SPEED] = updated.speechSpeed.coerceIn(0.6f, 1.5f)
            prefs[Keys.SPEECH_PITCH] = updated.speechPitch.coerceIn(0.7f, 1.3f)
            prefs[Keys.SPEECH_VOLUME] = updated.speechVolume.coerceIn(0f, 1f)
            prefs[Keys.IS_MUTED] = updated.isMuted
            prefs[Keys.AUTO_SPEAK] = updated.autoSpeak
            prefs[Keys.FLOATING_BUTTON_OPACITY] = updated.floatingButtonOpacity.coerceIn(0.35f, 1f)
            prefs[Keys.FLOATING_BUTTON_SIZE_DP] = updated.floatingButtonSizeDp.coerceIn(44, 72)
        }
    }

    private fun mapFromPreferences(prefs: Preferences): AppSettings {
        val language = when (prefs[Keys.UI_LANGUAGE]) {
            UiLanguage.ENGLISH.name -> UiLanguage.ENGLISH
            else -> UiLanguage.HINDI
        }
        val region = ReadingRegion(
            left = prefs[Keys.REGION_LEFT] ?: ReadingRegion.DEFAULT_LEFT,
            top = prefs[Keys.REGION_TOP] ?: ReadingRegion.DEFAULT_TOP,
            right = prefs[Keys.REGION_RIGHT] ?: ReadingRegion.DEFAULT_RIGHT,
            bottom = prefs[Keys.REGION_BOTTOM] ?: ReadingRegion.DEFAULT_BOTTOM
        ).normalized()

        return AppSettings(
            uiLanguage = language,
            floatingOverlayEnabled = prefs[Keys.FLOATING_OVERLAY_ENABLED] ?: true,
            subtitleOverlayEnabled = prefs[Keys.SUBTITLE_OVERLAY_ENABLED] ?: true,
            customRegionEnabled = prefs[Keys.CUSTOM_REGION_ENABLED] ?: true,
            showRegionBorder = prefs[Keys.SHOW_REGION_BORDER] ?: true,
            dimOutsideRegion = prefs[Keys.DIM_OUTSIDE_REGION] ?: true,
            regionLocked = prefs[Keys.REGION_LOCKED] ?: false,
            readingRegion = region,
            ocrIntervalMs = (prefs[Keys.OCR_INTERVAL_MS] ?: 600L).coerceIn(400L, 1500L),
            speechSpeed = (prefs[Keys.SPEECH_SPEED] ?: 1.0f).coerceIn(0.6f, 1.5f),
            speechPitch = (prefs[Keys.SPEECH_PITCH] ?: 1.0f).coerceIn(0.7f, 1.3f),
            speechVolume = (prefs[Keys.SPEECH_VOLUME] ?: 1.0f).coerceIn(0f, 1f),
            isMuted = prefs[Keys.IS_MUTED] ?: false,
            autoSpeak = prefs[Keys.AUTO_SPEAK] ?: true,
            floatingButtonOpacity = (prefs[Keys.FLOATING_BUTTON_OPACITY] ?: 0.92f).coerceIn(0.35f, 1f),
            floatingButtonSizeDp = (prefs[Keys.FLOATING_BUTTON_SIZE_DP] ?: 56).coerceIn(44, 72)
        )
    }
}
