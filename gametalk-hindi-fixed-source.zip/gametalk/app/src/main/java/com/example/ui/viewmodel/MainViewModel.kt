package com.example.ui.viewmodel

import android.content.Intent
import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.GameTalkApplication
import com.example.data.AppSettings
import com.example.data.LiveSessionState
import com.example.data.ModelDownloadState
import com.example.data.ReadingRegion
import com.example.data.UiLanguage
import com.example.engine.CaptureCommand
import com.example.engine.TranslationResult
import com.example.firebase.CloudHistoryUiState
import com.example.firebase.CloudTranslation
import com.example.firebase.FirestoreSyncRepository
import com.example.service.FloatingOverlayService
import com.example.service.ScreenCaptureService
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

/**
 * Authenticated feature ViewModel extending plain ViewModel and accepting DI-configured
 * FirestoreSyncRepository + currentUserId (keyed per signed-in Google user).
 */
class MainViewModel(
    private val app: GameTalkApplication,
    private val firestoreRepository: FirestoreSyncRepository,
    private val currentUserId: String,
    private val userDisplayName: String
) : ViewModel() {

    private val container = app.container

    val settings: StateFlow<AppSettings> = container.repository.settingsFlow
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS),
            initialValue = AppSettings()
        )

    val sessionState: StateFlow<LiveSessionState> = container.controller.sessionState

    // Two-tier Flow error handling: unwrap CancellationException -> FirebaseFirestoreException
    // before stateIn so Compose collectors never crash and real errors surface cleanly.
    val cloudHistoryState: StateFlow<CloudHistoryUiState> =
        firestoreRepository.observeTranslations(currentUserId)
            .map<List<CloudTranslation>, CloudHistoryUiState> { CloudHistoryUiState.Success(it) }
            .catch { error ->
                val firestoreError = generateSequence(error) { it.cause }
                    .filterIsInstance<FirebaseFirestoreException>()
                    .firstOrNull()
                if (firestoreError == null && error is CancellationException) throw error
                val rootError = firestoreError ?: error
                Log.w(TAG, "Error observing cloud translations", rootError)
                emit(
                    CloudHistoryUiState.Error(
                        rootError.localizedMessage ?: "Failed to load cloud translation history."
                    )
                )
            }
            .stateIn(
                scope = viewModelScope,
                started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS),
                initialValue = CloudHistoryUiState.Loading
            )

    private val _hasOverlayPermission = MutableStateFlow(container.permissionManager.hasOverlayPermission())
    val hasOverlayPermission: StateFlow<Boolean> = _hasOverlayPermission.asStateFlow()

    private val _hasNotificationPermission = MutableStateFlow(container.permissionManager.hasNotificationPermission())
    val hasNotificationPermission: StateFlow<Boolean> = _hasNotificationPermission.asStateFlow()

    private val _isTestingVoice = MutableStateFlow(false)
    val isTestingVoice: StateFlow<Boolean> = _isTestingVoice.asStateFlow()

    init {
        viewModelScope.launch {
            val initialSettings = container.repository.settingsFlow.first()
            firestoreRepository.syncUserProfile(userDisplayName, initialSettings)
        }
    }

    fun refreshPermissionsAndEngines() {
        val overlayGranted = container.permissionManager.hasOverlayPermission()
        _hasOverlayPermission.value = overlayGranted
        _hasNotificationPermission.value = container.permissionManager.hasNotificationPermission()
        container.speechManager.recheckHindiVoice()

        if (overlayGranted && (settings.value.floatingOverlayEnabled || settings.value.showRegionBorder) &&
            sessionState.value.isCapturing
        ) {
            FloatingOverlayService.start(app)
        }
    }

    fun onNotificationPermissionResult(granted: Boolean) {
        _hasNotificationPermission.value = granted
        if (!granted) {
            container.controller.reportError(
                messageHi = "नोटिफिकेशन अनुमति नहीं मिली। लाइव अनुवाद चालू रहने पर स्टेटस नोटिफिकेशन आवश्यक है।",
                messageEn = "Notification permission was denied. A persistent notification is recommended while live translation runs.",
                markErrorStatus = false
            )
        }
    }

    fun createScreenCaptureIntent(): Intent? = container.permissionManager.createScreenCaptureIntent()
    fun createOverlayPermissionIntent(): Intent = container.permissionManager.createOverlayPermissionIntent()
    fun createInstallHindiTtsIntent(): Intent = container.permissionManager.createInstallHindiTtsIntent()

    fun onMediaProjectionGranted(resultCode: Int, data: Intent) {
        container.controller.clearError()
        container.controller.storePendingProjectionGrant(resultCode, data)
        ScreenCaptureService.start(app)
    }

    fun onMediaProjectionDenied() {
        container.controller.reportPermissionRequired(
            messageHi = "स्क्रीन कैप्चर अनुमति अस्वीकृत कर दी गई। लाइव अनुवाद के लिए कृपया सिस्टम संवाद में 'Start now' चुनें।",
            messageEn = "Screen capture permission was denied. Please approve the Android screen capture dialog to begin."
        )
    }

    fun stopTranslation() {
        container.controller.sendCommand(CaptureCommand.Stop)
        ScreenCaptureService.stop(app)
        FloatingOverlayService.stop(app)
        container.speechManager.stopSpeaking()
        container.controller.setCapturingStopped()
    }

    fun pauseTranslation() {
        if (sessionState.value.isCapturing) {
            container.controller.sendCommand(CaptureCommand.Pause)
        }
    }

    fun resumeTranslation() {
        if (sessionState.value.isCapturing) {
            container.controller.sendCommand(CaptureCommand.Resume)
        }
    }

    fun triggerReadNow() {
        if (sessionState.value.isCapturing) {
            container.controller.sendCommand(CaptureCommand.ReadNow)
        }
    }

    fun readAgain() {
        val text = sessionState.value.lastHindiText
        if (text.isNotBlank()) {
            container.speechManager.speakNow(text)
        }
    }

    fun stopSpeaking() {
        container.speechManager.stopSpeaking()
    }

    fun replayHindiText(hindiText: String) {
        if (hindiText.isNotBlank()) {
            container.speechManager.speakNow(hindiText)
        }
    }

    fun downloadHindiModel() {
        viewModelScope.launch {
            container.translationManager.ensureModelDownloaded()
        }
    }

    fun runLiveVoiceAndTranslationTest() {
        if (_isTestingVoice.value) return
        viewModelScope.launch {
            _isTestingVoice.value = true
            try {
                val sampleEnglish = "Captain: Stay sharp! The final gate is opening now."
                val modelReady = if (sessionState.value.modelState is ModelDownloadState.Downloaded) {
                    true
                } else {
                    container.translationManager.ensureModelDownloaded()
                }
                if (!modelReady) {
                    container.speechManager.speakNow("नमस्ते! गेमटॉक हिंदी आवाज़ तैयार है। कृपया ऑफ़लाइन मॉडल डाउनलोड करें।")
                    return@launch
                }

                when (val result = container.translationManager.translateEnglishToHindi(sampleEnglish)) {
                    is TranslationResult.Success -> {
                        container.controller.updateLatestDialogue(sampleEnglish, result.hindiText)
                        container.repository.saveTranslation(
                            english = sampleEnglish,
                            hindi = result.hindiText,
                            customRegionMode = settings.value.customRegionEnabled
                        )
                        val syncRes = firestoreRepository.addTranslation(
                            english = sampleEnglish,
                            hindi = result.hindiText,
                            customRegionMode = settings.value.customRegionEnabled
                        )
                        syncRes.onFailure { err ->
                            container.controller.reportError(
                                messageHi = "क्लाउड सिंक में त्रुटि: ${err.localizedMessage ?: "अज्ञात"}",
                                messageEn = "Cloud sync error: ${err.localizedMessage ?: "Unknown"}",
                                markErrorStatus = false
                            )
                        }
                        container.speechManager.speakNow(result.hindiText)
                    }
                    is TranslationResult.Failure -> {
                        container.controller.reportError(result.messageHi, result.messageEn, markErrorStatus = false)
                        container.speechManager.speakNow("नमस्ते! गेमटॉक हिंदी आवाज़ काम कर रही है।")
                    }
                }
            } finally {
                _isTestingVoice.value = false
            }
        }
    }

    fun clearError() {
        container.controller.clearError()
    }

    fun toggleUiLanguage() {
        updateAndSyncSettings { current ->
            val next = if (current.uiLanguage == UiLanguage.HINDI) UiLanguage.ENGLISH else UiLanguage.HINDI
            current.copy(uiLanguage = next)
        }
    }

    fun setUiLanguage(language: UiLanguage) {
        updateAndSyncSettings { it.copy(uiLanguage = language) }
    }

    fun setFloatingOverlayEnabled(enabled: Boolean): Boolean {
        val granted = container.permissionManager.hasOverlayPermission()
        _hasOverlayPermission.value = granted
        if (enabled && !granted) {
            container.controller.reportPermissionRequired(
                messageHi = "फ्लोटिंग बटन चालू करने के लिए 'Display over other apps' अनुमति दें।",
                messageEn = "Please grant 'Display over other apps' permission to enable the floating button."
            )
            return false
        }
        viewModelScope.launch {
            container.repository.updateSettings { it.copy(floatingOverlayEnabled = enabled) }
            syncOverlayService(
                floatingEnabled = enabled,
                showBox = settings.value.showRegionBorder,
                customRegion = settings.value.customRegionEnabled
            )
        }
        return true
    }

    fun setSubtitleOverlayEnabled(enabled: Boolean) {
        viewModelScope.launch {
            container.repository.updateSettings { it.copy(subtitleOverlayEnabled = enabled) }
        }
    }

    fun setCustomRegionEnabled(enabled: Boolean) {
        updateAndSyncSettings { it.copy(customRegionEnabled = enabled) }
        syncOverlayService(
            floatingEnabled = settings.value.floatingOverlayEnabled,
            showBox = settings.value.showRegionBorder,
            customRegion = enabled
        )
    }

    fun setShowRegionBorder(show: Boolean): Boolean {
        val granted = container.permissionManager.hasOverlayPermission()
        _hasOverlayPermission.value = granted
        if (show && !granted) {
            container.controller.reportPermissionRequired(
                messageHi = "रीडिंग बॉक्स दिखाने के लिए ओवरले अनुमति आवश्यक है।",
                messageEn = "Overlay permission is required to show the reading area box."
            )
            return false
        }
        viewModelScope.launch {
            container.repository.updateSettings { it.copy(showRegionBorder = show) }
            syncOverlayService(
                floatingEnabled = settings.value.floatingOverlayEnabled,
                showBox = show,
                customRegion = settings.value.customRegionEnabled
            )
        }
        return true
    }

    fun setRegionLocked(locked: Boolean) {
        viewModelScope.launch {
            container.repository.updateSettings { it.copy(regionLocked = locked) }
        }
    }

    fun setDimOutsideRegion(dim: Boolean) {
        viewModelScope.launch {
            container.repository.updateSettings { it.copy(dimOutsideRegion = dim) }
        }
    }

    fun resetReadingRegion() {
        updateAndSyncSettings { it.copy(readingRegion = ReadingRegion.DEFAULT) }
    }

    fun updateOcrInterval(ms: Long) {
        updateAndSyncSettings { it.copy(ocrIntervalMs = ms.coerceIn(400L, 1200L)) }
    }

    fun updateSpeechSpeed(speed: Float) {
        updateAndSyncSettings { it.copy(speechSpeed = speed.coerceIn(0.6f, 1.5f)) }
    }

    fun updateSpeechPitch(pitch: Float) {
        updateAndSyncSettings { it.copy(speechPitch = pitch.coerceIn(0.7f, 1.3f)) }
    }

    fun updateSpeechVolume(volume: Float) {
        updateAndSyncSettings { it.copy(speechVolume = volume.coerceIn(0f, 1f)) }
    }

    fun setMuted(muted: Boolean) {
        viewModelScope.launch {
            container.repository.updateSettings { it.copy(isMuted = muted) }
        }
    }

    fun setAutoSpeak(autoSpeak: Boolean) {
        viewModelScope.launch {
            container.repository.updateSettings { it.copy(autoSpeak = autoSpeak) }
        }
    }

    fun updateFloatingButtonOpacity(opacity: Float) {
        viewModelScope.launch {
            container.repository.updateSettings { it.copy(floatingButtonOpacity = opacity.coerceIn(0.35f, 1f)) }
        }
    }

    fun updateFloatingButtonSizeDp(sizeDp: Int) {
        viewModelScope.launch {
            container.repository.updateSettings { it.copy(floatingButtonSizeDp = sizeDp.coerceIn(44, 72)) }
        }
    }

    fun toggleFavoriteTranslation(translationId: String, favorite: Boolean) {
        viewModelScope.launch {
            firestoreRepository.toggleFavorite(translationId, favorite).onFailure { err ->
                container.controller.reportError(
                    messageHi = "बुकमार्क अपडेट नहीं हो सका: ${err.localizedMessage ?: "त्रुटि"}",
                    messageEn = "Could not update bookmark: ${err.localizedMessage ?: "Error"}",
                    markErrorStatus = false
                )
            }
        }
    }

    fun deleteHistoryItem(translationId: String) {
        viewModelScope.launch {
            firestoreRepository.deleteTranslation(translationId).onFailure { err ->
                container.controller.reportError(
                    messageHi = "अनुवाद हटाया नहीं जा सका: ${err.localizedMessage ?: "त्रुटि"}",
                    messageEn = "Could not delete translation: ${err.localizedMessage ?: "Error"}",
                    markErrorStatus = false
                )
            }
        }
    }

    fun clearAllHistory() {
        viewModelScope.launch {
            container.repository.clearHistory()
            firestoreRepository.clearAllTranslations().onFailure { err ->
                container.controller.reportError(
                    messageHi = "क्लाउड इतिहास मिटाया नहीं जा सका: ${err.localizedMessage ?: "त्रुटि"}",
                    messageEn = "Could not clear cloud history: ${err.localizedMessage ?: "Error"}",
                    markErrorStatus = false
                )
            }
        }
    }

    private fun updateAndSyncSettings(transform: (AppSettings) -> AppSettings) {
        viewModelScope.launch {
            container.repository.updateSettings(transform)
            val updated = container.repository.settingsFlow.first()
            firestoreRepository.syncUserProfile(userDisplayName, updated)
        }
    }

    private fun syncOverlayService(
        floatingEnabled: Boolean,
        showBox: Boolean,
        customRegion: Boolean
    ) {
        val shouldRun = floatingEnabled || (customRegion && showBox)
        if (shouldRun && container.permissionManager.hasOverlayPermission()) {
            FloatingOverlayService.start(app)
        } else if (!sessionState.value.isCapturing) {
            FloatingOverlayService.stop(app)
        }
    }

    companion object {
        private const val TAG = "MainViewModel"
        private const val STOP_TIMEOUT_MILLIS = 5_000L
    }
}
