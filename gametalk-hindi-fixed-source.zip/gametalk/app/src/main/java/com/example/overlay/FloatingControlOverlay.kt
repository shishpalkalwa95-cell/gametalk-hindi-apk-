package com.example.overlay

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.provider.Settings
import android.util.Log
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import com.example.data.TranslatorStatus
import kotlin.math.abs

/**
 * Movable floating gaming bubble + expandable compact controls overlay (Pause/Resume, Read Now,
 * Region Lock/Unlock, Stop, Settings) plus an optional live Hindi subtitle banner overlay.
 */
class FloatingControlOverlay(
    private val context: Context,
    private val onPauseResume: () -> Unit,
    private val onReadNow: () -> Unit,
    private val onToggleRegionLock: () -> Unit,
    private val onStop: () -> Unit,
    private val onOpenSettings: () -> Unit
) {
    private val windowManager = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val density = context.resources.displayMetrics.density

    private var rootContainer: LinearLayout? = null
    private var bubbleView: TextView? = null
    private var controlsRow: LinearLayout? = null
    private var pauseResumeBtn: TextView? = null
    private var readNowBtn: TextView? = null
    private var lockBtn: TextView? = null
    private var stopBtn: TextView? = null
    private var settingsBtn: TextView? = null
    private var bubbleParams: WindowManager.LayoutParams? = null
    private var isBubbleAttached: Boolean = false
    private var isExpanded: Boolean = false

    // Subtitle overlay components
    private var subtitleContainer: LinearLayout? = null
    private var subtitleHindiText: TextView? = null
    private var subtitleEnglishText: TextView? = null
    private var subtitleParams: WindowManager.LayoutParams? = null
    private var isSubtitleAttached: Boolean = false

    private var currentOpacity: Float = 0.92f
    private var currentSizeDp: Int = 56
    private var isPaused: Boolean = false
    private var isCapturing: Boolean = false
    private var isRegionLocked: Boolean = false
    private var isHindiUi: Boolean = true
    private var currentStatus: TranslatorStatus = TranslatorStatus.IDLE

    fun updateFloatingButton(
        visible: Boolean,
        opacity: Float,
        sizeDp: Int,
        status: TranslatorStatus,
        isCapturing: Boolean,
        isPaused: Boolean,
        isRegionLocked: Boolean,
        isHindiUi: Boolean
    ) {
        this.currentOpacity = opacity.coerceIn(0.35f, 1f)
        this.currentSizeDp = sizeDp.coerceIn(44, 72)
        this.currentStatus = status
        this.isCapturing = isCapturing
        this.isPaused = isPaused
        this.isRegionLocked = isRegionLocked
        this.isHindiUi = isHindiUi

        if (!visible || !Settings.canDrawOverlays(context)) {
            detachBubble()
            return
        }

        if (!isBubbleAttached) {
            attachBubble()
        } else {
            refreshBubbleAppearance()
        }
    }

    fun updateSubtitleOverlay(
        enabled: Boolean,
        hindiText: String,
        englishText: String,
        isSpeaking: Boolean
    ) {
        if (!enabled || hindiText.isBlank() || !Settings.canDrawOverlays(context)) {
            detachSubtitle()
            return
        }

        if (!isSubtitleAttached) {
            attachSubtitle()
        }

        subtitleHindiText?.text = hindiText
        subtitleEnglishText?.apply {
            text = englishText
            visibility = if (englishText.isNotBlank()) View.VISIBLE else View.GONE
        }
        subtitleContainer?.background = createSubtitleBackground(isSpeaking)
    }

    fun onConfigurationChanged() {
        val params = bubbleParams ?: return
        val container = rootContainer ?: return
        if (!isBubbleAttached) return

        val screenW = context.resources.displayMetrics.widthPixels
        val screenH = context.resources.displayMetrics.heightPixels
        params.x = params.x.coerceIn(0, (screenW - dp(currentSizeDp)).coerceAtLeast(0))
        params.y = params.y.coerceIn(0, (screenH - dp(currentSizeDp)).coerceAtLeast(0))
        runCatching { windowManager.updateViewLayout(container, params) }
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun attachBubble() {
        if (isBubbleAttached || !Settings.canDrawOverlays(context)) return

        val container = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            alpha = currentOpacity
        }

        val bubbleSizePx = dp(currentSizeDp)
        val bubble = TextView(context).apply {
            text = "हि"
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 20f)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            background = createBubbleBackground(currentStatus)
            elevation = dp(6).toFloat()
        }
        container.addView(bubble, LinearLayout.LayoutParams(bubbleSizePx, bubbleSizePx))

        val controls = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), dp(6), dp(8), dp(6))
            background = createControlsBarBackground()
            visibility = View.GONE
        }

        val pauseBtn = createCompactActionButton(
            label = pauseButtonLabel(),
            bgColor = Color.parseColor("#2A1B4E"),
            strokeColor = Color.parseColor("#9D6BFF")
        ) {
            onPauseResume()
        }
        val readBtn = createCompactActionButton(
            label = if (isHindiUi) "पढ़ें" else "Read",
            bgColor = Color.parseColor("#0D2F3F"),
            strokeColor = Color.parseColor("#22D3EE")
        ) {
            onReadNow()
        }
        val lockActionBtn = createCompactActionButton(
            label = lockButtonLabel(),
            bgColor = Color.parseColor("#1B2545"),
            strokeColor = Color.parseColor("#60A5FA")
        ) {
            onToggleRegionLock()
        }
        val stopActionBtn = createCompactActionButton(
            label = if (isHindiUi) "बंद" else "Stop",
            bgColor = Color.parseColor("#4C0D1D"),
            strokeColor = Color.parseColor("#F43F5E")
        ) {
            isExpanded = false
            controls.visibility = View.GONE
            onStop()
        }
        val settingsActionBtn = createCompactActionButton(
            label = if (isHindiUi) "सेटिंग" else "App",
            bgColor = Color.parseColor("#161E38"),
            strokeColor = Color.parseColor("#94A3B8")
        ) {
            isExpanded = false
            controls.visibility = View.GONE
            onOpenSettings()
        }

        controls.addView(pauseBtn)
        controls.addView(readBtn)
        controls.addView(lockActionBtn)
        controls.addView(stopActionBtn)
        controls.addView(settingsActionBtn)

        val controlsLp = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply {
            marginStart = dp(6)
        }
        container.addView(controls, controlsLp)

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(16)
            y = dp(180)
        }

        // Smooth drag-anywhere touch listener with tap detection to toggle compact controls
        var initialX = 0
        var initialY = 0
        var touchStartX = 0f
        var touchStartY = 0f
        var isDragging = false
        val tapSlop = dp(10).toFloat()

        bubble.setOnTouchListener { _, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = params.x
                    initialY = params.y
                    touchStartX = event.rawX
                    touchStartY = event.rawY
                    isDragging = false
                    true
                }

                MotionEvent.ACTION_MOVE -> {
                    val dx = event.rawX - touchStartX
                    val dy = event.rawY - touchStartY
                    if (!isDragging && (abs(dx) > tapSlop || abs(dy) > tapSlop)) {
                        isDragging = true
                    }
                    if (isDragging) {
                        val screenW = context.resources.displayMetrics.widthPixels
                        val screenH = context.resources.displayMetrics.heightPixels
                        params.x = (initialX + dx.toInt()).coerceIn(0, (screenW - bubbleSizePx).coerceAtLeast(0))
                        params.y = (initialY + dy.toInt()).coerceIn(0, (screenH - bubbleSizePx).coerceAtLeast(0))
                        runCatching { windowManager.updateViewLayout(container, params) }
                    }
                    true
                }

                MotionEvent.ACTION_UP -> {
                    if (!isDragging) {
                        isExpanded = !isExpanded
                        controls.visibility = if (isExpanded) View.VISIBLE else View.GONE
                        runCatching { windowManager.updateViewLayout(container, params) }
                    }
                    true
                }

                else -> false
            }
        }

        try {
            windowManager.addView(container, params)
            rootContainer = container
            bubbleView = bubble
            controlsRow = controls
            pauseResumeBtn = pauseBtn
            readNowBtn = readBtn
            lockBtn = lockActionBtn
            stopBtn = stopActionBtn
            settingsBtn = settingsActionBtn
            bubbleParams = params
            isBubbleAttached = true
        } catch (t: Throwable) {
            Log.e(TAG, "Unable to attach FloatingControlOverlay", t)
            isBubbleAttached = false
        }
    }

    private fun refreshBubbleAppearance() {
        val container = rootContainer ?: return
        val bubble = bubbleView ?: return
        val params = bubbleParams ?: return

        container.alpha = currentOpacity
        val sizePx = dp(currentSizeDp)
        val lp = bubble.layoutParams
        if (lp != null && (lp.width != sizePx || lp.height != sizePx)) {
            lp.width = sizePx
            lp.height = sizePx
            bubble.layoutParams = lp
        }
        bubble.background = createBubbleBackground(currentStatus)
        pauseResumeBtn?.text = pauseButtonLabel()
        readNowBtn?.text = if (isHindiUi) "पढ़ें" else "Read"
        lockBtn?.text = lockButtonLabel()
        stopBtn?.text = if (isHindiUi) "बंद" else "Stop"
        settingsBtn?.text = if (isHindiUi) "सेटिंग" else "App"

        runCatching { windowManager.updateViewLayout(container, params) }
    }

    private fun attachSubtitle() {
        if (isSubtitleAttached || !Settings.canDrawOverlays(context)) return

        val container = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(16), dp(10), dp(16), dp(10))
            background = createSubtitleBackground(false)
        }

        val hindiView = TextView(context).apply {
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 19f)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            maxLines = 4
        }

        val englishView = TextView(context).apply {
            setTextColor(Color.parseColor("#B6C2DF"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            gravity = Gravity.CENTER
            maxLines = 2
            setPadding(0, dp(3), 0, 0)
        }

        container.addView(hindiView)
        container.addView(englishView)

        val maxWidth = (context.resources.displayMetrics.widthPixels * 0.90f).toInt()
        val params = WindowManager.LayoutParams(
            maxWidth,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            y = dp(42)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }

        try {
            windowManager.addView(container, params)
            subtitleContainer = container
            subtitleHindiText = hindiView
            subtitleEnglishText = englishView
            subtitleParams = params
            isSubtitleAttached = true
        } catch (t: Throwable) {
            Log.e(TAG, "Unable to attach subtitle overlay", t)
            isSubtitleAttached = false
        }
    }

    fun detachAll() {
        detachBubble()
        detachSubtitle()
    }

    private fun detachBubble() {
        if (!isBubbleAttached) return
        val container = rootContainer
        rootContainer = null
        bubbleView = null
        controlsRow = null
        bubbleParams = null
        isBubbleAttached = false
        isExpanded = false
        if (container != null) {
            runCatching { windowManager.removeView(container) }
        }
    }

    private fun detachSubtitle() {
        if (!isSubtitleAttached) return
        val container = subtitleContainer
        subtitleContainer = null
        subtitleHindiText = null
        subtitleEnglishText = null
        subtitleParams = null
        isSubtitleAttached = false
        if (container != null) {
            runCatching { windowManager.removeView(container) }
        }
    }

    private fun pauseButtonLabel(): String {
        return when {
            !isCapturing -> if (isHindiUi) "शुरू" else "Start"
            isPaused -> if (isHindiUi) "चालू" else "Resume"
            else -> if (isHindiUi) "रोकें" else "Pause"
        }
    }

    private fun lockButtonLabel(): String {
        return if (isRegionLocked) {
            if (isHindiUi) "अनलॉक" else "Unlock"
        } else {
            if (isHindiUi) "लॉक" else "Lock"
        }
    }

    private fun createCompactActionButton(
        label: String,
        bgColor: Int,
        strokeColor: Int,
        onClick: () -> Unit
    ): TextView {
        return TextView(context).apply {
            text = label
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            minHeight = dp(38)
            minWidth = dp(48)
            setPadding(dp(10), dp(6), dp(10), dp(6))
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = dp(10).toFloat()
                setColor(bgColor)
                setStroke(dp(1), strokeColor)
            }
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                marginEnd = dp(6)
            }
            setOnClickListener { onClick() }
        }
    }

    private fun createBubbleBackground(status: TranslatorStatus): GradientDrawable {
        val ringColor = when (status) {
            TranslatorStatus.SPEAKING, TranslatorStatus.CAPTURING -> Color.parseColor("#22D3EE")
            TranslatorStatus.READING, TranslatorStatus.TRANSLATING -> Color.parseColor("#9D6BFF")
            TranslatorStatus.PAUSED -> Color.parseColor("#F59E0B")
            TranslatorStatus.ERROR, TranslatorStatus.PERMISSION_REQUIRED -> Color.parseColor("#F43F5E")
            TranslatorStatus.IDLE -> Color.parseColor("#64748B")
        }
        return GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(Color.parseColor("#0D1326"))
            setStroke(dp(3), ringColor)
        }
    }

    private fun createControlsBarBackground(): GradientDrawable {
        return GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dp(16).toFloat()
            setColor(Color.argb(238, 10, 15, 30))
            setStroke(dp(1), Color.parseColor("#2B3966"))
        }
    }

    private fun createSubtitleBackground(isSpeaking: Boolean): GradientDrawable {
        return GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dp(14).toFloat()
            setColor(Color.argb(228, 7, 10, 22))
            setStroke(
                dp(2),
                if (isSpeaking) Color.parseColor("#22D3EE") else Color.parseColor("#9D6BFF")
            )
        }
    }

    private fun dp(value: Int): Int = (value * density).toInt()

    companion object {
        private const val TAG = "FloatingControlOverlay"
    }
}
