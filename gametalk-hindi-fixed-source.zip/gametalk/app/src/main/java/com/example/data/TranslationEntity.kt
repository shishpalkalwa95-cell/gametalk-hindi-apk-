package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "translation_history")
data class TranslationEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val originalEnglish: String,
    val translatedHindi: String,
    val timestamp: Long = System.currentTimeMillis(),
    val captureMode: String = "region"
)
