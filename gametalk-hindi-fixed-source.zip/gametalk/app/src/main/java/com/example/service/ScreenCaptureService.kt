package com.example.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.content.res.Configuration
import android.graphics.Bitmap
import android.os.Build
import android.os.IBinder
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import com.example.GameTalkApplication
import com.example.MainActivity
import com.example.R
import com.example.data.AppSettings
import com.example.data.TranslatorStatus
import com.example.engine.CaptureCommand
import com.example.engine.OcrResult
import com.example.engine.ScreenCaptureManager
import com.example.engine.TranslationResult
import com.google.firebase.Firebase
import com.google.firebase.auth.auth
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Foreground Service (mediaProjection type) running the complete on-device pipeline:
 * MediaProjection -> Cropped Reading Region -> ML Kit OCR -> ML Kit English-to-Hindi Translation
 * -> Android Hindi TextToSpeech + Room History persistence.
 */
class ScreenCaptureService : Service() {

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val isProcessingFrame = AtomicBoolean(false)

    private var captureManager: ScreenCaptureManager? = null
    @Volatile
    private var latestSettings: AppSettings = AppSettings()

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        val container = (application as GameTalkApplication).container

        captureManager = ScreenCaptureManager(
            context = this,
            onFrameCaptured = { bitmap, forceRead ->
                handleCapturedFrame(bitmap, forceRead)
            },
            onProjectionStopped = {
                container.controller.reportPermissionRequired(
                    messageHi = "स्क्रीन कैप्चर सत्र Android सिस्टम या स्क्रीन लॉक के कारण बंद हो गया। जारी रखने के लिए ऐप में फिर से अनुमति दें।",
                    messageEn = "Screen capture session ended by Android system or screen lock. Grant screen capture permission again in the app."
                )
                stopSessionAndSelf(preserveError = true)
            },
            onCaptureError = { hiMsg, enMsg ->
                container.controller.reportError(hiMsg, enMsg)
                stopSessionAndSelf(preserveError = true)
            },
            onDisplayReconfigured = {
                // Reset frame signature so the first frame after Portrait <-> Landscape rotation scans immediately
                container.ocrProcessor.resetFrameSignatureOnly()
            }
        )

        serviceScope.launch {
            container.repository.settingsFlow.collect { settings ->
                latestSettings = settings
                captureManager?.updateInterval(settings.ocrIntervalMs)
            }
        }

        serviceScope.launch {
            container.controller.commands.collect { command ->
                when (command) {
                    CaptureCommand.Pause -> pauseCapture()
                    CaptureCommand.Resume -> resumeCapture()
                    CaptureCommand.ReadNow -> {
                        container.ocrProcessor.resetState()
                        captureManager?.requestImmediateCapture()
                    }
                    CaptureCommand.Stop -> stopSessionAndSelf()
                }
            }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopSessionAndSelf()
                return START_NOT_STICKY
            }
            ACTION_PAUSE -> {
                pauseCapture()
                return START_NOT_STICKY
            }
            ACTION_RESUME -> {
                resumeCapture()
                return START_NOT_STICKY
            }
            ACTION_START -> {
                startCaptureSession()
                return START_NOT_STICKY
            }
            else -> {
                // If process was recreated without an active MediaProjection consent token,
                // stop cleanly instead of crashing.
                val container = (application as GameTalkApplication).container
                if (!container.controller.sessionState.value.isCapturing) {
                    stopSelf()
                }
                return START_NOT_STICKY
            }
        }
    }

    private fun startCaptureSession() {
        val container = (application as GameTalkApplication).container

        // Promote to foreground with MEDIA_PROJECTION type BEFORE acquiring MediaProjection
        val notification = buildNotification(isPaused = false)
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                ServiceCompat.startForeground(
                    this,
                    NOTIFICATION_ID,
                    notification,
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
                )
            } else {
                startForeground(NOTIFICATION_ID, notification)
            }
        } catch (se: SecurityException) {
            Log.e(TAG, "Foreground service start denied", se)
            container.controller.reportError(
                messageHi = "मीडिया प्रोजेक्शन सेवा शुरू नहीं हो सकी। कृपया स्क्रीन कैप्चर की अनुमति फिर से दें।",
                messageEn = "Could not start mediaProjection foreground service. Please grant screen capture again."
            )
            stopSelf()
            return
        }

        val grant = container.controller.consumePendingProjectionGrant()
        if (grant == null) {
            container.controller.reportPermissionRequired(
                messageHi = "हर नए सत्र के लिए स्क्रीन कैप्चर अनुमति आवश्यक है।",
                messageEn = "Screen capture permission is required for each new session."
            )
            stopSessionAndSelf(preserveError = true)
            return
        }

        container.ocrProcessor.resetState()
        val started = captureManager?.start(
            resultCode = grant.first,
            resultData = grant.second,
            scanIntervalMs = latestSettings.ocrIntervalMs
        ) ?: false

        if (!started) {
            stopSessionAndSelf(preserveError = true)
            return
        }

        container.speechManager.resume()
        container.controller.setCapturingStarted()

        // Ensure independent floating overlay service is active when permitted and enabled
        if (container.permissionManager.hasOverlayPermission() &&
            (latestSettings.floatingOverlayEnabled || latestSettings.showRegionBorder)
        ) {
            FloatingOverlayService.start(this)
        }
    }

    private fun handleCapturedFrame(bitmap: Bitmap, forceRead: Boolean) {
        val container = (application as GameTalkApplication).container
        if (!isProcessingFrame.compareAndSet(false, true)) {
            if (!bitmap.isRecycled) bitmap.recycle()
            return
        }

        serviceScope.launch {
            try {
                val settings = latestSettings
                val session = container.controller.sessionState.value
                if (!session.isCapturing || (session.isPaused && !forceRead)) {
                    return@launch
                }

                container.controller.incrementProcessedFrames()
                container.controller.updateStatus(TranslatorStatus.READING)

                val ocrResult = container.ocrProcessor.processBitmap(
                    fullFrame = bitmap,
                    customRegionEnabled = settings.customRegionEnabled,
                    readingRegion = settings.readingRegion,
                    forceRead = forceRead
                )

                when (ocrResult) {
                    OcrResult.UnchangedFrame,
                    OcrResult.EmptyOrNoise,
                    OcrResult.DuplicateSuppressed -> {
                        restoreActiveStatus()
                    }

                    is OcrResult.Failure -> {
                        container.controller.reportError(
                            messageHi = "टेक्स्ट पहचान (OCR) में समस्या आई। अगली फ्रेम पर पुनः प्रयास किया जाएगा।",
                            messageEn = "OCR failed on this frame. Retrying automatically on next frame.",
                            markErrorStatus = false
                        )
                        restoreActiveStatus()
                    }

                    is OcrResult.NewDialogue -> {
                        container.controller.updateStatus(TranslatorStatus.TRANSLATING)
                        when (val translated = container.translationManager.translateEnglishToTarget(
                            englishText = ocrResult.text,
                            targetLanguage = settings.targetLanguage
                        )) {
                            is TranslationResult.Success -> {
                                container.controller.updateLatestDialogue(
                                    english = ocrResult.text,
                                    hindi = translated.hindiText
                                )
                                container.repository.saveTranslation(
                                    english = ocrResult.text,
                                    hindi = translated.hindiText,
                                    customRegionMode = settings.customRegionEnabled
                                )
                                if (Firebase.auth.currentUser != null) {
                                    container.firestoreRepository.addTranslation(
                                        english = ocrResult.text,
                                        hindi = translated.hindiText,
                                        customRegionMode = settings.customRegionEnabled
                                    )
                                }
                                if (settings.autoSpeak && !settings.isMuted) {
                                    container.speechManager.enqueueDialogue(
                                        hindiText = translated.hindiText,
                                        interruptPending = settings.interruptPendingSpeech
                                    )
                                } else {
                                    restoreActiveStatus()
                                }
                            }

                            is TranslationResult.Failure -> {
                                container.controller.reportError(
                                    messageHi = translated.messageHi,
                                    messageEn = translated.messageEn,
                                    markErrorStatus = true
                                )
                            }
                        }
                    }
                }
            } catch (t: Throwable) {
                Log.e(TAG, "Pipeline error", t)
                container.controller.reportError(
                    messageHi = "लाइव अनुवाद प्रक्रिया में त्रुटि हुई।",
                    messageEn = "Unexpected error in live translation pipeline.",
                    markErrorStatus = false
                )
            } finally {
                if (!bitmap.isRecycled) bitmap.recycle()
                isProcessingFrame.set(false)
            }
        }
    }

    private fun restoreActiveStatus() {
        val container = (application as GameTalkApplication).container
        val current = container.controller.sessionState.value
        if (!current.isCapturing) return
        val status = when {
            current.isPaused -> TranslatorStatus.PAUSED
            current.isSpeaking -> TranslatorStatus.SPEAKING
            else -> TranslatorStatus.CAPTURING
        }
        container.controller.updateStatus(status)
    }

    private fun pauseCapture() {
        val container = (application as GameTalkApplication).container
        captureManager?.setPaused(true)
        container.speechManager.pause()
        container.controller.setPaused(true)
        updateNotification(isPaused = true)
    }

    private fun resumeCapture() {
        val container = (application as GameTalkApplication).container
        captureManager?.setPaused(false)
        container.speechManager.resume()
        container.controller.setPaused(false)
        updateNotification(isPaused = false)
    }

    private fun stopSessionAndSelf(preserveError: Boolean = false) {
        val container = (application as GameTalkApplication).container
        captureManager?.stop()
        container.speechManager.stopSpeaking()
        container.ocrProcessor.resetState()

        if (!preserveError) {
            container.controller.setCapturingStopped()
        } else {
            val prevStatus = container.controller.sessionState.value.status
            val prevErrorHi = container.controller.sessionState.value.lastErrorHi
            val prevErrorEn = container.controller.sessionState.value.lastErrorEn
            container.controller.setCapturingStopped()
            if (prevErrorHi != null && prevErrorEn != null) {
                if (prevStatus == TranslatorStatus.PERMISSION_REQUIRED) {
                    container.controller.reportPermissionRequired(prevErrorHi, prevErrorEn)
                } else {
                    container.controller.reportError(prevErrorHi, prevErrorEn, markErrorStatus = true)
                }
            }
        }

        // Keep FloatingOverlayService lifecycle independent so the Floating Circle stays available
        // if enabled by the user (only stop it if neither floating circle nor region box is enabled).
        if (!latestSettings.floatingOverlayEnabled && !latestSettings.showRegionBorder) {
            FloatingOverlayService.stop(this)
        }
        ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        captureManager?.handleConfigurationChanged()
    }

    override fun onLowMemory() {
        super.onLowMemory()
        val container = (application as GameTalkApplication).container
        container.translationManager.clearCache()
        container.speechManager.trimQueueForLowMemory()
    }

    override fun onTrimMemory(level: Int) {
        super.onTrimMemory(level)
        if (level >= TRIM_MEMORY_RUNNING_LOW) {
            val container = (application as GameTalkApplication).container
            container.translationManager.clearCache()
            container.speechManager.trimQueueForLowMemory()
        }
    }

    override fun onDestroy() {
        val container = (application as GameTalkApplication).container
        captureManager?.stop()
        container.speechManager.stopSpeaking()
        if (container.controller.sessionState.value.isCapturing) {
            container.controller.setCapturingStopped()
        }
        serviceScope.cancel()
        super.onDestroy()
    }

    private fun createNotificationChannel() {
        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val channel = NotificationChannel(
            CHANNEL_ID,
            getString(R.string.notification_channel_name),
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = getString(R.string.notification_channel_description)
            setShowBadge(false)
        }
        manager.createNotificationChannel(channel)
    }

    private fun updateNotification(isPaused: Boolean) {
        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.notify(NOTIFICATION_ID, buildNotification(isPaused))
    }

    private fun buildNotification(isPaused: Boolean): Notification {
        val openAppIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val contentPendingIntent = PendingIntent.getActivity(
            this,
            100,
            openAppIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val toggleIntent = Intent(this, ScreenCaptureService::class.java).apply {
            action = if (isPaused) ACTION_RESUME else ACTION_PAUSE
        }
        val togglePendingIntent = PendingIntent.getService(
            this,
            101,
            toggleIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val stopIntent = Intent(this, ScreenCaptureService::class.java).apply {
            action = ACTION_STOP
        }
        val stopPendingIntent = PendingIntent.getService(
            this,
            102,
            stopIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val title = if (isPaused) {
            getString(R.string.notification_title_paused)
        } else {
            getString(R.string.notification_title_active)
        }
        val text = if (isPaused) {
            getString(R.string.notification_text_paused)
        } else {
            getString(R.string.notification_text_active)
        }
        val toggleLabel = if (isPaused) {
            getString(R.string.notification_action_resume)
        } else {
            getString(R.string.notification_action_pause)
        }

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notification_translate)
            .setContentTitle(title)
            .setContentText(text)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setSilent(true)
            .setContentIntent(contentPendingIntent)
            .addAction(0, toggleLabel, togglePendingIntent)
            .addAction(0, getString(R.string.notification_action_stop), stopPendingIntent)
            .build()
    }

    companion object {
        private const val TAG = "ScreenCaptureService"
        private const val CHANNEL_ID = "gametalk_capture_channel"
        private const val NOTIFICATION_ID = 4201

        const val ACTION_START = "com.example.action.CAPTURE_START"
        const val ACTION_PAUSE = "com.example.action.CAPTURE_PAUSE"
        const val ACTION_RESUME = "com.example.action.CAPTURE_RESUME"
        const val ACTION_STOP = "com.example.action.CAPTURE_STOP"

        fun start(context: Context) {
            val intent = Intent(context, ScreenCaptureService::class.java).apply {
                action = ACTION_START
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stop(context: Context) {
            val intent = Intent(context, ScreenCaptureService::class.java).apply {
                action = ACTION_STOP
            }
            runCatching { context.startService(intent) }
        }
    }
}
