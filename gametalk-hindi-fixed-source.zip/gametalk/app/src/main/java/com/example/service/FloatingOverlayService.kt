package com.example.service

import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.os.IBinder
import android.provider.Settings
import android.widget.Toast
import com.example.GameTalkApplication
import com.example.MainActivity
import com.example.data.AppSettings
import com.example.data.LiveSessionState
import com.example.data.UiLanguage
import com.example.engine.CaptureCommand
import com.example.overlay.FloatingControlOverlay
import com.example.overlay.ReadingAreaOverlay
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch

/**
 * Manages the floating control bubble, movable/resizable reading region overlay, and
 * optional Hindi subtitle overlay safely via WindowManager.
 */
class FloatingOverlayService : Service() {

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

    private lateinit var readingAreaOverlay: ReadingAreaOverlay
    private lateinit var floatingControlOverlay: FloatingControlOverlay

    private var latestSettings: AppSettings = AppSettings()
    private var latestSession: LiveSessionState = LiveSessionState()

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        val container = (application as GameTalkApplication).container

        readingAreaOverlay = ReadingAreaOverlay(
            context = this,
            onRegionChanged = { updatedRegion ->
                serviceScope.launch {
                    container.repository.saveReadingRegion(updatedRegion)
                }
            },
            onToggleLock = {
                serviceScope.launch {
                    container.repository.updateSettings { it.copy(regionLocked = !it.regionLocked) }
                }
            },
            onHideRequested = {
                serviceScope.launch {
                    container.repository.updateSettings { it.copy(showRegionBorder = false) }
                }
            }
        )

        floatingControlOverlay = FloatingControlOverlay(
            context = this,
            onPauseResume = {
                if (!latestSession.isCapturing) {
                    // Do not launch MainActivity over the game from the floating Start button.
                    // Android requires a foreground Activity for fresh MediaProjection consent.
                    Toast.makeText(
                        this,
                        "स्क्रीन कैप्चर बंद है। नई अनुमति के लिए GameTalk Hindi ऐप में एक बार Start करें।",
                        Toast.LENGTH_LONG
                    ).show()
                } else if (latestSession.isPaused) {
                    container.controller.sendCommand(CaptureCommand.Resume)
                } else {
                    container.controller.sendCommand(CaptureCommand.Pause)
                }
            },
            onReadNow = {
                if (latestSession.isCapturing) {
                    container.controller.sendCommand(CaptureCommand.ReadNow)
                } else {
                    Toast.makeText(
                        this,
                        "पहले GameTalk Hindi ऐप में Live Translation शुरू करें।",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            },
            onToggleRegionLock = {
                serviceScope.launch {
                    container.repository.updateSettings { current ->
                        if (!current.showRegionBorder) {
                            current.copy(showRegionBorder = true, regionLocked = false)
                        } else {
                            current.copy(regionLocked = !current.regionLocked)
                        }
                    }
                }
            },
            onStop = {
                container.controller.sendCommand(CaptureCommand.Stop)
                stopSelf()
            },
            onOpenSettings = {
                openMainActivity()
            }
        )

        serviceScope.launch {
            combine(
                container.repository.settingsFlow,
                container.controller.sessionState
            ) { settings, session -> settings to session }
                .collect { (settings, session) ->
                    latestSettings = settings
                    latestSession = session
                    renderOverlays(settings, session)
                }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val container = (application as GameTalkApplication).container
        if (intent?.action == ACTION_STOP_OVERLAY) {
            stopSelf()
            return START_NOT_STICKY
        }

        if (!Settings.canDrawOverlays(this)) {
            container.controller.setOverlayActive(false)
            container.controller.reportPermissionRequired(
                messageHi = "फ्लोटिंग बटन और रीडिंग बॉक्स दिखाने के लिए 'Display over other apps' अनुमति आवश्यक है।",
                messageEn = "Overlay permission ('Display over other apps') is required for the floating button and reading box."
            )
            stopSelf()
            return START_NOT_STICKY
        }

        container.controller.setOverlayActive(true)
        renderOverlays(latestSettings, latestSession)
        return START_STICKY
    }

    private fun renderOverlays(settings: AppSettings, session: LiveSessionState) {
        val container = (application as GameTalkApplication).container
        if (!Settings.canDrawOverlays(this)) {
            container.controller.setOverlayActive(false)
            readingAreaOverlay.detach()
            floatingControlOverlay.detachAll()
            return
        }

        val isHindiUi = settings.uiLanguage == UiLanguage.HINDI

        readingAreaOverlay.updateState(
            visible = settings.customRegionEnabled && settings.showRegionBorder,
            region = settings.readingRegion,
            locked = settings.regionLocked,
            showBorder = settings.showRegionBorder,
            dimOutside = settings.dimOutsideRegion,
            isHindiUi = isHindiUi
        )

        floatingControlOverlay.updateFloatingButton(
            visible = settings.floatingOverlayEnabled,
            opacity = settings.floatingButtonOpacity,
            sizeDp = settings.floatingButtonSizeDp,
            status = session.status,
            isCapturing = session.isCapturing,
            isPaused = session.isPaused,
            isRegionLocked = settings.regionLocked,
            isHindiUi = isHindiUi
        )

        floatingControlOverlay.updateSubtitleOverlay(
            enabled = settings.subtitleOverlayEnabled && session.isCapturing,
            hindiText = session.lastHindiText,
            englishText = session.lastEnglishText,
            isSpeaking = session.isSpeaking
        )

        val anyVisible = settings.floatingOverlayEnabled ||
            (settings.customRegionEnabled && settings.showRegionBorder) ||
            (settings.subtitleOverlayEnabled && session.isCapturing)
        container.controller.setOverlayActive(anyVisible)
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        readingAreaOverlay.onConfigurationChanged()
        floatingControlOverlay.onConfigurationChanged()
    }

    private fun openMainActivity() {
        val intent = Intent(this, MainActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        }
        runCatching { startActivity(intent) }
    }

    override fun onDestroy() {
        val container = (application as GameTalkApplication).container
        container.controller.setOverlayActive(false)
        readingAreaOverlay.detach()
        floatingControlOverlay.detachAll()
        serviceScope.cancel()
        super.onDestroy()
    }

    companion object {
        const val ACTION_START_OVERLAY = "com.example.action.START_OVERLAY"
        const val ACTION_STOP_OVERLAY = "com.example.action.STOP_OVERLAY"

        fun start(context: Context) {
            if (!Settings.canDrawOverlays(context)) return
            val intent = Intent(context, FloatingOverlayService::class.java).apply {
                action = ACTION_START_OVERLAY
            }
            runCatching { context.startService(intent) }
        }

        fun stop(context: Context) {
            val intent = Intent(context, FloatingOverlayService::class.java).apply {
                action = ACTION_STOP_OVERLAY
            }
            runCatching { context.stopService(intent) }
        }
    }
}
